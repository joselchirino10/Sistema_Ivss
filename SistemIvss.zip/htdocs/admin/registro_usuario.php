<?php
require_once '../auth/sesion.php';
validarAcceso('Administrador'); 
require_once '../conexion.php';

$error_db = "";
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        $fecha_nacimiento = $_POST['fecha_nacimiento'];
        
        // --- VALIDACIÓN DE MAYORÍA DE EDAD ---
        $cumpleanos = new DateTime($fecha_nacimiento);
        $hoy = new DateTime();
        $edad = $hoy->diff($cumpleanos)->y;

        if ($edad < 18) {
            $error_db = "El usuario debe ser mayor de 18 años para ser registrado.";
        } else {
            $rol_asignado = $_POST['tipo_usuario'] ?? 'Regular';
            
            $sql = "INSERT INTO usuarios_sistema (nombre, apellidos, cedula, correo, fecha_nacimiento, username, password_hash, tipo_usuario, estado, intentos_fallidos) 
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, 'activo', 0)";
            
            $stmt = $pdo->prepare($sql);
            $stmt->execute([
                $_POST['nombre'], 
                $_POST['apellidos'], 
                $_POST['cedula'], 
                $_POST['correo'], 
                $fecha_nacimiento, 
                $_POST['username'], 
                '', 
                $rol_asignado
            ]);
            
            header("Location: gestion_usuarios.php?accion=creado");
            exit;
        }
    } catch (PDOException $e) {
        $error_db = "La cédula o el nombre de usuario ya existen en el sistema.";
    }
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>IVSS - Registrar Personal</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;600&family=Montserrat:wght@500;600&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <style>
        /* Mismos estilos base */
        :root { --primary-blue: #0056b3; --dark-blue: #003366; --accent: #00d1b2; --bg: #f0f2f5; --white: #ffffff; --text: #2d3436; --sidebar-width: 260px; --navbar-height: 80px; }
        * { margin: 0; padding: 0; box-sizing: border-box; font-family: 'Inter', sans-serif; }
        body { background-color: var(--bg); color: var(--text); height: 100vh; display: flex; flex-direction: column; overflow: hidden; }

        .navbar { height: var(--navbar-height); background: var(--primary-blue); display: flex; align-items: center; padding: 0 2rem; border-bottom: 3px solid var(--accent); }
        .navbar-content { display: flex; align-items: center; gap: 15px; }
        .navbar-logo { height: 50px; width: auto; }
        .navbar-text { font-family: 'Montserrat', sans-serif; font-size: 0.9rem; font-weight: 600; color: white; line-height: 1.2; }

        .app-container { display: flex; flex: 1; overflow: hidden; }
        .sidebar { width: var(--sidebar-width); background: var(--dark-blue); color: white; padding: 2rem 1rem; display: flex; flex-direction: column; gap: 10px; }
        .menu-item { padding: 12px 15px; color: #cbd5e0; text-decoration: none; display: flex; align-items: center; gap: 12px; border-radius: 8px; transition: 0.3s; }
        .menu-item:hover, .menu-item.active { background: rgba(255,255,255,0.1); color: white; }
        .menu-item.active { background: var(--primary-blue); }

        .main-content { flex: 1; overflow-y: auto; padding: 2rem; display: flex; justify-content: center; align-items: flex-start;}
        
        /* Estilo específico del formulario */
        .card-form { background: var(--white); border-radius: 15px; padding: 2rem; box-shadow: 0 5px 15px rgba(0,0,0,0.05); width: 100%; max-width: 600px; }
        .form-group { margin-bottom: 1.2rem; }
        .form-group label { display: block; margin-bottom: 5px; font-weight: 600; font-size: 0.9rem; color: #555; }
        .form-group input, .form-group select { width: 100%; padding: 10px; border: 1px solid #ddd; border-radius: 8px; font-size: 0.95rem; }
        .row-inputs { display: flex; gap: 15px; }
        .row-inputs > div { flex: 1; }
        
        .btn-submit { background: var(--primary-blue); color: white; border: none; padding: 12px; width: 100%; border-radius: 8px; font-weight: 600; cursor: pointer; margin-top: 10px; transition: 0.3s;}
        .btn-submit:hover { background: var(--dark-blue); }
        .btn-cancel { background: #f0f2f5; color: #333; border: 1px solid #ccc; padding: 12px; width: 100%; border-radius: 8px; font-weight: 600; text-align: center; display: block; text-decoration: none; margin-top: 10px;}
    </style>
</head>
<body>
    <?php if($error_db !== ""): ?>
    <script>
        document.addEventListener("DOMContentLoaded", function() {
            Swal.fire({ icon: 'error', title: 'Error de Registro', text: '<?= $error_db ?>' });
        });
    </script>
    <?php endif; ?>

    <nav class="navbar">
        <div class="navbar-content">
            <img src="../assets/seguro.png" alt="Logo Seguro" class="navbar-logo">
            <span class="navbar-text">DEPARTAMENTO DE REGISTRO Y ESTADÍSTICA <br> HOSPITAL DR. RAFAEL GALLARDO</span>
        </div>
    </nav>

    <div class="app-container">
        <aside class="sidebar">
            <div class="menu-item active">
                <i class="fas fa-th-large"></i> Dashboard
            </div>
            <div class="menu-item" onclick="window.location.href='registrar_ingreso.php'">
                <i class="fas fa-user-plus"></i> Registro Ingresos
            </div>
            <a href="gestion_ingresos.php" class="menu-item"><i class="fas fa-list-alt"></i> Historial Ingresos</a>
            <div class="menu-item" onclick="window.location.href='gestion_pacientes.php'">
                <i class="fas fa-search"></i> Gestión Pacientes
            </div>
            <a href="estadisticas.php" class="menu-item"><i class="fas fa-chart-pie"></i> Estadísticas</a>
            <a href="gestion_usuarios.php" class="menu-item"><i class="fas fa-user-shield"></i> Gestión Usuarios</a>
            <div class="menu-item" onclick="window.location.href='bitacora.php'">
                <i class="fas fa-book"></i> Bitácora
            </div>
            
            <div style="margin-top: auto; padding-top: 20px; border-top: 1px solid rgba(255,255,255,0.1);">
                <a href="../auth/logout.php" class="menu-item" style="color: #ff7675; font-weight: 600;">
                    <i class="fas fa-sign-out-alt"></i> Cerrar Sesión
                </a>
            </div>
        </aside>

        <main class="main-content">
            <div class="card-form">
                <h2 style="margin-bottom: 5px; color: var(--dark-blue);">Registro de Personal</h2>
                <p style="color: #666; font-size: 0.85rem; margin-bottom: 20px;">Complete los datos para dar de alta a un nuevo usuario en el sistema.</p>

                <form method="POST">
                    <div class="row-inputs">
                        <div class="form-group">
                            <label>Nombre(s)</label>
                            <input type="text" name="nombre" required>
                        </div>
                        <div class="form-group">
                            <label>Apellido(s)</label>
                            <input type="text" name="apellidos" required>
                        </div>
                    </div>

                    <div class="row-inputs">
                        <div class="form-group">
                            <label>Cédula</label>
                            <input type="text" name="cedula" required>
                        </div>
                        <div class="form-group">
                            <label>Usuario (Username)</label>
                            <input type="text" name="username" required>
                        </div>
                    </div>

                    <div class="form-group">
                        <label>Correo Electrónico</label>
                        <input type="email" name="correo" required>
                    </div>

                    <div class="row-inputs">
                        
                        
                        <div class="form-group">
    <label>Fecha de Nacimiento</label>
    <input type="date" 
           name="fecha_nacimiento" 
           id="fecha_nacimiento" 
           max="<?= date('Y-m-d', strtotime('-18 years')); ?>"
           required>
</div>

                        <div class="form-group">
                            <label>Rol en el Sistema</label>
                            <select name="tipo_usuario" required>
                                <option value="Regular">Regular</option>
                            
                                <option value="Administrador">Administrador</option>
                            </select>
                        </div>
                    </div>

                    <div class="row-inputs" style="margin-top: 15px;">
                        <div style="flex: 2;"><button type="submit" class="btn-submit">Registrar Usuario</button></div>
                        <div style="flex: 1;"><a href="gestion_usuarios.php" class="btn-cancel">Cancelar</a></div>
                    </div>
                </form>
            </div>
        </main>
    </div>
    <script>
document.getElementById('fecha_nacimiento').addEventListener('input', function (e) {
    const value = e.target.value;
    if (value) {
        const parts = value.split('-'); // El formato de input date es YYYY-MM-DD
        const year = parts[0];

        // Si el año tiene más de 4 dígitos, recortarlo
        if (year.length > 4) {
            const correctedYear = year.slice(0, 4);
            e.target.value = correctedYear + '-' + parts[1] + '-' + parts[2];
        }
    }
});
</script>
</body>
</html>