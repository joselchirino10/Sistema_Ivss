<?php

require_once '../auth/sesion.php'; 

validarAcceso('Regular'); 
require_once '../conexion.php';

?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>IVSS - Registro de Ingresos</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;600&family=Montserrat:wght@500;600&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="../estilos.css">
    
   
</head>
<body class="page-registro-ingresos">

    <nav class="navbar">
        <div class="navbar-content">
            <img src="../assets/seguro.png" alt="Logo" class="navbar-logo">
            <span class="navbar-text">
                DEPARTAMENTO DE REGISTRO Y ESTADÍSTICA <br> 
                HOSPITAL DR. RAFAEL GALLARDO - CORO
            </span>
        </div>
    </nav>

    <div class="app-container">
<aside class="sidebar">
            <div class="menu-item" onclick="window.location.href='dashboard_regular.php'">
                <i class="fas fa-th-large"></i> Dashboard
            </div>
            <div class="menu-item active" onclick="window.location.href='registrar_ingreso_regular.php'">
                <i class="fas fa-user-plus"></i> Registro Ingresos
            </div>
            <a href="gestion_ingresos_regular.php" class="menu-item"><i class="fas fa-list-alt"></i> Historial Ingresos</a>
            <div class="menu-item" onclick="window.location.href='gestion_pacientes_regular.php'">
                <i class="fas fa-search"></i> Gestión Pacientes
            </div>
            <a href="estadisticas_regular.php" class="menu-item"><i class="fas fa-chart-pie"></i> Estadísticas</a>
            
            <div style="margin-top: auto; padding-top: 20px; border-top: 1px solid rgba(255,255,255,0.1);">
                <a href="../auth/logout.php" class="menu-item" style="color: #ff7675; font-weight: 600;">
                    <i class="fas fa-sign-out-alt"></i> Cerrar Sesión
                </a>
            </div>
        </aside>

        <main class="main">
            <div class="form-container">
                <div class="form-card">
                    <div class="form-header">
                        <h2><i class="fas fa-address-card"></i> Control de Ingreso</h2>
                    </div>

                    <label class="checkbox-group">
                        <input type="checkbox" id="no_cedulado" onchange="toggleNoCedulado()"> 
                        ¿Paciente No Cedulado?
                    </label>

                    <div id="search-section" class="form-group">
                        <label>Verificar Paciente (Cédula)</label>
                        <div style="display: flex; gap: 10px;">
                            <input type="text" id="ci_busqueda" class="input-control" placeholder="Ej: 28123456" maxlength="9">
                            <button type="button" class="btn-check" onclick="verificarPaciente()">
                                <i class="fas fa-search"></i>
                            </button>
                        </div>
                    </div>

                    <div id="status-msg" class="status-pill"></div>

                    <form id="main-form" class="hidden" action="../api/guardar_ingreso.php" method="POST" ...>
    <!-- Agrega esta línea justo aquí -->
    <input type="hidden" name="id_paciente" id="input_id">
    
    <input type="hidden" name="cedula_paciente" id="hidden_ci">
    <input type="hidden" name="es_nuevo" id="is_new_flag">
                        <input type="hidden" name="cedula_paciente" id="hidden_ci">
                        <input type="hidden" name="es_nuevo" id="is_new_flag">
                        <input type="hidden" name="es_no_cedulado" id="hidden_no_cedulado" value="0">

                        <div id="representative-data" class="rep-section hidden">
                            <h4><i class="fas fa-user-shield"></i> Datos del Representante</h4>
                            <br>
                            <div class="form-group">
                                <label>Cédula del Representante</label>
                                <div style="display: flex; gap: 10px;">
                                    <input type="text" name="cedula_rep" id="input_cedula_rep" class="input-control" maxlength="9" placeholder="Ej: 12345678">
                                    <button type="button" class="btn-check" onclick="verificarRepresentante()">
                                        <i class="fas fa-search"></i>
                                    </button>
                                </div>
                                <div id="rep-status-msg" style="font-size: 0.85rem; margin-top: 5px; font-weight: 600;"></div>
                            </div>
                            
                            <div id="rep-details-section" class="hidden">
                                <div class="row">
                                    <div class="form-group">
                                        <label>Nombres</label>
                                        <input type="text" name="nombres_rep" id="input_nombres_rep" class="input-control" readonly>
                                    </div>
                                    <div class="form-group">
                                        <label>Apellidos</label>
                                        <input type="text" name="apellidos_rep" id="input_apellidos_rep" class="input-control" readonly>
                                    </div>
                                </div>
                            </div>
                            
                            <div id="lista-representados-section" class="form-group hidden" style="margin-top: 15px; padding-top: 15px; border-top: 1px dashed #cbd5e0;">
                                <label><i class="fas fa-child"></i> Seleccionar Menor a Cargo</label>
                                
                                <div class="custom-select-container" id="custom-select-rep">
                                    <div class="custom-select-trigger" onclick="toggleCustomSelect()">
                                        <span id="custom-select-text">Seleccione un representado...</span>
                                        <i class="fas fa-chevron-down custom-arrow"></i>
                                    </div>
                                    
                                    <ul id="custom-select-options" class="custom-options-list hidden">
                                        </ul>
                                </div>

                                <input type="hidden" name="id_representado_existente" id="id_representado_existente" value="">
                            </div>
                        </div> <div id="personal-data" class="hidden">
                            
                            
                            

                            <div class="form-group">
                                <label>Fecha de Nacimiento</label>
                                <input type="date" name="fecha_nacimiento" id="input_fecha" class="input-control" required>
                                <div id="age-msg"></div>
                            </div>

                            <div class="row">
                                <div class="form-group">
                                    <label>Nombres</label>
                                    <input type="text" name="nombres" id="input_nombres" class="input-control" required>
                                </div>
                                <div class="form-group">
                                    <label>Apellidos</label>
                                    <input type="text" name="apellidos" id="input_apellidos" class="input-control" required>
                                </div>
                            </div>
                        </div> <div class="form-group" id="especialidad-container" style="display: none;">
                            <label>Especialidad</label>
                            
                            <input type="text" id="especialidad_fija" class="input-control" value="Pediatría" readonly style="display:none; background-color: #e3f2fd; font-weight: bold; color: #0056b3;">
                            <input type="hidden" name="especialidad_pediatrica" id="hidden_especialidad_pediatrica" value="Pediatría" disabled>

                            <select name="especialidad" id="select_especialidad" class="input-control" required style="display:none;">
                                <option value="" disabled selected hidden>Seleccione especialidad...</option>
                                <?php
                                $query = "SHOW COLUMNS FROM ingresos LIKE 'especialidad'";
                                $resultado = mysqli_query($conexion, $query);
                                if ($resultado) {
                                    $fila = mysqli_fetch_assoc($resultado);
                                    preg_match("/^enum\((.*)\)$/", $fila['Type'], $matches);
                                    $valores = explode(",", $matches[1]);
                                    foreach ($valores as $valor) {
                                        $v = trim($valor, "'");
                                        if($v != "Pediatría") {
                                            echo "<option value='$v'>$v</option>";
                                        }
                                    }
                                }
                                ?>
                            </select>
                        </div>

                        <button type="submit" id="submit-btn" class="btn-submit hidden">
                            <i class="fas fa-save"></i> Registrar Ingreso
                        </button>
                    </form>
                </div>
            </div>
        </main>
    </div>
<script>
        function manejarSeleccionRepresentado() {
            const select = document.getElementById('select_representado');
            const personalData = document.getElementById('personal-data');
            const submitBtn = document.getElementById('submit-btn');
            
            const inputNombres = document.getElementById('input_nombres');
            const inputApellidos = document.getElementById('input_apellidos');
            const inputFecha = document.getElementById('input_fecha');
            const inputIdExistente = document.getElementById('id_representado_existente');
            
            // Mostrar la sección de datos del paciente
            personalData.classList.remove('hidden');
            submitBtn.classList.remove('hidden');
            document.getElementById('especialidad-container').style.display = 'block';

            if (select.value === 'nuevo') {
                // Limpiar campos para un registro nuevo
                inputNombres.value = '';
                inputApellidos.value = '';
                inputFecha.value = '';
                
                // Permitir escribir
                inputNombres.readOnly = false;
                inputApellidos.readOnly = false;
                inputFecha.readOnly = false;
                
                inputIdExistente.value = ''; // Está vacío porque es nuevo
                
            } else if (select.value !== '') {
                // Autocompletar con los datos del menor existente usando los atributos 'data-'
                const opcionSeleccionada = select.options[select.selectedIndex];
                
                inputNombres.value = opcionSeleccionada.getAttribute('data-nombres');
                inputApellidos.value = opcionSeleccionada.getAttribute('data-apellidos');
                inputFecha.value = opcionSeleccionada.getAttribute('data-fecha');
                
                // Bloquear campos para no editar al menor accidentalmente (opcional)
                inputNombres.readOnly = true;
                inputApellidos.readOnly = true;
                inputFecha.readOnly = true;
                
                inputIdExistente.value = select.value; // Guardar el ID del menor
            }
        }
    </script>
    <script src="../api/obtenerPacienteRegular.js?v=3"></script>
</body>
</html>