<?php
require_once '../auth/sesion.php'; 

validarAcceso('Regular'); 
require_once '../conexion.php';

// Inicializar variables para los filtros
$filtro_fecha = isset($_GET['fecha']) ? mysqli_real_escape_string($conexion, $_GET['fecha']) : '';
$filtro_especialidad = isset($_GET['especialidad']) ? mysqli_real_escape_string($conexion, $_GET['especialidad']) : '';
$filtro_paciente = isset($_GET['paciente']) ? mysqli_real_escape_string($conexion, $_GET['paciente']) : '';

// Construir la consulta SQL dinámicamente según los filtros aplicados
$sql = "SELECT i.id AS ingreso_id, p.nombres, p.apellidos, p.cedula, p.tipo, i.fecha_consulta, i.tipo_paciente, i.especialidad 
        FROM ingresos i
        INNER JOIN pacientes p ON i.paciente_id = p.id
        WHERE 1=1";

if (!empty($filtro_fecha)) {
    $sql .= " AND i.fecha_consulta = '$filtro_fecha'";
}
if (!empty($filtro_especialidad)) {
    $sql .= " AND i.especialidad = '$filtro_especialidad'";
}
if (!empty($filtro_paciente)) {
    $sql .= " AND (p.nombres LIKE '%$filtro_paciente%' OR p.apellidos LIKE '%$filtro_paciente%' OR p.cedula LIKE '%$filtro_paciente%')";
}

// Ordenar por los más recientes primero
$sql .= " ORDER BY i.fecha_consulta DESC, i.id DESC";

$resultado = mysqli_query($conexion, $sql);
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>IVSS - Historial de Ingresos</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;600&family=Montserrat:wght@500;600&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="../estilos.css">
    
</head>
<body class="page-historial-ingresos">

    <nav class="navbar">
        <div class="navbar-content">
            <img src="../assets/seguro.png" alt="Logo" class="navbar-logo" onerror="this.src='https://via.placeholder.com/55?text=IVSS'">
            <span class="navbar-text">
                DEPARTAMENTO DE REGISTRO Y ESTADÍSTICA <br> 
                HOSPITAL DR. RAFAEL GALLARDO - CORO
            </span>
        </div>
    </nav>

    <div class="app-container">
        
         <aside class="sidebar">
            <div class="menu-item" onclick="window.location.href='dashboard_regular.php'">
                <i class="fas fa-th-large"></i> Dashboard
            </div>
            <div class="menu-item" onclick="window.location.href='registrar_ingreso_regular.php'">
                <i class="fas fa-user-plus"></i> Registro Ingresos
            </div>
            <a href="gestion_ingresos_regular.php" class="menu-item active"><i class="fas fa-list-alt"></i> Historial Ingresos</a>
            <div class="menu-item" onclick="window.location.href='gestion_pacientes_regular.php'">
                <i class="fas fa-search"></i> Gestión Pacientes
            </div>
            <a href="estadisticas_regular.php" class="menu-item"><i class="fas fa-chart-pie"></i> Estadísticas</a>
            
            <div style="margin-top: auto; padding-top: 20px; border-top: 1px solid rgba(255,255,255,0.1);">
                <a href="../auth/logout.php" class="menu-item" style="color: #ff7675; font-weight: 600;">
                    <i class="fas fa-sign-out-alt"></i> Cerrar Sesión
                </a>
            </div>
        </aside>

        <main class="main">
            <div class="search-container">
                <div class="filter-box">
                    <h2><i class="fas fa-filter"></i> Filtrar Ingresos</h2>
                    
                    <form method="GET" action="gestion_ingresos.php" class="filter-form">
                        <div class="form-group">
                            <label>Fecha de Consulta</label>
                            <input type="date" name="fecha" class="input-control" value="<?php echo htmlspecialchars($filtro_fecha); ?>">
                        </div>
                        
                        <div class="form-group">
                            <label>Especialidad</label>
                            <select name="especialidad" class="input-control">
                                <option value="">Todas las especialidades</option>
                                <?php
                                $especialidades = ['Neumonología','Pediatría','Cardiología','Nefrología','Medicina Interna','Traumatología','Dermatología'];
                                foreach ($especialidades as $esp) {
                                    $selected = ($filtro_especialidad == $esp) ? 'selected' : '';
                                    echo "<option value=\"$esp\" $selected>$esp</option>";
                                }
                                ?>
                            </select>
                        </div>

                        <div class="form-group">
                            <label>Paciente (Cédula o Nombre)</label>
                            <input type="text" name="paciente" class="input-control" placeholder="Ej. 30401423 o Zarraga" value="<?php echo htmlspecialchars($filtro_paciente); ?>">
                        </div>

                        <button type="submit" class="btn-search"><i class="fas fa-search"></i> Filtrar</button>
                        <a href="gestion_ingresos.php" class="btn-reset"><i class="fas fa-times"></i> Limpiar</a>
                    </form>
                </div>
            </div>

            <div class="search-container" style="margin-top: 0;">
                <div class="table-section">
                    <?php if (mysqli_num_rows($resultado) > 0): ?>
                        <table>
                           <thead>
    <tr>
        <th>ID Ingreso</th>
        <th>Fecha</th>
        <th>Paciente</th>
        <th>Cédula</th>
        <th>Tipo Paciente</th>
        <th>Especialidad</th>
        <th>Acciones</th> </tr>
</thead>
<tbody>
    <?php while ($row = mysqli_fetch_assoc($resultado)): 
        $clase_tipo = ($row['tipo_paciente'] == 'Nuevo') ? 'badge-nuevo' : 'badge-existente';
        $cedula_mostrar = !empty($row['cedula']) ? $row['cedula'] : 'N/A (' . $row['tipo'] . ')';
        $especialidad_mostrar = !empty($row['especialidad']) ? $row['especialidad'] : 'No asignada';
    ?>
        <tr>
            <td><strong>#<?php echo $row['ingreso_id']; ?></strong></td>
            <td><?php echo date('d/m/Y', strtotime($row['fecha_consulta'])); ?></td>
            <td><?php echo htmlspecialchars($row['nombres'] . ' ' . $row['apellidos']); ?></td>
            <td><?php echo $cedula_mostrar; ?></td>
            <td><span class="badge <?php echo $clase_tipo; ?>"><?php echo $row['tipo_paciente']; ?></span></td>
            <td>
                <?php if($especialidad_mostrar != 'No asignada'): ?>
                    <span class="badge badge-especialidad"><?php echo $especialidad_mostrar; ?></span>
                <?php else: ?>
                    <span style="color: #95a5a6; font-size: 0.85rem;">No asignada</span>
                <?php endif; ?>
            </td>
            <td>
                <button type="button" class="btn-delete" onclick="eliminarIngreso(<?php echo $row['ingreso_id']; ?>)" title="Eliminar Ingreso">
                    <i class="fas fa-trash-alt"></i>
                </button>
            </td>
        </tr>
    <?php endwhile; ?>
</tbody>
                        </table>
                    <?php else: ?>
                        <div class="empty-state">
                            <i class="fas fa-folder-open" style="font-size: 3rem; color: #bdc3c7; margin-bottom: 1rem;"></i>
                            <h3>No se encontraron registros</h3>
                            <p>No hay ingresos que coincidan con los filtros aplicados en este momento.</p>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </main>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<script>
function eliminarIngreso(idIngreso) {
    Swal.fire({
        title: '¿Estás segura/o?',
        text: "Se eliminará el registro de ingreso #" + idIngreso + ". ¡Esta acción no se puede deshacer!",
        icon: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#e74c3c',
        cancelButtonColor: '#7f8c8d',
        confirmButtonText: 'Sí, eliminar',
        cancelButtonText: 'Cancelar',
        heightAuto: false
    }).then((result) => {
        if (result.isConfirmed) {
            
            Swal.fire({
                title: 'Eliminando...',
                allowOutsideClick: false,
                heightAuto: false,
                didOpen: () => { Swal.showLoading(); }
            });

            fetch('../api/eliminar_ingreso.php', {
                method: 'POST',
                headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                body: `id=${idIngreso}`
            })
            .then(response => response.json())
            .then(data => {
                if (data.status === 'success') {
                    Swal.fire({
                        title: '¡Eliminado!',
                        text: 'El registro de ingreso ha sido borrado.',
                        icon: 'success',
                        heightAuto: false
                    }).then(() => {
                        window.location.reload(); // Recarga la página para actualizar la tabla
                    });
                } else {
                    Swal.fire('Error', data.message, 'error');
                }
            })
            .catch(error => {
                console.error('Error:', error);
                Swal.fire('Error', 'Hubo un problema de comunicación con el servidor.', 'error');
            });
        }
    });
}
</script>
</body>
</html>