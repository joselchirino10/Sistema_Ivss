<?php
require_once '../auth/sesion.php'; 
require_once '../conexion.php';

validarAcceso('Regular'); 
$nombreUsuario = isset($_SESSION['nombre']) ? $_SESSION['nombre'] : 'Usuario';

try {
    // Ya no hacemos "new PDO" aquí porque conexion.php ya nos trae la variable $pdo lista para usar.

    // 1. Total de Pacientes Registrados (Histórico)
    $totalPacientes = $pdo->query("SELECT COUNT(*) FROM pacientes")->fetchColumn();

    // 2. Ingresos realizados HOY
    $atendidosHoy = $pdo->query("SELECT COUNT(*) FROM ingresos WHERE DATE(fecha_consulta) = CURDATE()")->fetchColumn();

    // 3. Usuarios activos en el sistema
    $usuariosActivos = $pdo->query("SELECT COUNT(*) FROM usuarios_sistema WHERE estado = 'activo'")->fetchColumn();

    // 4. ESTADÍSTICAS DEL GRÁFICO: Solo ingresos de HOY
    $queryStats = $pdo->query("SELECT tipo_paciente, COUNT(*) as cantidad 
                               FROM ingresos 
                               WHERE DATE(fecha_consulta) = CURDATE() 
                               GROUP BY tipo_paciente");
    $statsData = $queryStats->fetchAll();

    $labels = [];
    $counts = [];
    foreach($statsData as $stat) {
        $labels[] = $stat['tipo_paciente']; 
        $counts[] = $stat['cantidad'];
    }

    // Si no hay datos hoy, enviamos un array vacío para que el JS lo maneje
    $jsonLabels = json_encode($labels);
    $jsonCounts = json_encode($counts);

} catch (\PDOException $e) {
     die("Error de base de datos: " . $e->getMessage());
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>IVSS - Dashboard Diario</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;600&family=Montserrat:wght@500;600&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <link rel="stylesheet" href="../estilos.css">
</head>
<body class="page-dashboard">

    <nav class="navbar">
        <div class="navbar-content">
            <img src="../assets/seguro.png" alt="Logo Seguro" class="navbar-logo">
            <span class="navbar-text">
                DEPARTAMENTO DE REGISTRO Y ESTADÍSTICA <br> 
                HOSPITAL DR. RAFAEL GALLARDO - CORO
            </span>
        </div>
    </nav>

    <div class="app-container">
        <aside class="sidebar">
            <div class="menu-item active">
                <i class="fas fa-th-large"></i> Dashboard
            </div>
            <div class="menu-item" onclick="window.location.href='registrar_ingreso_regular.php'">
                <i class="fas fa-user-plus"></i> Registro Ingresos
            </div>
            <a href="gestion_ingresos_regular.php" class="menu-item"><i class="fas fa-list-alt"></i> Historial Ingresos</a>
            <div class="menu-item" onclick="window.location.href='gestion_pacientes_regular.php'">
                <i class="fas fa-search"></i> Gestión Pacientes
            </div>
            <a href="estadisticas_regular.php" class="menu-item"><i class="fas fa-chart-pie"></i> Estadísticas</a>
            
            <div style="margin-top: auto; padding-top: 20px; border-top: 1px solid rgba(255,255,255,0.1);">
                <a href="../auth/logout.php" class="menu-item" style="color: #ff7675; font-weight: 600;">
                    <i class="fas fa-sign-out-alt"></i> Cerrar Sesión
                </a>
            </div>
        </aside>

        <main class="main">
            <header class="topbar">
                <div style="font-weight: 600;">Resumen Diario Hospitalario</div>
                <div class="user-profile" style="display: flex; align-items: center; gap: 10px;">
    <span style="font-size: 0.9rem;">Hola, <?php echo htmlspecialchars($nombreUsuario); ?></span>
    <img src="https://ui-avatars.com/api/?name=<?php echo urlencode($nombreUsuario); ?>&background=0056b3&color=fff" style="width: 35px; border-radius: 8px;">
</div>
            </header>

            <div class="container">
                
                
                <div class="stats-grid">
                    <div class="stat-card">
                        <div class="icon-box" style="background: #e3f2fd; color: #0056b3;"><i class="fas fa-users"></i></div>
                        <div><h3><?php echo $totalPacientes; ?></h3><p style="color: #7f8c8d; font-size: 0.85rem;">Pacientes Globales</p></div>
                    </div>
                    <div class="stat-card" style="border-left-color: #2e7d32;">
                        <div class="icon-box" style="background: #e8f5e9; color: #2e7d32;"><i class="fas fa-calendar-day"></i></div>
                        <div><h3><?php echo $atendidosHoy; ?></h3><p style="color: #7f8c8d; font-size: 0.85rem;">Ingresos de Hoy</p></div>
                    </div>
                    <div class="stat-card">
                        <div class="icon-box" style="background: #f1f2f6; color: var(--dark-blue);"><i class="fas fa-user-check"></i></div>
                        <div><h3><?php echo $usuariosActivos; ?></h3><p style="color: #7f8c8d; font-size: 0.85rem;">Usuarios del Sistema</p></div>
                    </div>
                </div>

                <div class="dashboard-row">
                    <section class="card-section">
                        <h3 style="margin-bottom: 0.5rem; font-size: 1.1rem; color: var(--dark-blue);">Distribución de Ingresos (Hoy)</h3>
                        <p style="font-size: 0.8rem; color: #7f8c8d; margin-bottom: 1.5rem;">Relación de pacientes nuevos vs. sucesivos del día actual.</p>
                        
                        <div style="max-width: 280px; margin: 0 auto; position: relative;">
                            <?php if ($atendidosHoy > 0): ?>
                                <canvas id="chartIngresosHoy"></canvas>
                            <?php else: ?>
                                <div style="height: 280px; display: flex; align-items: center; justify-content: center; text-align: center; color: #bdc3c7;">
                                    <p><i class="fas fa-chart-pie fa-3x" style="margin-bottom: 10px; display: block;"></i> No hay ingresos registrados <br> todavía el día de hoy.</p>
                                </div>
                            <?php endif; ?>
                        </div>
                    </section>

                    <section class="card-section" style="background: var(--dark-blue); color: white;">
                        <h3 style="color: white; margin-bottom: 1.2rem;"><i class="fas fa-id-card"></i> Consultar Expediente</h3>
                        <div class="search-container">
                            <label style="font-size: 0.85rem; color: #cbd5e0;">Cédula del Paciente:</label>
                            <input type="text" id="inputCedula" placeholder="Ej: 12345678" class="search-input">
                            <button onclick="buscarExpediente()" class="search-btn">OBTENER ID</button>
                            
                            <div id="resultadoBusqueda" style="margin-top: 20px; padding: 20px; background: rgba(255,255,255,0.05); border: 1px dashed rgba(255,255,255,0.2); border-radius: 12px; text-align: center; display: none;">
                                <span style="display: block; font-size: 0.8rem; color: #cbd5e0; margin-bottom: 5px;">ID DE EXPEDIENTE</span>
                                <strong id="idExpediente" style="font-size: 2.2rem; color: var(--accent);">---</strong>
                            </div>
                        </div>
                    </section>
                </div>
            </div>
        </main>
    </div>

    <script>
        // Solo inicializar el gráfico si hay datos hoy
        <?php if ($atendidosHoy > 0): ?>
        const ctx = document.getElementById('chartIngresosHoy').getContext('2d');
        new Chart(ctx, {
            type: 'doughnut',
            data: {
                labels: <?php echo $jsonLabels; ?>,
                datasets: [{
                    data: <?php echo $jsonCounts; ?>,
                    backgroundColor: ['#00d1b2', '#0056b3', '#9b59b6'],
                    hoverOffset: 15,
                    borderWidth: 0
                }]
            },
            options: {
                responsive: true,
                plugins: {
                    legend: {
                        position: 'bottom',
                        labels: { font: { family: 'Inter', size: 12 } }
                    }
                },
                cutout: '75%'
            }
        });
        <?php endif; ?>

        function buscarExpediente() {
            const cedula = document.getElementById('inputCedula').value;
            const resDiv = document.getElementById('resultadoBusqueda');
            const resId = document.getElementById('idExpediente');

            if(cedula.trim() === "") return alert("Ingrese cédula");

            fetch(`../api/buscar_id_regular.php?cedula=${encodeURIComponent(cedula)}`)
                .then(response => response.json())
                .then(data => {
                    resDiv.style.display = 'block';
                    if(data.success) {
                        resId.innerText = data.id;
                        resId.style.color = "var(--accent)";
                    } else {
                        resId.innerText = "X";
                        resId.style.color = "#ff7675";
                        alert("Paciente no encontrado.");
                    }
                })
                .catch(err => alert("Error de servidor"));
        }
    </script>
</body>
</html>