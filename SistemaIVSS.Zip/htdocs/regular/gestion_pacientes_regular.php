<?php
require_once '../auth/sesion.php'; 

validarAcceso('Regular'); 
require_once '../conexion.php';
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>IVSS - Gestion Pacientes</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;600&family=Montserrat:wght@500;600&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="../estilos.css">
    
</head>
<body class="page-gestion-pacientes">

    <nav class="navbar">
        <div class="navbar-content">
            <img src="../assets/seguro.png" alt="Logo" class="navbar-logo" onerror="this.src='https://via.placeholder.com/55?text=IVSS'">
            <span class="navbar-text">
                DEPARTAMENTO DE REGISTRO Y ESTADÍSTICA <br> 
                HOSPITAL DR. RAFAEL GALLARDO - CORO
            </span>
        </div>
    </nav>

    <div class="app-container">
        
       <div class="app-container">
       <aside class="sidebar">
            <div class="menu-item"  onclick="window.location.href='dashboard_regular.php'">
                <i class="fas fa-th-large"></i> Dashboard
            </div>
            <div class="menu-item" onclick="window.location.href='registrar_ingreso_regular.php'">
                <i class="fas fa-user-plus"></i> Registro Ingresos
            </div>
            <a href="gestion_ingresos_regular.php" class="menu-item"><i class="fas fa-list-alt"></i> Historial Ingresos</a>
            <div class="menu-item active">
                <i class="fas fa-search"></i> Gestión Pacientes
            </div>
            <a href="estadisticas_regular.php" class="menu-item"><i class="fas fa-chart-pie"></i> Estadísticas</a>
            
            <div style="margin-top: auto; padding-top: 20px; border-top: 1px solid rgba(255,255,255,0.1);">
                <a href="../auth/logout.php" class="menu-item" style="color: #ff7675; font-weight: 600;">
                    <i class="fas fa-sign-out-alt"></i> Cerrar Sesión
                </a>
            </div>
        </aside>

        <main class="main">
            <div class="search-container">
                <div class="search-box">
                    <h2><i class="fas fa-file-medical"></i> Consulta de Pacientes e Historial</h2>
                    
                    <label class="checkbox-group">
                        <input type="checkbox" id="check_no_cedulado"> 
                        ¿Paciente No Cedulado? (Buscar por Cédula del Representante)
                    </label>

                    <div class="input-group">
                        <input type="text" id="busqueda" class="input-control" placeholder="Ingrese número de cédula..." maxlength="10">
                        <button onclick="realizarBusqueda()" class="btn-search">
                            <i class="fas fa-search"></i> Buscar
                        </button>
                    </div>
                </div>

                <div id="resultados-area"></div>
            </div>
        </main>
    </div>

    <script>
    function realizarBusqueda() {
        const valor = document.getElementById('busqueda').value.trim();
        const esNoCedulado = document.getElementById('check_no_cedulado').checked ? 1 : 0;
        const resultadosArea = document.getElementById('resultados-area');

        if(valor === "") {
            alert("Por favor ingrese un número de cédula válido.");
            return;
        }

        // Mostramos un mensaje de carga mientras responde el servidor
        resultadosArea.innerHTML = "<p style='text-align:center; margin-top: 20px; color: var(--primary-blue);'><i class='fas fa-spinner fa-spin'></i> Buscando información...</p>";

        fetch('../api/procesar_busqueda_regular.php', {
            method: 'POST',
            headers: {'Content-Type': 'application/x-www-form-urlencoded'},
            body: `valor=${encodeURIComponent(valor)}&es_no_cedulado=${esNoCedulado}`
        })
        .then(response => response.text())
        .then(data => {
            resultadosArea.innerHTML = data;
        })
        .catch(error => {
            console.error('Error:', error);
            resultadosArea.innerHTML = "<p style='color:red; text-align:center;'>Ocurrió un error al realizar la búsqueda.</p>";
        });
    }

    // Permitir buscar presionando la tecla Enter
    document.getElementById('busqueda').addEventListener('keypress', function (e) {
        if (e.key === 'Enter') {
            realizarBusqueda();
        }
    });
    </script>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

<script>
document.addEventListener('DOMContentLoaded', function() {
    // Buscamos parámetros en la URL
    const urlParams = new URLSearchParams(window.location.search);
    
    // Si el parámetro 'status' es igual a 'success_registro'
    if (urlParams.get('status') === 'success_registro') {
        Swal.fire({
            title: '¡Registro Exitoso!',
            text: 'El ingreso del paciente ha sido guardado correctamente.',
            icon: 'success',
            confirmButtonColor: '#0056b3',
            heightAuto: false // Esto evita que se mueva tu sidebar
        });
        
        // Limpiamos la URL (quita el ?status=... de la barra de direcciones)
        window.history.replaceState({}, document.title, "gestion_pacientes_regular.php");
    }
});
</script>
</body>
</html>