// --- 1. VALIDACIONES DE TECLADO ---
function soloLetras(e) {
    const key = e.keyCode || e.which;
    const tecla = String.fromCharCode(key).toLowerCase();
    const letras = " áéíóúabcdefghijklmnñopqrstuvwxyz";
    if (letras.indexOf(tecla) === -1) e.preventDefault();
}

function soloNumeros(e) {
    const key = e.keyCode || e.which;
    const tecla = String.fromCharCode(key);
    const numeros = "0123456789";
    if (numeros.indexOf(tecla) === -1) e.preventDefault();
}

// --- 2. LÓGICA DE EDAD Y ESPECIALIDAD ---
function procesarCambioEdad() {
    const campoFecha = document.getElementById('input_fecha');
    const container = document.getElementById('especialidad-container');
    const select = document.getElementById('select_especialidad');
    const fija = document.getElementById('especialidad_fija');
    const hiddenPed = document.getElementById('hidden_especialidad_pediatrica');
    const msg = document.getElementById('age-msg');
    const submitBtn = document.getElementById('submit-btn'); 

    if (!campoFecha || !campoFecha.value) {
        if (msg) msg.innerText = "";
        if (container) container.style.display = "none";
        if (submitBtn) submitBtn.classList.add('hidden');
        return;
    }

    const fechaNac = new Date(campoFecha.value);
    const hoy = new Date();
    if (isNaN(fechaNac.getTime())) return;

    if (container) container.style.display = "block";
    if (submitBtn) submitBtn.classList.remove('hidden');

    let meses = (hoy.getFullYear() - fechaNac.getFullYear()) * 12;
    meses -= fechaNac.getMonth();
    meses += hoy.getMonth();

    const limiteMeses = 131; // 10 años y 11 meses

    if (meses <= limiteMeses) {
        if (fija) fija.style.display = "block";
        if (select) {
            select.style.display = "none";
            select.required = false;
        }
        if (hiddenPed) hiddenPed.disabled = false;
        
        if(msg) {
            msg.innerText = "Paciente Pediátrico.";
            msg.style.color = "#d63031";
        }
    } else {
        if (fija) fija.style.display = "none";
        if (select) {
            select.style.display = "block";
            select.required = true;
        }
        if (hiddenPed) hiddenPed.disabled = true;
        
        if(msg) {
            msg.innerText = "Paciente Adulto.";
            msg.style.color = "#00b894";
        }
    }
}

// --- 3. BÚSQUEDA DE PACIENTE ---
async function verificarPaciente() {
    const ci = document.getElementById('ci_busqueda').value;
    const msg = document.getElementById('status-msg');
    const form = document.getElementById('main-form');
    const personalData = document.getElementById('personal-data');
    const isNewFlag = document.getElementById('is_new_flag');
    const hiddenCi = document.getElementById('hidden_ci');
    
    const inNom = document.getElementById('input_nombres');
    const inApe = document.getElementById('input_apellidos');
    const inFec = document.getElementById('input_fecha');

    if (!ci) {
        alert("Ingrese la cédula para continuar.");
        return;
    }

    hiddenCi.value = ci; // ASIGNACIÓN INMEDIATA

    msg.style.display = "block";
    msg.className = "status-pill";
    msg.innerHTML = '<span style="color: #0056b3;">Buscando... <i class="fas fa-spinner fa-spin"></i></span>';

    try {
        const response = await fetch(`../api/obtener_paciente.php?cedula=${ci}`);
        const data = await response.json();

        form.classList.remove('hidden');
        form.style.display = 'block';
        personalData.classList.remove('hidden');

        if (data.existe) {
            msg.className = "status-pill msg-success";
            msg.innerHTML = `<i class="fas fa-check-circle"></i> Paciente Registrado.`;
            isNewFlag.value = "0";

            inNom.value = data.datos.nombres;
            inApe.value = data.datos.apellidos;
            inFec.value = data.datos.fecha_nacimiento;

            inNom.readOnly = inApe.readOnly = inFec.readOnly = true;
            inNom.style.backgroundColor = inApe.style.backgroundColor = inFec.style.backgroundColor = "#e1e8ed";
        } else {
            msg.className = "status-pill msg-new";
            msg.innerHTML = `<i class="fas fa-user-plus"></i> Paciente no registrado. Complete los datos.`;
            isNewFlag.value = "1";
            
            inNom.value = ""; inApe.value = ""; inFec.value = "";
            inNom.readOnly = inApe.readOnly = inFec.readOnly = false;
            inNom.style.backgroundColor = inApe.style.backgroundColor = inFec.style.backgroundColor = "#ffffff";
        }

        procesarCambioEdad();

    } catch (error) {
        console.error('Error:', error);
        msg.innerHTML = '<span style="color: #e74c3c;">Error de conexión.</span>';
    }
}

// --- 4. GESTIÓN DE PACIENTE NO CEDULADO ---
function toggleNoCedulado() {
    const isChecked = document.getElementById('no_cedulado').checked;
    const searchSection = document.getElementById('search-section');
    const mainForm = document.getElementById('main-form');
    const repData = document.getElementById('representative-data');
    const hiddenNoCedulado = document.getElementById('hidden_no_cedulado');
    const hiddenCi = document.getElementById('hidden_ci');

    mainForm.reset();
    closeCustomSelect();

    if (isChecked) {
        searchSection.classList.add('hidden');
        mainForm.classList.remove('hidden');
        repData.classList.remove('hidden');
        hiddenNoCedulado.value = "1";
        hiddenCi.value = "S/C"; // "Sin Cédula" para que el PHP no lo reciba vacío
    } else {
        searchSection.classList.remove('hidden');
        mainForm.classList.add('hidden');
        repData.classList.add('hidden');
        hiddenNoCedulado.value = "0";
        hiddenCi.value = ""; 
    }
}

// --- 5. SELECTOR PERSONALIZADO (CUSTOM SELECT) ---
function toggleCustomSelect() {
    const list = document.getElementById('custom-select-options');
    list.classList.toggle('hidden');
}

function closeCustomSelect() {
    const list = document.getElementById('custom-select-options');
    if(list) list.classList.add('hidden');
}

function seleccionarRepresentadoVisual(element, idPaciente, nombres, apellidos, fechaNacimiento) {
    const triggerText = document.getElementById('custom-select-text');
    const hiddenInputId = document.getElementById('id_representado_existente');
    const inNom = document.getElementById('input_nombres');
    const inApe = document.getElementById('input_apellidos');
    const inFec = document.getElementById('input_fecha');

    hiddenInputId.value = idPaciente;
    triggerText.innerText = `${nombres} ${apellidos}`;
    closeCustomSelect();

    document.getElementById('personal-data').classList.remove('hidden');
    document.getElementById('submit-btn').classList.remove('hidden');
    document.getElementById('especialidad-container').style.display = 'block';

    if (idPaciente === 'nuevo') {
        triggerText.innerHTML = 'NUEVO REPRESENTADO';
        inNom.value = inApe.value = inFec.value = '';
        inNom.readOnly = inApe.readOnly = inFec.readOnly = false;
        inNom.style.backgroundColor = inApe.style.backgroundColor = inFec.style.backgroundColor = "#ffffff";
    } else {
        inNom.value = nombres; inApe.value = apellidos; inFec.value = fechaNacimiento;
        inNom.readOnly = inApe.readOnly = inFec.readOnly = true;
        inNom.style.backgroundColor = inApe.style.backgroundColor = inFec.style.backgroundColor = "#e1e8ed";
    }
    procesarCambioEdad();
}

// --- 6. VERIFICAR REPRESENTANTE ---
function verificarRepresentante() {
    const cedulaRep = document.getElementById('input_cedula_rep').value.trim();
    const statusMsg = document.getElementById('rep-status-msg');
    const inNomRep = document.getElementById('input_nombres_rep');
    const inApeRep = document.getElementById('input_apellidos_rep');
    const seccionRepresentados = document.getElementById('lista-representados-section');
    const listaVisualUl = document.getElementById('custom-select-options');

    if (!cedulaRep) return;

    fetch('../api/buscar_representante.php?cedula=' + encodeURIComponent(cedulaRep))
        .then(response => response.json())
        .then(data => {
            document.getElementById('rep-details-section').classList.remove('hidden');
            
            if (data.existe) {
                inNomRep.value = data.nombres;
                inApeRep.value = data.apellidos;
                inNomRep.readOnly = inApeRep.readOnly = true;
                inNomRep.style.backgroundColor = inApeRep.style.backgroundColor = "#e1e8ed";
                
                listaVisualUl.innerHTML = '';
                if (data.representados && data.representados.length > 0) {
                    data.representados.forEach(menor => {
                        let li = document.createElement('li');
                        li.className = 'custom-option';
                        li.innerHTML = `<i class="fas fa-child"></i> ${menor.nombres} ${menor.apellidos}`;
                        li.onclick = () => seleccionarRepresentadoVisual(li, menor.id_paciente, menor.nombres, menor.apellidos, menor.fecha_nacimiento);
                        listaVisualUl.appendChild(li);
                    });
                }
                
                let liNuevo = document.createElement('li');
                liNuevo.className = 'custom-option option-nuevo';
                liNuevo.innerHTML = `+ Añadir nuevo`;
                liNuevo.onclick = () => seleccionarRepresentadoVisual(liNuevo, 'nuevo', '', '', '');
                listaVisualUl.appendChild(liNuevo);
                
                seccionRepresentados.classList.remove('hidden');
            } else {
                inNomRep.value = inApeRep.value = '';
                inNomRep.readOnly = inApeRep.readOnly = false;
                inNomRep.style.backgroundColor = inApeRep.style.backgroundColor = "#ffffff";
                document.getElementById('personal-data').classList.remove('hidden');
                document.getElementById('submit-btn').classList.remove('hidden');
            }
        });
}

// --- 7. INICIALIZACIÓN Y VALIDACIÓN FINAL ---
document.addEventListener('DOMContentLoaded', () => {
    const form = document.getElementById('main-form');
    
    // VALIDACIÓN CRÍTICA ANTES DE ENVIAR
    form.addEventListener('submit', (e) => {
        const isNoCedulado = document.getElementById('no_cedulado').checked;
        const hiddenCi = document.getElementById('hidden_ci');
        const ciBusqueda = document.getElementById('ci_busqueda').value;

        if (!isNoCedulado) {
            hiddenCi.value = ciBusqueda; // Aseguramos que viaje la cédula buscada
        }

        if (!hiddenCi.value) {
            e.preventDefault();
            alert("Error: La cédula del paciente no puede estar vacía.");
        }
    });

    // Listeners existentes
    document.getElementById('input_fecha')?.addEventListener('change', procesarCambioEdad);
    
    ['input_nombres', 'input_apellidos', 'input_nombres_rep', 'input_apellidos_rep'].forEach(id => {
        document.getElementById(id)?.addEventListener('keypress', soloLetras);
    });

    ['ci_busqueda', 'input_cedula_rep'].forEach(id => {
        document.getElementById(id)?.addEventListener('keypress', soloNumeros);
    });
});