
// --- 1. VALIDACIONES DE TECLADO ---
function soloLetras(e) {
    const key = e.keyCode || e.which;
    const tecla = String.fromCharCode(key).toLowerCase();
    const letras = " áéíóúabcdefghijklmnñopqrstuvwxyz";
    if (letras.indexOf(tecla) === -1) e.preventDefault();
}

function soloNumeros(e) {
    const key = e.keyCode || e.which;
    const tecla = String.fromCharCode(key);
    const numeros = "0123456789";
    if (numeros.indexOf(tecla) === -1) e.preventDefault();
}

// --- 2. LÓGICA DE EDAD Y ESPECIALIDAD ---
function procesarCambioEdad() {
    const campoFecha = document.getElementById('input_fecha');
    const container = document.getElementById('especialidad-container');
    const select = document.getElementById('select_especialidad');
    const fija = document.getElementById('especialidad_fija');
    const hiddenPed = document.getElementById('hidden_especialidad_pediatrica');
    const msg = document.getElementById('age-msg');
    const submitBtn = document.getElementById('submit-btn'); 

    if (!campoFecha || !campoFecha.value) {
        if (msg) msg.innerText = "";
        if (container) container.style.display = "none";
        if (submitBtn) submitBtn.classList.add('hidden');
        return;
    }

    const fechaNac = new Date(campoFecha.value);
    const hoy = new Date();
    if (isNaN(fechaNac.getTime())) return;

    if (container) container.style.display = "block";
    if (submitBtn) submitBtn.classList.remove('hidden');

    let meses = (hoy.getFullYear() - fechaNac.getFullYear()) * 12;
    meses -= fechaNac.getMonth();
    meses += hoy.getMonth();

    const limiteMeses = 131; // 10 años y 11 meses

    if (meses <= limiteMeses) {
        // --- CASO PEDIÁTRICO ---
        if (fija) fija.style.display = "block";
        if (select) {
            select.style.display = "none";
            select.required = false;
        }
        if (hiddenPed) hiddenPed.disabled = false;
        
        if(msg) {
            msg.innerText = "Paciente Pediátrico.";
            msg.style.color = "#d63031";
        }
    } else {
        // --- CASO ADULTO ---
        if (fija) fija.style.display = "none";
        if (select) {
            select.style.display = "block";
            select.required = true;
        }
        if (hiddenPed) hiddenPed.disabled = true;
        
        if(msg) {
            msg.innerText = "Paciente Adulto.";
            msg.style.color = "#00b894";
        }
    }
}

// --- 3. BÚSQUEDA DE PACIENTE ADULTO (FETCH API) ---
async function verificarPaciente() {
    const ci = document.getElementById('ci_busqueda').value;
    const msg = document.getElementById('status-msg');
    const form = document.getElementById('main-form');
    const personalData = document.getElementById('personal-data');
    const isNewFlag = document.getElementById('is_new_flag');
    const hiddenCi = document.getElementById('hidden_ci');
    
    const inId = document.getElementById('input_id');
    const inNom = document.getElementById('input_nombres');
    const inApe = document.getElementById('input_apellidos');
    const inFec = document.getElementById('input_fecha');

    if (!ci) {
        alert("Ingrese la cédula para continuar.");
        return;
    }

    form.classList.add('hidden');
    personalData.classList.add('hidden');
    document.getElementById('especialidad-container').style.display = 'none';
    document.getElementById('submit-btn').classList.add('hidden');
    
    msg.style.display = "block";
    msg.className = "status-pill";
    msg.innerHTML = '<span style="color: #0056b3;">Buscando paciente... <i class="fas fa-spinner fa-spin"></i></span>';

    try {
        const response = await fetch(`../api/obtener_paciente_regular.php?cedula=${ci}`);
        const data = await response.json();

        form.classList.remove('hidden');
        personalData.classList.remove('hidden'); 
        hiddenCi.value = ci;

        if (data.existe) {
            msg.className = "status-pill msg-success";
            msg.innerHTML = `<i class="fas fa-check-circle"></i> Paciente Registrado.`;
            isNewFlag.value = "0";

            inId.value = data.datos.id;
            inNom.value = data.datos.nombres;
            inApe.value = data.datos.apellidos;
            inFec.value = data.datos.fecha_nacimiento;

            inNom.readOnly = true;
            inApe.readOnly = true;
            inFec.readOnly = true;
        } else {
            msg.className = "status-pill msg-new";
            msg.innerHTML = `<i class="fas fa-user-plus"></i> El paciente no está registrado. Ingrese los datos personales.`;
            isNewFlag.value = "1";
            
            inId.value = "NUEVO REGISTRO";
            inNom.value = ""; inNom.readOnly = false;
            inApe.value = ""; inApe.readOnly = false;
            inFec.value = ""; inFec.readOnly = false;
        }

        procesarCambioEdad();

    } catch (error) {
        console.error('Error:', error);
        msg.className = "status-pill";
        msg.innerHTML = '<span style="color: #e74c3c;"><i class="fas fa-exclamation-triangle"></i> Error al conectar con el servidor.</span>';
    }
}

// --- 4. GESTIÓN DE PACIENTE NO CEDULADO (TOGGLE) ---
function toggleNoCedulado() {
    const isChecked = document.getElementById('no_cedulado').checked;
    
    const searchSection = document.getElementById('search-section');
    const mainForm = document.getElementById('main-form');
    const repData = document.getElementById('representative-data');
    const expedienteGroup = document.getElementById('expediente-group');
    const hiddenNoCedulado = document.getElementById('hidden_no_cedulado');
    const pacienteTitle = document.getElementById('paciente-title');
    const ageMsg = document.getElementById('age-msg');
    const statusMsg = document.getElementById('status-msg'); 
    
    const repDetails = document.getElementById('rep-details-section');
    const personalData = document.getElementById('personal-data');
    const submitBtn = document.getElementById('submit-btn');
    const statusMsgRep = document.getElementById('rep-status-msg');
    const seccionRepresentados = document.getElementById('lista-representados-section');

    mainForm.reset();
    closeCustomSelect(); 
    resetCustomSelectTrigger(); 

    if(ageMsg) ageMsg.innerText = "";
    if(statusMsgRep) statusMsgRep.innerHTML = ""; 
    if(statusMsg) statusMsg.style.display = "none"; 

    if (isChecked) {
        searchSection.classList.add('hidden');
        mainForm.classList.remove('hidden');
        repData.classList.remove('hidden');
        
        // ¡LA CURA!: Validamos que exista antes de modificarlo para que no se rompa el JS
        if (pacienteTitle) pacienteTitle.classList.remove('hidden');
        
        expedienteGroup.classList.add('hidden');
        
        if (repDetails) repDetails.classList.add('hidden');
        if (personalData) personalData.classList.add('hidden');
        if (submitBtn) submitBtn.classList.add('hidden');
        if (seccionRepresentados) seccionRepresentados.classList.add('hidden');
        document.getElementById('especialidad-container').style.display = 'none';

        // ¡Ahora sí llegará hasta aquí!
        hiddenNoCedulado.value = "1";
        document.getElementById('is_new_flag').value = "1";
        
        document.getElementById('input_cedula_rep').required = true;
        document.getElementById('input_nombres_rep').required = true;
        document.getElementById('input_apellidos_rep').required = true;

    } else {
        searchSection.classList.remove('hidden');
        mainForm.classList.add('hidden');
        repData.classList.add('hidden');
        
        // Lo mismo aquí
        if (pacienteTitle) pacienteTitle.classList.add('hidden');
        
        expedienteGroup.classList.remove('hidden');
        hiddenNoCedulado.value = "0";
        document.getElementById('input_cedula_rep').required = false;
        
        if (repDetails) repDetails.classList.add('hidden');
        if (personalData) personalData.classList.add('hidden');
        if (submitBtn) submitBtn.classList.add('hidden');
        if (seccionRepresentados) seccionRepresentados.classList.add('hidden');
        document.getElementById('especialidad-container').style.display = 'none';
    }
}

// =========================================================================
// --- 5. NUEVA LÓGICA DEL SELECTOR VISUAL PERSONALIZADO (CUSTOM SELECT) ---
// =========================================================================

// Alternar apertura/cierre de la lista visual
function toggleCustomSelect() {
    const container = document.getElementById('custom-select-rep');
    const list = document.getElementById('custom-select-options');
    container.classList.toggle('open');
    list.classList.toggle('hidden');
}

// Cerrar forzosamente la lista visual
function closeCustomSelect() {
    const container = document.getElementById('custom-select-rep');
    const list = document.getElementById('custom-select-options');
    if(container) container.classList.remove('open');
    if(list) list.classList.add('hidden');
}

// Resetear el texto del trigger visual
function resetCustomSelectTrigger() {
    const triggerText = document.getElementById('custom-select-text');
    if(triggerText) triggerText.innerText = "Seleccione un representado...";
}

// **Función Principal: Ejecutada cuando se hace clic en una opción (<li>) de la lista**
function seleccionarRepresentadoVisual(element, idPaciente, nombres, apellidos, fechaNacimiento) {
    const triggerText = document.getElementById('custom-select-text');
    const hiddenInputId = document.getElementById('id_representado_existente');
    
    const personalData = document.getElementById('personal-data');
    const submitBtn = document.getElementById('submit-btn');
    const inputNombres = document.getElementById('input_nombres');
    const inputApellidos = document.getElementById('input_apellidos');
    const inputFecha = document.getElementById('input_fecha');

    // 1. Marcar visualmente la opción como seleccionada en la lista
    const allOptions = document.querySelectorAll('.custom-option');
    allOptions.forEach(opt => opt.classList.remove('selected'));
    element.classList.add('selected');

    // 2. Actualizar el texto del 'botón' principal y guardar el ID en el input oculto
    hiddenInputId.value = idPaciente;
    triggerText.innerText = `${nombres} ${apellidos}`; // Texto visual del botón

    // 3. Cerrar la lista visualmente
    closeCustomSelect();

    // 4. Mostrar secciones comunes (datos paciente y especialidad)
    personalData.classList.remove('hidden');
    submitBtn.classList.remove('hidden');
    document.getElementById('especialidad-container').style.display = 'block';

    // 5. Lógica de Negocio: Autocompletar datos si es existente o limpiar si es nuevo
    if (idPaciente === 'nuevo') {
        // --- CASO: AÑADIR NUEVO REPRESENTADO ---
        triggerText.innerHTML = '<i class="fas fa-user-plus"></i> NUEVO REPRESENTADO';
        
        inputNombres.value = ''; inputNombres.readOnly = false;
        inputApellidos.value = ''; inputApellidos.readOnly = false;
        inputFecha.value = ''; inputFecha.readOnly = false;
        
        inputNombres.style.backgroundColor = "#ffffff";
        inputApellidos.style.backgroundColor = "#ffffff";
        inputFecha.style.backgroundColor = "#ffffff";

    } else {
        // --- CASO: REPRESENTADO EXISTENTE SELECCIONADO ---
        inputNombres.value = nombres; inputNombres.readOnly = true;
        inputApellidos.value = apellidos; inputApellidos.readOnly = true;
        inputFecha.value = fechaNacimiento; inputFecha.readOnly = true;
        
        inputNombres.style.backgroundColor = "#e1e8ed";
        inputApellidos.style.backgroundColor = "#e1e8ed";
        inputFecha.style.backgroundColor = "#e1e8ed";
    }

    // 6. Forzar el recálculo de edad y especialidad (Pediatría por defecto en este caso)
    procesarCambioEdad();
}

// --- 6. BÚSQUEDA DE REPRESENTANTE Y CARGA DE LA LISTA VISUAL ---
function verificarRepresentante() {
    const cedulaRep = document.getElementById('input_cedula_rep').value.trim();
    const statusMsg = document.getElementById('rep-status-msg');
    const inputNombres = document.getElementById('input_nombres_rep');
    const inputApellidos = document.getElementById('input_apellidos_rep');
    
    const repDetails = document.getElementById('rep-details-section');
    const personalData = document.getElementById('personal-data');
    const seccionRepresentados = document.getElementById('lista-representados-section');
    const listaVisualUl = document.getElementById('custom-select-options');

    // Limpiamos los datos anteriores mientras busca al representante
    repDetails.classList.add('hidden');
    personalData.classList.add('hidden');
    if (seccionRepresentados) seccionRepresentados.classList.add('hidden');
    closeCustomSelect();
    resetCustomSelectTrigger();

    document.getElementById('especialidad-container').style.display = "none";
    document.getElementById('submit-btn').classList.add('hidden');

    if (cedulaRep === '') {
        statusMsg.innerHTML = '<span style="color: #e74c3c;">Por favor, ingrese la cédula del representante.</span>';
        return;
    }

    statusMsg.innerHTML = '<span style="color: #0056b3;">Buscando representante... <i class="fas fa-spinner fa-spin"></i></span>';

    fetch('../api/buscar_representante_regular.php?cedula=' + encodeURIComponent(cedulaRep))
        .then(response => response.json())
        .then(data => {
            repDetails.classList.remove('hidden');
            
            // Configuración general obligatoria de especialidad pediátrica
            document.getElementById('select_especialidad').style.display = "none";
            document.getElementById('select_especialidad').required = false;
            document.getElementById('especialidad_fija').style.display = "block";
            document.getElementById('hidden_especialidad_pediatrica').disabled = false;

            if (data.existe) {
                // --- REPRESENTANTE EXISTENTE ---
                inputNombres.value = data.nombres || data.nombre || '';
                inputApellidos.value = data.apellidos || data.apellido || '';
                
                inputNombres.readOnly = true;
                inputApellidos.readOnly = true;
                inputNombres.style.backgroundColor = "#e1e8ed";
                inputApellidos.style.backgroundColor = "#e1e8ed";
                
                statusMsg.innerHTML = '<span style="color: #00d1b2;">Representante registrado. Seleccione o añada un menor.</span>';

                // **CONSTRUCCIÓN VISUAL DE LA LISTA (<ul> -> <li>)**
                if (listaVisualUl && seccionRepresentados) {
                    listaVisualUl.innerHTML = ''; // Limpiar lista anterior
                    
                    // 1. Agregar los menores existentes (si tiene)
                    if (data.representados && data.representados.length > 0) {
                        data.representados.forEach(menor => {
                            let li = document.createElement('li');
                            li.className = 'custom-option';
                            // Icono visual y datos
                            li.innerHTML = `<i class="fas fa-child"></i> ${menor.nombres} ${menor.apellidos} <span style="margin-left:auto; font-size:0.8rem; opacity:0.6;">Nac: ${menor.fecha_nacimiento}</span>`;
                            
                            // Evento de clic para seleccionar
                            li.onclick = function() {
                                seleccionarRepresentadoVisual(this, menor.id_paciente, menor.nombres, menor.apellidos, menor.fecha_nacimiento);
                            };
                            listaVisualUl.appendChild(li);
                        });
                    }
                    
                    // 2. Agregar SIEMPRE la opción visual de "Añadir nuevo" al final
                    let liNuevo = document.createElement('li');
                    liNuevo.className = 'custom-option option-nuevo';
                    liNuevo.innerHTML = `<i class="fas fa-user-plus"></i> + Añadir nuevo representado`;
                    liNuevo.onclick = function() {
                        seleccionarRepresentadoVisual(this, 'nuevo', '', '', '');
                    };
                    listaVisualUl.appendChild(liNuevo);
                    
                    // Mostrar la sección completa del selector
                    seccionRepresentados.classList.remove('hidden');
                }

            } else {
                // --- REPRESENTANTE NUEVO ---
                inputNombres.value = ''; inputApellidos.value = '';
                inputNombres.readOnly = false; inputApellidos.readOnly = false;
                inputNombres.style.backgroundColor = "#ffffff"; inputApellidos.style.backgroundColor = "#ffffff";
                
                statusMsg.innerHTML = '<span style="color: #e67e22;">Representante no registrado. Llene sus datos y los del paciente.</span>';
                
                // Limpiar campos del paciente (será registro nuevo obligatoriamente)
                document.getElementById('input_nombres').value = '';
                document.getElementById('input_apellidos').value = '';
                document.getElementById('input_fecha').value = '';
                document.getElementById('input_nombres').readOnly = false;
                document.getElementById('input_apellidos').readOnly = false;
                document.getElementById('input_fecha').readOnly = false;
                document.getElementById('id_representado_existente').value = '';

                personalData.classList.remove('hidden');
                document.getElementById('especialidad-container').style.display = "block";
                document.getElementById('submit-btn').classList.remove('hidden');
            }
        })
        .catch(error => {
            console.error('Error de conexión:', error);
            statusMsg.innerHTML = '<span style="color: #e74c3c;">Error al conectar con el servidor. Revisar consola.</span>';
        });
}

// --- 7. INICIALIZACIÓN ---
document.addEventListener('DOMContentLoaded', () => {
    const campoFecha = document.getElementById('input_fecha');
    
    if(campoFecha) {
        campoFecha.max = new Date().toISOString().split("T")[0];
        campoFecha.addEventListener('change', procesarCambioEdad);
        campoFecha.addEventListener('input', procesarCambioEdad);
    }

    const idsLetras = ['input_nombres', 'input_apellidos', 'input_nombres_rep', 'input_apellidos_rep'];
    idsLetras.forEach(id => {
        const el = document.getElementById(id);
        if(el) el.addEventListener('keypress', soloLetras);
    });

    const idsNumeros = ['ci_busqueda', 'input_cedula_rep'];
    idsNumeros.forEach(id => {
        const el = document.getElementById(id);
        if(el) el.addEventListener('keypress', soloNumeros);
    });

    // NUEVO: Cerrar el selector personalizado si se hace clic fuera de él
    document.addEventListener('click', function(event) {
        const isClickInside = document.getElementById('custom-select-rep').contains(event.target);
        if (!isClickInside) {
            closeCustomSelect();
        }
    });
});