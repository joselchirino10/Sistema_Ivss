<?php
require_once '../auth/sesion.php'; 
require_once '../conexion.php';

// ¡EL ARMA SECRETA!: Esto forzará a PHP a mostrar en pantalla CUALQUIER rechazo de la base de datos.
mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);

try {
    // 1. Captura de datos más segura
    $es_no_cedulado = $_POST['es_no_cedulado'] ?? "0";
    $cedula_paciente = $_POST['cedula_paciente'] ?? null;
    $nombres_paciente = mysqli_real_escape_string($conexion, $_POST['nombres'] ?? '');
    $apellidos_paciente = mysqli_real_escape_string($conexion, $_POST['apellidos'] ?? '');
    $fecha_nacimiento = $_POST['fecha_nacimiento'] ?? '';
    
    // Atrapamos la especialidad correcta, ya sea del select o del input oculto pediátrico
    $especialidad = $_POST['especialidad'] ?? $_POST['especialidad_pediatrica'] ?? 'No definida';
    
    $id_representante = "NULL";
    $tipo_paciente_paciente = "Nuevo"; 

    $id_paciente_final = 0;

    // --- LÓGICA PARA REPRESENTANTE ---
    if ($es_no_cedulado == "1") {
        $cedula_rep_cruda = $_POST['cedula_rep'] ?? '';
        $cedula_rep_limpia = preg_replace('/[^0-9]/', '', $cedula_rep_cruda);
        $cedula_rep = mysqli_real_escape_string($conexion, $cedula_rep_limpia);
        $nombres_rep = mysqli_real_escape_string($conexion, $_POST['nombres_rep'] ?? '');
        $apellidos_rep = mysqli_real_escape_string($conexion, $_POST['apellidos_rep'] ?? '');

        if (empty($cedula_rep)) {
            die("Error Lógico: El formulario no envió la cédula del representante al servidor.");
        }

        $check_rep = mysqli_query($conexion, "SELECT ID FROM representantes WHERE Cedula = '$cedula_rep'");
        
        if ($row_r = mysqli_fetch_assoc($check_rep)) {
            $id_representante = $row_r['ID'];
        } else {
            $sql_insert_rep = "INSERT INTO representantes (Nombres, Apellidos, Cedula) VALUES ('$nombres_rep', '$apellidos_rep', '$cedula_rep')";
            mysqli_query($conexion, $sql_insert_rep);
            $id_representante = mysqli_insert_id($conexion);
        }
    }

    // --- LÓGICA PARA BUSCAR/REGISTRAR PACIENTE ---
    if ($es_no_cedulado == "1") {
        $check_p = mysqli_query($conexion, "SELECT id FROM pacientes WHERE nombres = '$nombres_paciente' AND apellidos = '$apellidos_paciente' AND id_representante = $id_representante");
        
        if ($row_p = mysqli_fetch_assoc($check_p)) {
            $id_paciente_final = $row_p['id'];
            $tipo_paciente_paciente = "Existente";
        } else {
            // OJO: Si la tabla exige la 'cedula' obligatoriamente, el error saltará aquí.
            $sql_insert_paciente = "INSERT INTO pacientes (nombres, apellidos, fecha_nacimiento, id_representante) VALUES ('$nombres_paciente', '$apellidos_paciente', '$fecha_nacimiento', $id_representante)";
            mysqli_query($conexion, $sql_insert_paciente);
            $id_paciente_final = mysqli_insert_id($conexion);
            $tipo_paciente_paciente = "Nuevo";
        }
    } else {
        $check_p = mysqli_query($conexion, "SELECT id FROM pacientes WHERE cedula = '$cedula_paciente'");
        
        if ($row_p = mysqli_fetch_assoc($check_p)) {
            $id_paciente_final = $row_p['id'];
            $tipo_paciente_paciente = "Existente";
        } else {
            $sql_insert_paciente = "INSERT INTO pacientes (cedula, nombres, apellidos, fecha_nacimiento) VALUES ('$cedula_paciente', '$nombres_paciente', '$apellidos_paciente', '$fecha_nacimiento')";
            mysqli_query($conexion, $sql_insert_paciente);
            $id_paciente_final = mysqli_insert_id($conexion);
            $tipo_paciente_paciente = "Nuevo";
        }
    }

    // --- REGISTRO DE INGRESO ---
    if ($id_paciente_final > 0) {
        $fecha_ingreso = date("Y-m-d H:i:s");
        
        $sql_ingreso = "INSERT INTO ingresos (paciente_id, especialidad, fecha_consulta, tipo_paciente) VALUES ('$id_paciente_final', '$especialidad', '$fecha_ingreso', '$tipo_paciente_paciente')";
        mysqli_query($conexion, $sql_ingreso);
            
        // Bitácora
        $usuario_id = $_SESSION['usuario_id'] ?? 0;
        $accion = 'Create';
        $desc = ($es_no_cedulado == "1") 
                ? "Ingreso ($tipo_paciente_paciente) paciente menor: $nombres_paciente (Rep: $cedula_rep)" 
                : "Ingreso ($tipo_paciente_paciente) paciente CI: $cedula_paciente";

        $stmt = $conexion->prepare("INSERT INTO bitacora (usuario_id, accion, descripcion) VALUES (?, ?, ?)");
        $stmt->bind_param("iss", $usuario_id, $accion, $desc);
        $stmt->execute();
        
        header("Location: ../regular/gestion_pacientes_regular.php?status=success_registro");
        exit();
    } else {
        // En lugar de una pantalla en blanco, ahora nos dirá por qué no entró.
        die("<h3>Atención:</h3><p>El ID del paciente final es 0. Revisa si hay campos vacíos que estén impidiendo el registro.</p>");
    }

} catch (mysqli_sql_exception $e) {
    // Si la base de datos rechaza cualquier cosa, caerá aquí y te dirá exactamente el motivo.
    die("<div style='background-color:#ffeaa7; padding:20px; border:1px solid #fdcb6e; font-family:sans-serif;'>
            <h3 style='color:#d63031;'>¡MySQL rechazó la operación!</h3>
            <p><strong>Detalle del error:</strong> " . $e->getMessage() . "</p>
         </div>");
}
?>