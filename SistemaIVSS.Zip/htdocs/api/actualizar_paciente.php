<?php
require_once '../auth/sesion.php'; 
validarAcceso('Administrador'); 

header('Content-Type: application/json; charset=utf-8');

// Configuración de conexión (Idéntica a tu obtener_paciente.php)
require_once '../conexion.php';
try {
    // Creamos la conexión PDO
    $pdo = new PDO("mysql:host=$host;dbname=$db;charset=utf8mb4", $user, $pass);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // Validamos que estemos recibiendo todos los datos necesarios desde el modal
    if (isset($_POST['id'], $_POST['nombres'], $_POST['apellidos'], $_POST['fecha_nacimiento'])) {
        
        // Limpiamos un poco los datos
        $id = intval($_POST['id']);
        $nombres = trim($_POST['nombres']);
        $apellidos = trim($_POST['apellidos']);
        $fecha_nacimiento = $_POST['fecha_nacimiento'];

        // Obtenemos el ID del usuario actual desde la sesión
        if (session_status() === PHP_SESSION_NONE) {
            session_start();
        }
        $usuario_id = isset($_SESSION['id_sistema']) ? $_SESSION['id_sistema'] : (isset($_SESSION['usuario_id']) ? $_SESSION['usuario_id'] : 0);

        // Preparamos la consulta UPDATE para evitar inyecciones SQL
        $sql = "UPDATE pacientes SET nombres = :nombres, apellidos = :apellidos, fecha_nacimiento = :fecha_nacimiento WHERE id = :id";
        $stmt = $pdo->prepare($sql);

        // Enlazamos los parámetros
        $stmt->bindParam(':nombres', $nombres, PDO::PARAM_STR);
        $stmt->bindParam(':apellidos', $apellidos, PDO::PARAM_STR);
        $stmt->bindParam(':fecha_nacimiento', $fecha_nacimiento, PDO::PARAM_STR);
        $stmt->bindParam(':id', $id, PDO::PARAM_INT);

        // Ejecutamos y verificamos si se guardó
        if ($stmt->execute()) {
            
            // --- INICIO DEL REGISTRO EN BITÁCORA ---
            // Si la actualización fue exitosa y hay un usuario válido, registramos la acción 'Update'
            if ($usuario_id > 0) {
                $accion = 'Update';
                $descripcion = "Actualización de datos del paciente: " . $nombres . " " . $apellidos . " (ID: " . $id . ")";
                
                $sqlBitacora = "INSERT INTO bitacora (usuario_id, accion, descripcion) VALUES (:usuario_id, :accion, :descripcion)";
                $stmtBit = $pdo->prepare($sqlBitacora);
                
                $stmtBit->bindParam(':usuario_id', $usuario_id, PDO::PARAM_INT);
                $stmtBit->bindParam(':accion', $accion, PDO::PARAM_STR);
                $stmtBit->bindParam(':descripcion', $descripcion, PDO::PARAM_STR);
                $stmtBit->execute();
            }
            // --- FIN DEL REGISTRO EN BITÁCORA ---

            echo json_encode(['status' => 'success', 'message' => 'Los datos se actualizaron correctamente.']);
        } else {
            echo json_encode(['status' => 'error', 'message' => 'Ocurrió un error al intentar actualizar el registro en la base de datos.']);
        }

    } else {
        echo json_encode(['status' => 'error', 'message' => 'Faltan datos en el formulario. Por favor, verifica.']);
    }

} catch (PDOException $e) {
    // Si hay un error crítico de conexión o consulta, lo capturamos aquí
    echo json_encode(['status' => 'error', 'message' => 'Error del sistema: ' . $e->getMessage()]);
}
?>