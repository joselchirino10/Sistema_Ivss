<?php
require_once '../auth/sesion.php';
require_once '../conexion.php'; // ¡Aquí ya viene $pdo creado y configurado!

header('Content-Type: application/json');

try {
    // Ya NO creamos $pdo aquí, simplemente usamos el que viene de conexion.php

    if (isset($_GET['cedula']) && trim($_GET['cedula']) !== '') {
        $cedula = trim($_GET['cedula']);
        
        // Usamos directamente el $pdo que ya está abierto
        $stmt = $pdo->prepare("SELECT id FROM pacientes WHERE cedula = ? LIMIT 1");
        $stmt->execute([$cedula]);
        $paciente = $stmt->fetch(); // fetch() ya usa FETCH_ASSOC por defecto gracias a tu conexion.php

        if ($paciente) {
            echo json_encode(['success' => true, 'id' => $paciente['id']]);
        } else {
            echo json_encode(['success' => false, 'message' => 'No encontrado']);
        }
    } else {
        echo json_encode(['success' => false, 'message' => 'Cédula no proporcionada']);
    }
} catch (PDOException $e) {
    // Capturamos cualquier error de la consulta
    echo json_encode(['success' => false, 'message' => 'Error de base de datos']);
}