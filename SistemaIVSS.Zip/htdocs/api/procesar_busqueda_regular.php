<?php
require_once '../auth/sesion.php';

validarAcceso('Regular'); 
require_once '../conexion.php';

$valor = $_POST['valor'] ?? '';
$esNoCedulado = $_POST['es_no_cedulado'] ?? 0;

if (empty($valor)) exit("<p class='result-card'>Ingrese un dato válido.</p>");

if ($esNoCedulado == 1) {
    // 1. BUSCAR POR REPRESENTANTE
    $queryRep = "SELECT * FROM representantes WHERE Cedula = ?";
    $stmtRep = mysqli_prepare($conexion, $queryRep);
    mysqli_stmt_bind_param($stmtRep, "s", $valor);
    mysqli_stmt_execute($stmtRep);
    $resRep = mysqli_stmt_get_result($stmtRep);

    if ($rep = mysqli_fetch_assoc($resRep)) {
        echo "<div class='result-card rep-info'>";
        echo "<h3><i class='fas fa-user-shield'></i> Representante: " . htmlspecialchars($rep['Nombres'] . " " . $rep['Apellidos']) . "</h3>";
        echo "<p>Cédula: <b>" . htmlspecialchars($rep['Cedula']) . "</b> | ID Sistema: " . $rep['ID'] . "</p>";
        echo "</div>";

        // 2. BUSCAR SUS REPRESENTADOS (PACIENTES NO CEDULADOS)
        $queryPac = "SELECT * FROM pacientes WHERE id_representante = ?";
        $stmtPac = mysqli_prepare($conexion, $queryPac);
        mysqli_stmt_bind_param($stmtPac, "i", $rep['ID']);
        mysqli_stmt_execute($stmtPac);
        $resPac = mysqli_stmt_get_result($stmtPac);

        if (mysqli_num_rows($resPac) > 0) {
            while ($paciente = mysqli_fetch_assoc($resPac)) {
                mostrarHistorial($paciente, $conexion);
            }
        } else {
            echo "<p class='result-card'>Este representante no tiene menores registrados.</p>";
        }
    } else {
        echo "<p class='result-card'>No se encontró ningún representante con esa cédula.</p>";
    }
} else {
    // BUSCAR PACIENTE CEDULADO NORMAL
    $queryPac = "SELECT * FROM pacientes WHERE cedula = ?";
    $stmtPac = mysqli_prepare($conexion, $queryPac);
    mysqli_stmt_bind_param($stmtPac, "s", $valor);
    mysqli_stmt_execute($stmtPac);
    $resPac = mysqli_stmt_get_result($stmtPac);

    if ($paciente = mysqli_fetch_assoc($resPac)) {
        mostrarHistorial($paciente, $conexion);
    } else {
        echo "<p class='result-card'>No se encontró paciente con la cédula $valor.</p>";
    }
}

// FUNCIÓN AUXILIAR PARA MOSTRAR HISTORIAL (SOLO LECTURA)
function mostrarHistorial($paciente, $conexion) {
    echo "<div class='result-card'>";
    
    // Encabezado de información del paciente (Sin botones de acción)
    echo "<div style='margin-bottom: 15px;'>";
        echo "<h3><i class='fas fa-user'></i> " . htmlspecialchars($paciente['nombres'] . " " . $paciente['apellidos']) . "</h3>";
        echo "<p style='margin-top: 5px;'>ID Expediente: <b>" . htmlspecialchars($paciente['id']) . "</b> | Fecha de Nacimiento: " . htmlspecialchars($paciente['fecha_nacimiento']) . "</p>";
    echo "</div>";

    // CONSULTAR INGRESOS DE ESTE PACIENTE
    $queryIng = "SELECT * FROM ingresos WHERE paciente_id = ? ORDER BY fecha_consulta DESC";
    $stmtIng = mysqli_prepare($conexion, $queryIng);
    mysqli_stmt_bind_param($stmtIng, "i", $paciente['id']);
    mysqli_stmt_execute($stmtIng);
    $resIng = mysqli_stmt_get_result($stmtIng);

    echo "<h4 style='color: var(--dark-blue); margin-bottom: 10px; font-size: 0.9rem; border-bottom: 1px solid #eee; padding-bottom: 5px;'>Historial de Consultas e Ingresos</h4>";

    if (mysqli_num_rows($resIng) > 0) {
        echo "<table class='history-table'>";
        echo "<thead>
                <tr>
                    <th>Fecha</th>
                    <th>Especialidad</th>
                    <th>Tipo de Paciente</th>
                    <th>ID Ingreso</th>
                </tr>
              </thead>";
        echo "<tbody>";
        while ($ing = mysqli_fetch_assoc($resIng)) {
            $esp = !empty($ing['especialidad']) ? htmlspecialchars($ing['especialidad']) : "No asignada";
            echo "<tr>
                    <td>" . htmlspecialchars($ing['fecha_consulta']) . "</td>
                    <td><span class='badge' style='background: #e3f2fd; color: #0056b3;'>" . $esp . "</span></td>
                    <td>" . htmlspecialchars($ing['tipo_paciente']) . "</td>
                    <td style='color: #7f8c8d;'>#" . htmlspecialchars($ing['id']) . "</td>
                  </tr>";
        }
        echo "</tbody></table>";
    } else {
        echo "<p style='color: #636e72; font-style: italic; margin-top: 10px; font-size: 0.85rem;'>Este paciente no cuenta con registros de ingresos previos en el sistema.</p>";
    }
    echo "</div>";
}
?>