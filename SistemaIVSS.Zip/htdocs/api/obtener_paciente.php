<?php
// obtener_paciente.php
header('Content-Type: application/json; charset=utf-8');

// 1. Validar la sesión antes de conectarnos a la BD.
require_once '../auth/sesion.php'; 

// Como es una API (devuelve JSON), no queremos que validarAcceso imprima HTML o redirija
// si falla. Vamos a hacer una validación manual rápida para evitar romper el JSON.
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Opcional: Si quieres ser estricto con los permisos en la API
if (!isset($_SESSION['usuario_id']) || $_SESSION['tipo_usuario'] !== 'Administrador') {
    // Si tienes diferentes roles que pueden acceder, ajusta esta condición.
    // Lo importante es devolver un JSON de error si no tienen acceso.
    echo json_encode(['existe' => false, 'error' => 'Acceso no autorizado a la API.']);
    exit;
}


// 2. Configuración de conexión centralizada
require_once '../conexion.php';

// Verificamos que la variable $pdo exista (creada en conexion.php)
if (!isset($pdo)) {
    echo json_encode(['existe' => false, 'error' => 'Error interno: La conexión a la base de datos no está disponible.']);
    exit;
}

try {
    // Ya no necesitamos crear "new PDO(...)" aquí. Usamos el $pdo de conexion.php

    // ESCENARIO 1: Búsqueda por ID (El que usa tu botón de EDITAR)
    if (isset($_GET['id'])) {
        $id = $_GET['id'];

        $stmt = $pdo->prepare("SELECT id, cedula, nombres, apellidos, fecha_nacimiento, tipo FROM pacientes WHERE id = :id LIMIT 1");
        $stmt->bindParam(':id', $id, PDO::PARAM_INT);
        $stmt->execute();

        $paciente = $stmt->fetch(PDO::FETCH_ASSOC);

        if ($paciente) {
            echo json_encode($paciente);
        } else {
            echo json_encode(['error' => 'Paciente no encontrado']);
        }
    } 
    // ESCENARIO 2: Búsqueda por Cédula (El que usa tu REGISTRO para validar)
    elseif (isset($_GET['cedula'])) {
        $cedula = trim($_GET['cedula']);

        if (!empty($cedula)) {
            $stmt = $pdo->prepare("SELECT id, cedula, nombres, apellidos, fecha_nacimiento, tipo FROM pacientes WHERE cedula = :cedula LIMIT 1");
            $stmt->bindParam(':cedula', $cedula, PDO::PARAM_STR);
            $stmt->execute();
            
            $paciente = $stmt->fetch(PDO::FETCH_ASSOC);

            if ($paciente) {
                echo json_encode([
                    'existe' => true, 
                    'tipo_registrado' => $paciente['tipo'], 
                    'datos' => [
                        'id'               => $paciente['id'],
                        'nombres'          => $paciente['nombres'],
                        'apellidos'        => $paciente['apellidos'],
                        'fecha_nacimiento' => $paciente['fecha_nacimiento']
                    ]
                ]);
            } else {
                echo json_encode(['existe' => false]);
            }
        } else {
            echo json_encode(['existe' => false, 'error' => 'Cédula no proporcionada']);
        }
    } 
    else {
        echo json_encode(['error' => 'No se proporcionó un parámetro de búsqueda válido']);
    }

} catch (PDOException $e) {
    echo json_encode(['existe' => false, 'error' => 'Error de base de datos: ' . $e->getMessage()]);
}
?>