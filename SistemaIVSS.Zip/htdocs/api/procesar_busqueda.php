<?php
require_once '../auth/sesion.php'; 

validarAcceso('Administrador'); 
require_once '../conexion.php';
$valor = $_POST['valor'] ?? '';
$esNoCedulado = $_POST['es_no_cedulado'] ?? 0;

if (empty($valor)) exit("<p class='result-card'>Ingrese un dato válido.</p>");

if ($esNoCedulado == 1) {
    // 1. BUSCAR POR REPRESENTANTE
    $queryRep = "SELECT * FROM representantes WHERE Cedula = ?";
    $stmtRep = mysqli_prepare($conexion, $queryRep);
    mysqli_stmt_bind_param($stmtRep, "s", $valor);
    mysqli_stmt_execute($stmtRep);
    $resRep = mysqli_stmt_get_result($stmtRep);

    if ($rep = mysqli_fetch_assoc($resRep)) {
        echo "<div class='result-card rep-info'>";
        echo "<h3><i class='fas fa-user-shield'></i> Representante: ID " . $rep['ID'] . "</h3>";
        echo "<p>Cédula: " . $rep['Cedula'] . "</p>";
        echo "</div>";

        // 2. BUSCAR SUS REPRESENTADOS (PACIENTES NO CEDULADOS)
        $queryPac = "SELECT * FROM pacientes WHERE id_representante = ?";
        $stmtPac = mysqli_prepare($conexion, $queryPac);
        mysqli_stmt_bind_param($stmtPac, "i", $rep['ID']);
        mysqli_stmt_execute($stmtPac);
        $resPac = mysqli_stmt_get_result($stmtPac);

        if (mysqli_num_rows($resPac) > 0) {
            while ($paciente = mysqli_fetch_assoc($resPac)) {
                mostrarHistorial($paciente, $conexion);
            }
        } else {
            echo "<p class='result-card'>Este representante no tiene menores registrados.</p>";
        }
    } else {
        echo "<p class='result-card'>No se encontró ningún representante con esa cédula.</p>";
    }
} else {
    // BUSCAR PACIENTE CEDULADO NORMAL
    $queryPac = "SELECT * FROM pacientes WHERE cedula = ?";
    $stmtPac = mysqli_prepare($conexion, $queryPac);
    mysqli_stmt_bind_param($stmtPac, "s", $valor);
    mysqli_stmt_execute($stmtPac);
    $resPac = mysqli_stmt_get_result($stmtPac);

    if ($paciente = mysqli_fetch_assoc($resPac)) {
        mostrarHistorial($paciente, $conexion);
    } else {
        echo "<p class='result-card'>No se encontró paciente con la cédula $valor.</p>";
    }
}

// FUNCIÓN AUXILIAR PARA MOSTRAR HISTORIAL
function mostrarHistorial($paciente, $conexion) {
    echo "<div class='result-card'>";
    
    // Contenedor flexible para poner el nombre a la izquierda y los botones a la derecha
    echo "<div style='display: flex; justify-content: space-between; align-items: flex-start; margin-bottom: 15px;'>";
        echo "<div>";
            echo "<h3><i class='fas fa-user'></i> " . htmlspecialchars($paciente['nombres'] . " " . $paciente['apellidos']) . "</h3>";
            echo "<p>ID Expediente: <b>" . htmlspecialchars($paciente['id']) . "</b> | Nacimiento: " . htmlspecialchars($paciente['fecha_nacimiento']) . "</p>";
        echo "</div>";
        
        // Botones de acción correctamente impresos en PHP con estilos en línea básicos
        echo "<div style='display: flex; gap: 10px;'>";
            echo "<button onclick='abrirModalEditar(" . $paciente['id'] . ")' class='btn-edit' style='background-color: #f39c12; color: white; border: none; padding: 8px 12px; border-radius: 6px; cursor: pointer; font-weight: 600;'><i class='fas fa-edit'></i> Editar</button>";
            echo "<button onclick='eliminarPaciente(" . $paciente['id'] . ")' class='btn-delete' style='background-color: #e74c3c; color: white; border: none; padding: 8px 12px; border-radius: 6px; cursor: pointer; font-weight: 600;'><i class='fas fa-trash'></i> Eliminar</button>";
        echo "</div>";
    echo "</div>";

    // CONSULTAR INGRESOS DE ESTE PACIENTE (Ahora más seguro con sentencias preparadas)
    $queryIng = "SELECT * FROM ingresos WHERE paciente_id = ? ORDER BY fecha_consulta DESC";
    $stmtIng = mysqli_prepare($conexion, $queryIng);
    mysqli_stmt_bind_param($stmtIng, "i", $paciente['id']);
    mysqli_stmt_execute($stmtIng);
    $resIng = mysqli_stmt_get_result($stmtIng);

    if (mysqli_num_rows($resIng) > 0) {
        echo "<table class='history-table'>";
        echo "<thead><tr><th>Fecha</th><th>Especialidad</th><th>Tipo</th><th>ID Ingreso</th></tr></thead>";
        echo "<tbody>";
        while ($ing = mysqli_fetch_assoc($resIng)) {
            $esp = !empty($ing['especialidad']) ? htmlspecialchars($ing['especialidad']) : "No asignada";
            echo "<tr>
                    <td>" . htmlspecialchars($ing['fecha_consulta']) . "</td>
                    <td><span class='badge'>" . $esp . "</span></td>
                    <td>" . htmlspecialchars($ing['tipo_paciente']) . "</td>
                    <td>#" . htmlspecialchars($ing['id']) . "</td>
                  </tr>";
        }
        echo "</tbody></table>";
    } else {
        echo "<p style='color: #666; font-style: italic; margin-top: 10px;'>No registra ingresos previos.</p>";
    }
    echo "</div>";
}
?>