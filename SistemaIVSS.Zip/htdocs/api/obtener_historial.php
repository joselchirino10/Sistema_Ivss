<?php
require_once '../auth/sesion.php'; 

validarAcceso('Administrador'); 
require_once '../conexion.php';
$id_paciente = $_GET['id'];

$sql = "SELECT * FROM ingresos WHERE paciente_id = $id_paciente ORDER BY fecha_consulta DESC";
$res = mysqli_query($conexion, $sql);

if (mysqli_num_rows($res) > 0) {
    while ($row = mysqli_fetch_assoc($res)) {
        echo "<div class='history-item'>";
        echo "<strong>Fecha:</strong> " . date("d/m/Y H:i", strtotime($row['fecha_consulta'])) . "<br>";
        echo "<strong>Especialidad:</strong> <span style='color:var(--primary-blue)'>" . $row['especialidad'] . "</span>";
        echo "</div>";
    }
} else {
    echo "<p style='text-align:center; color:#636e72;'>Este paciente no tiene ingresos previos registrados.</p>";
}
?>