<?php
require_once '../auth/sesion.php';

validarAcceso('Regular'); 

// obtener_paciente.php
header('Content-Type: application/json; charset=utf-8');

// Configuración de conexión 
require_once '../conexion.php';
try {
    // Creamos la conexión PDO
    $pdo = new PDO("mysql:host=$host;dbname=$db;charset=utf8mb4", $user, $pass);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // ESCENARIO 1: Búsqueda por ID (El que usa tu botón de EDITAR)
    if (isset($_GET['id'])) {
        $id = $_GET['id'];

        $stmt = $pdo->prepare("SELECT id, cedula, nombres, apellidos, fecha_nacimiento, tipo FROM pacientes WHERE id = :id LIMIT 1");
        $stmt->bindParam(':id', $id, PDO::PARAM_INT);
        $stmt->execute();

        $paciente = $stmt->fetch(PDO::FETCH_ASSOC);

        if ($paciente) {
            echo json_encode($paciente);
        } else {
            echo json_encode(['error' => 'Paciente no encontrado']);
        }
    } 
    // ESCENARIO 2: Búsqueda por Cédula (El que usa tu REGISTRO para validar)
    elseif (isset($_GET['cedula'])) {
        $cedula = trim($_GET['cedula']);

        if (!empty($cedula)) {
            $stmt = $pdo->prepare("SELECT id, cedula, nombres, apellidos, fecha_nacimiento, tipo FROM pacientes WHERE cedula = :cedula LIMIT 1");
            $stmt->bindParam(':cedula', $cedula, PDO::PARAM_STR);
            $stmt->execute();
            
            $paciente = $stmt->fetch(PDO::FETCH_ASSOC);

            if ($paciente) {
                echo json_encode([
                    'existe' => true, 
                    'tipo_registrado' => $paciente['tipo'], 
                    'datos' => [
                        'id'               => $paciente['id'],
                        'nombres'          => $paciente['nombres'],
                        'apellidos'        => $paciente['apellidos'],
                        'fecha_nacimiento' => $paciente['fecha_nacimiento']
                    ]
                ]);
            } else {
                echo json_encode(['existe' => false]);
            }
        } else {
            echo json_encode(['existe' => false, 'error' => 'Cédula no proporcionada']);
        }
    } 
    else {
        echo json_encode(['error' => 'No se proporcionó un parámetro de búsqueda válido']);
    }

} catch (PDOException $e) {
    echo json_encode(['existe' => false, 'error' => 'Error de conexión: ' . $e->getMessage()]);
}
?>