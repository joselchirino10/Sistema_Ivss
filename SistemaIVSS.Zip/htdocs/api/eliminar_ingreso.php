<?php
require_once '../auth/sesion.php'; 

require_once '../conexion.php';

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['id'])) {
 
    $conexion = mysqli_connect($host, $user, $pass, $db);

    if (!$conexion) {
        echo json_encode(['status' => 'error', 'message' => 'Error de conexión a la base de datos.']);
        exit;
    }

    $id_ingreso = intval($_POST['id']);
    
    // Obtenemos el ID del usuario que está realizando la acción desde la sesión.
    // (Asegúrate de usar el mismo nombre de variable que usas en tu login.php)
    if (session_status() === PHP_SESSION_NONE) {
        session_start();
    }
    $usuario_id = isset($_SESSION['id_sistema']) ? $_SESSION['id_sistema'] : (isset($_SESSION['usuario_id']) ? $_SESSION['usuario_id'] : 0);

    // Prevenir inyección SQL usando sentencias preparadas para eliminar el ingreso
    $query = "DELETE FROM ingresos WHERE id = ?";
    
    if ($stmt = mysqli_prepare($conexion, $query)) {
        mysqli_stmt_bind_param($stmt, "i", $id_ingreso);
        
        if (mysqli_stmt_execute($stmt)) {
            
            // --- INICIO DEL REGISTRO EN BITÁCORA ---
            // Si tenemos un usuario válido en sesión, registramos la acción 'Delete'
            if ($usuario_id > 0) {
                $accion = 'Delete';
                $descripcion = "Eliminación del registro de ingreso #" . $id_ingreso;
                
                $query_bitacora = "INSERT INTO bitacora (usuario_id, accion, descripcion) VALUES (?, ?, ?)";
                if ($stmt_bit = mysqli_prepare($conexion, $query_bitacora)) {
                    mysqli_stmt_bind_param($stmt_bit, "iss", $usuario_id, $accion, $descripcion);
                    mysqli_stmt_execute($stmt_bit);
                    mysqli_stmt_close($stmt_bit);
                }
            }
            // --- FIN DEL REGISTRO EN BITÁCORA ---
             
            echo json_encode(['status' => 'success', 'message' => 'Ingreso eliminado y registrado en la bitácora correctamente.']);
        } else {
            echo json_encode(['status' => 'error', 'message' => 'No se pudo eliminar el registro.']);
        }
        
        mysqli_stmt_close($stmt);
    } else {
        echo json_encode(['status' => 'error', 'message' => 'Error en la consulta SQL.']);
    }

    mysqli_close($conexion);
} else {
    echo json_encode(['status' => 'error', 'message' => 'Petición no válida o ID faltante.']);
}
?>