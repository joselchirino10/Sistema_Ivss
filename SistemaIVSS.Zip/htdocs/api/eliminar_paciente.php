<?php

// 1. Seguridad: Verificar sesión y acceso
require_once '../auth/sesion.php'; 
validarAcceso('Administrador'); 

// 2. Incluir conexión a base de datos
require_once '../conexion.php';
// Preparar respuesta JSON por defecto
$respuesta = [
    'status' => 'error',
    'message' => 'Ocurrió un error desconocido.'
];

// 3. Verificar si se recibió el ID
if (isset($_POST['id']) && !empty($_POST['id'])) {
    $idPaciente = intval($_POST['id']); // Asegurar que sea un entero

    // Obtener el ID del usuario actual desde la sesión
    if (session_status() === PHP_SESSION_NONE) {
        session_start();
    }
    $usuario_id = isset($_SESSION['id_sistema']) ? $_SESSION['id_sistema'] : (isset($_SESSION['usuario_id']) ? $_SESSION['usuario_id'] : 0);

    // INICIAR TRANSACCIÓN (Muy importante porque vamos a borrar y registrar en múltiples tablas)
    mysqli_begin_transaction($conexion);

    try {
        // --- EXTRA: Consultar datos del paciente antes de borrarlo para la bitácora ---
        $sqlInfo = "SELECT nombres, apellidos, cedula FROM pacientes WHERE id = ?";
        $stmtInfo = mysqli_prepare($conexion, $sqlInfo);
        mysqli_stmt_bind_param($stmtInfo, "i", $idPaciente);
        mysqli_stmt_execute($stmtInfo);
        $resultInfo = mysqli_stmt_get_result($stmtInfo);
        
        $pacienteDetalle = "ID " . $idPaciente; // Valor por defecto
        if ($rowInfo = mysqli_fetch_assoc($resultInfo)) {
            $cedulaText = !empty($rowInfo['cedula']) ? " CI: " . $rowInfo['cedula'] : " (No Cedulado)";
            $pacienteDetalle = $rowInfo['nombres'] . " " . $rowInfo['apellidos'] . $cedulaText;
        }
        mysqli_stmt_close($stmtInfo);

        // A. Eliminar Ingresos relacionados (Clave foránea)
        // Si no tienes configurado ON DELETE CASCADE en tu BD, debes hacer esto manualmente.
        $sqlIngresos = "DELETE FROM ingresos WHERE paciente_id = ?";
        $stmtIngresos = mysqli_prepare($conexion, $sqlIngresos);
        mysqli_stmt_bind_param($stmtIngresos, "i", $idPaciente);
        mysqli_stmt_execute($stmtIngresos);
        mysqli_stmt_close($stmtIngresos);

        // B. Eliminar Paciente
        $sqlPaciente = "DELETE FROM pacientes WHERE id = ?";
        $stmtPaciente = mysqli_prepare($conexion, $sqlPaciente);
        mysqli_stmt_bind_param($stmtPaciente, "i", $idPaciente);
        mysqli_stmt_execute($stmtPaciente);
        mysqli_stmt_close($stmtPaciente);

        // C. Registrar acción en la Bitácora
        if ($usuario_id > 0) {
            $accion = 'Delete';
            $descripcion = "Eliminación permanente del paciente y su historial. Paciente: " . $pacienteDetalle;
            
            $sqlBitacora = "INSERT INTO bitacora (usuario_id, accion, descripcion) VALUES (?, ?, ?)";
            $stmtBitacora = mysqli_prepare($conexion, $sqlBitacora);
            mysqli_stmt_bind_param($stmtBitacora, "iss", $usuario_id, $accion, $descripcion);
            mysqli_stmt_execute($stmtBitacora);
            mysqli_stmt_close($stmtBitacora);
        }

        // Si todo salió bien, confirmar cambios
        mysqli_commit($conexion);

        $respuesta['status'] = 'success';
        $respuesta['message'] = 'El paciente y su historial de ingresos fueron eliminados correctamente.';

    } catch (Exception $e) {
        // Si algo salió mal, revertir cambios
        mysqli_rollback($conexion);
        $respuesta['status'] = 'error';
        $respuesta['message'] = 'No se pudo eliminar el paciente. Error de base de datos: ' . $e->getMessage();
    }

} else {
    $respuesta['message'] = 'ID de paciente no proporcionado.';
}

// 4. Enviar respuesta en formato JSON
header('Content-Type: application/json');
echo json_encode($respuesta);
?>