<?php
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Methods: GET, POST");
header("Access-Control-Allow-Headers: Content-Type");

// Configuración de conexión
require_once '../conexion.php';
$method = $_SERVER['REQUEST_METHOD'];

switch ($method) {
    case 'GET':
        if (isset($_GET['cedula'])) {
            $cedula = $_GET['cedula'];
            // Usamos el nombre de columna exacto: cedula_identidad
            $stmt = $pdo->prepare("SELECT id, nombres, apellidos, fecha_nacimiento, cedula_identidad FROM pacientes WHERE cedula_identidad = ?");
            $stmt->execute([$cedula]);
            $paciente = $stmt->fetch();

            if ($paciente) {
                echo json_encode($paciente);
            } else {
                http_response_code(404);
                echo json_encode(["mensaje" => "No encontrado"]);
            }
        }
        break;

    case 'POST':
        $data = json_decode(file_get_contents("php://input"));
        if (!empty($data->nombres)) {
            try {
                $stmt = $pdo->prepare("INSERT INTO pacientes (nombres, apellidos, cedula_identidad, fecha_nacimiento) VALUES (?, ?, ?, ?)");
                $stmt->execute([
                    $data->nombres,
                    $data->apellidos,
                    $data->cedula_identidad,
                    $data->fecha_nacimiento
                ]);
                echo json_encode(["id" => $pdo->lastInsertId(), "mensaje" => "Registro exitoso"]);
            } catch (PDOException $e) {
                http_response_code(409);
                echo json_encode(["error" => "Cédula ya existe"]);
            }
        }
        break;
}