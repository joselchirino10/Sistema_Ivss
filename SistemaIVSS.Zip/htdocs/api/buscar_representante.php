<?php
require_once '../auth/sesion.php'; 

validarAcceso('Administrador'); 

require_once '../conexion.php';
header('Content-Type: application/json; charset=utf-8');

try {
    $conexion = new PDO("mysql:host=$host;dbname=$db;charset=utf8mb4", $user, $pass);
    $conexion->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $conexion->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    echo json_encode(["status" => "error", "message" => "Error de conexión: " . $e->getMessage()]);
    exit;
}

if (isset($_GET['cedula']) && !empty(trim($_GET['cedula']))) {
    $cedula = trim($_GET['cedula']);
    
    try {
        // 1. Buscar en tu tabla 'representantes' (Notar que uso 'ID', 'Nombres', 'Apellidos' y 'Cedula')
        $queryRep = "SELECT ID, Nombres, Apellidos FROM representantes WHERE Cedula = :cedula LIMIT 1";
        $stmtRep = $conexion->prepare($queryRep);
        $stmtRep->execute([':cedula' => $cedula]);
        $representante = $stmtRep->fetch();
        
        if ($representante) {
            
            // Extraemos el ID real (la llave primaria)
            $id_rep = $representante['ID'];
            
            // 2. Buscar en tu tabla 'pacientes' los que tienen ese id_representante
            // Uso 'id AS id_paciente' para que coincida con lo que tu Javascript espera leer
            $queryHijos = "SELECT id AS id_paciente, nombres, apellidos, fecha_nacimiento 
                           FROM pacientes 
                           WHERE id_representante = :id_rep"; 
            
            $stmtHijos = $conexion->prepare($queryHijos);
            $stmtHijos->execute([':id_rep' => $id_rep]);
            $hijos = $stmtHijos->fetchAll(); 

            // 3. Devolver la respuesta
            echo json_encode([
                "status" => "success",
                "existe" => true,
                "nombres" => $representante['Nombres'], 
                "apellidos" => $representante['Apellidos'],
                "representados" => $hijos 
            ]);

        } else {
            echo json_encode([
                "status" => "not_found",
                "existe" => false,
                "message" => "No se encontró ningún representante con esa cédula."
            ]);
        }

    } catch (PDOException $e) {
        echo json_encode(["status" => "error", "message" => "Error en la consulta: " . $e->getMessage()]);
    }

} else {
    echo json_encode(["status" => "error", "message" => "Cédula no proporcionada."]);
}
?>