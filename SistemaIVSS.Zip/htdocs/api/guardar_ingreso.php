<?php
require_once '../auth/sesion.php'; 
require_once '../conexion.php';

// Activamos el reporte de errores detallado
mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);

try {
    // 1. Captura y Limpieza estricta
    $es_no_cedulado = $_POST['es_no_cedulado'] ?? "0";
    $cedula_paciente = trim($_POST['cedula_paciente'] ?? '');
    $nombres_paciente = mysqli_real_escape_string($conexion, trim($_POST['nombres'] ?? ''));
    $apellidos_paciente = mysqli_real_escape_string($conexion, trim($_POST['apellidos'] ?? ''));
    $fecha_nacimiento = $_POST['fecha_nacimiento'] ?? '';
    $especialidad = $_POST['especialidad'] ?? $_POST['especialidad_pediatrica'] ?? 'No definida';
    
    $id_representante = "NULL"; // Valor por defecto para SQL
    $tipo_paciente_paciente = "Nuevo"; 
    $id_paciente_final = 0;

    // --- LÓGICA PARA REPRESENTANTE ---
    if ($es_no_cedulado == "1") {
        $cedula_rep = mysqli_real_escape_string($conexion, preg_replace('/[^0-9]/', '', $_POST['cedula_rep'] ?? ''));
        $nombres_rep = mysqli_real_escape_string($conexion, trim($_POST['nombres_rep'] ?? ''));
        $apellidos_rep = mysqli_real_escape_string($conexion, trim($_POST['apellidos_rep'] ?? ''));

        if (empty($cedula_rep)) {
            die("Error: La cédula del representante es obligatoria.");
        }

        $check_rep = mysqli_query($conexion, "SELECT ID FROM representantes WHERE Cedula = '$cedula_rep'");
        if ($row_r = mysqli_fetch_assoc($check_rep)) {
            $id_representante = $row_r['ID'];
        } else {
            mysqli_query($conexion, "INSERT INTO representantes (Nombres, Apellidos, Cedula) VALUES ('$nombres_rep', '$apellidos_rep', '$cedula_rep')");
            $id_representante = mysqli_insert_id($conexion);
        }
    }

    // --- LÓGICA PARA PACIENTE ---
    if ($es_no_cedulado == "1") {
        // CASO NIÑO: Buscamos por nombre y representante
        $check_p = mysqli_query($conexion, "SELECT id FROM pacientes WHERE nombres = '$nombres_paciente' AND apellidos = '$apellidos_paciente' AND id_representante = $id_representante");
        
        if ($row_p = mysqli_fetch_assoc($check_p)) {
            $id_paciente_final = $row_p['id'];
            $tipo_paciente_paciente = "Existente";
        } else {
            // IMPORTANTE: Dejamos 'cedula' fuera para que sea NULL y no choque con el UNIQUE
            $sql = "INSERT INTO pacientes (nombres, apellidos, fecha_nacimiento, id_representante, tipo) 
                    VALUES ('$nombres_paciente', '$apellidos_paciente', '$fecha_nacimiento', $id_representante, 'NO CEDULADO')";
            mysqli_query($conexion, $sql);
            $id_paciente_final = mysqli_insert_id($conexion);
        }
    } else {
        // CASO ADULTO: Buscamos por cédula
        if (empty($cedula_paciente)) die("Error: Cédula del paciente vacía.");

        $check_p = mysqli_query($conexion, "SELECT id FROM pacientes WHERE cedula = '$cedula_paciente'");
        
        if ($row_p = mysqli_fetch_assoc($check_p)) {
            $id_paciente_final = $row_p['id'];
            $tipo_paciente_paciente = "Existente";
        } else {
            $sql = "INSERT INTO pacientes (cedula, nombres, apellidos, fecha_nacimiento, tipo) 
                    VALUES ('$cedula_paciente', '$nombres_paciente', '$apellidos_paciente', '$fecha_nacimiento', 'CEDULADO')";
            mysqli_query($conexion, $sql);
            $id_paciente_final = mysqli_insert_id($conexion);
        }
    }

    // --- REGISTRO FINAL ---
    if ($id_paciente_final > 0) {
        $fecha_ingreso = date("Y-m-d H:i:s");
        mysqli_query($conexion, "INSERT INTO ingresos (paciente_id, especialidad, fecha_consulta, tipo_paciente) 
                                 VALUES ('$id_paciente_final', '$especialidad', '$fecha_ingreso', '$tipo_paciente_paciente')");
            
        // Bitácora
        $usuario_id = $_SESSION['usuario_id'] ?? 0;
        $id_txt = ($es_no_cedulado == "1") ? "Rep: $cedula_rep" : "CI: $cedula_paciente";
        $desc = "Ingreso $tipo_paciente_paciente - Paciente: $nombres_paciente $apellidos_paciente ($id_txt)";

        $stmt = $conexion->prepare("INSERT INTO bitacora (usuario_id, accion, descripcion) VALUES (?, 'Create', ?)");
        $stmt->bind_param("is", $usuario_id, $desc);
        $stmt->execute();
        
        header("Location: ../admin/gestion_pacientes.php?status=success_registro");
        exit();
    }

} catch (mysqli_sql_exception $e) {
    echo "<h3>Error de Base de Datos:</h3>";
    echo "<p>" . $e->getMessage() . "</p>";
    echo "<p>Código de error: " . $e->getCode() . "</p>";
}
?>