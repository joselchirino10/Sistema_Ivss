<?php
require_once '../auth/sesion.php'; 
require_once '../conexion.php'; 

validarAcceso('Administrador'); 

if (isset($conn) && !isset($conexion)) {
    $conexion = $conn;
}

if (!$conexion) {
    die("Error de conexión: " . mysqli_connect_error());
}

// 1. Inicializar variables para los filtros
$filtro_fecha = isset($_GET['fecha']) ? mysqli_real_escape_string($conexion, $_GET['fecha']) : '';
$filtro_especialidad = isset($_GET['especialidad']) ? mysqli_real_escape_string($conexion, $_GET['especialidad']) : '';
$filtro_paciente = isset($_GET['paciente']) ? mysqli_real_escape_string($conexion, $_GET['paciente']) : '';

// --- CONFIGURACIÓN DE PAGINACIÓN ---
$registros_por_pagina = 10; // Puedes cambiar esto a 15, 20, etc.
$pagina_actual = isset($_GET['pagina']) && is_numeric($_GET['pagina']) ? (int)$_GET['pagina'] : 1;
if ($pagina_actual < 1) $pagina_actual = 1;
$offset = ($pagina_actual - 1) * $registros_por_pagina;

// 2. Construir la condición WHERE dinámicamente
$condiciones = "1=1";
if (!empty($filtro_fecha)) {
    $condiciones .= " AND i.fecha_consulta = '$filtro_fecha'";
}
if (!empty($filtro_especialidad)) {
    $condiciones .= " AND i.especialidad = '$filtro_especialidad'";
}
if (!empty($filtro_paciente)) {
    $condiciones .= " AND (p.nombres LIKE '%$filtro_paciente%' OR p.apellidos LIKE '%$filtro_paciente%' OR p.cedula LIKE '%$filtro_paciente%')";
}

// 3. Consulta para saber el total de registros EXACTOS con esos filtros
$sql_count = "SELECT COUNT(*) as total FROM ingresos i INNER JOIN pacientes p ON i.paciente_id = p.id WHERE $condiciones";
$result_count = mysqli_query($conexion, $sql_count);
$row_count = mysqli_fetch_assoc($result_count);
$total_registros = $row_count['total'];

// Calcular cuántas páginas hay en total
$total_paginas = ceil($total_registros / $registros_por_pagina);

// 4. Consulta final con LIMIT y OFFSET
$sql = "SELECT i.id AS ingreso_id, p.nombres, p.apellidos, p.cedula, p.tipo, i.fecha_consulta, i.tipo_paciente, i.especialidad 
        FROM ingresos i
        INNER JOIN pacientes p ON i.paciente_id = p.id
        WHERE $condiciones
        ORDER BY i.fecha_consulta DESC, i.id DESC
        LIMIT $registros_por_pagina OFFSET $offset";

$resultado = mysqli_query($conexion, $sql);

// Mantener los filtros en la URL al cambiar de página
$query_params = $_GET;
unset($query_params['pagina']); 
$query_string = http_build_query($query_params);
$query_string = $query_string ? '&' . $query_string : '';
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>IVSS - Historial de Ingresos</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;600&family=Montserrat:wght@500;600&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="../estilos.css">
    <style>
        /* Estilos para la paginación */
        .pagination { display: flex; justify-content: center; align-items: center; gap: 8px; margin-top: 20px; padding: 10px 0; }
        .pagination a { padding: 8px 12px; border: 1px solid #ddd; border-radius: 6px; text-decoration: none; color: #0056b3; font-weight: 500; transition: 0.3s; font-size: 0.9rem; }
        .pagination a:hover { background-color: #e3f2fd; border-color: #0056b3; }
        .pagination a.active { background-color: #0056b3; color: white; border-color: #0056b3; }
        .pagination-info { text-align: center; color: #666; font-size: 0.85rem; margin-top: 10px; }
    </style>
</head>
<body class="page-historial-ingresos">

    <nav class="navbar">
        <div class="navbar-content">
            <img src="../assets/seguro.png" alt="Logo" class="navbar-logo">
            <span class="navbar-text">
                DEPARTAMENTO DE REGISTRO Y ESTADÍSTICA <br> 
                HOSPITAL DR. RAFAEL GALLARDO - CORO
            </span>
        </div>
    </nav>

    <div class="app-container">
        <aside class="sidebar">
            <a href="dashboard_admin.php" class="menu-item"><i class="fas fa-th-large"></i> Dashboard</a>
            <a href="registrar_ingreso.php" class="menu-item"><i class="fas fa-user-plus"></i> Registro Ingresos</a>
            <a href="gestion_ingresos.php" class="menu-item active"><i class="fas fa-list-alt"></i> Historial Ingresos</a>
            <a href="gestion_pacientes.php" class="menu-item"><i class="fas fa-search"></i> Gestion Pacientes</a>
            <a href="estadisticas.php" class="menu-item"><i class="fas fa-chart-pie"></i> Estadísticas</a>
            <a href="gestion_usuarios.php" class="menu-item"><i class="fas fa-user-shield"></i> Gestión Usuarios</a>
            <a href="bitacora.php" class="menu-item"><i class="fas fa-book"></i> Bitácora</a>
            
            <div style="margin-top: auto; padding-top: 20px; border-top: 1px solid rgba(255,255,255,0.1);">
                <a href="../auth/logout.php" class="menu-item" style="color: #ff7675; font-weight: 600;">
                    <i class="fas fa-sign-out-alt"></i> Cerrar Sesión
                </a>
            </div> 
        </aside>

        <main class="main">
            <div class="search-container">
                <div class="filter-box">
                    <h2><i class="fas fa-filter"></i> Filtrar Ingresos</h2>
                    <form method="GET" action="gestion_ingresos.php" class="filter-form">
                        <div class="form-group">
                            <label>Fecha de Consulta</label>
                            <input type="date" name="fecha" class="input-control" value="<?php echo htmlspecialchars($filtro_fecha); ?>">
                        </div>
                        
                        <div class="form-group">
                            <label>Especialidad</label>
                            <select name="especialidad" class="input-control">
                                <option value="">Todas las especialidades</option>
                                <?php
                                $especialidades = ['Neumonología','Pediatría','Cardiología','Nefrología','Medicina Interna','Traumatología','Dermatología'];
                                foreach ($especialidades as $esp) {
                                    $selected = ($filtro_especialidad == $esp) ? 'selected' : '';
                                    echo "<option value=\"$esp\" $selected>$esp</option>";
                                }
                                ?>
                            </select>
                        </div>

                        <div class="form-group">
                            <label>Paciente (Cédula o Nombre)</label>
                            <input type="text" name="paciente" class="input-control" placeholder="Ej. 30401423" value="<?php echo htmlspecialchars($filtro_paciente); ?>">
                        </div>

                        <button type="submit" class="btn-search"><i class="fas fa-search"></i> Filtrar</button>
                        <a href="gestion_ingresos.php" class="btn-reset"><i class="fas fa-times"></i> Limpiar</a>
                    </form>
                </div>
            </div>

            <div class="search-container" style="margin-top: 0;">
                <div class="table-section">
                    <?php if (mysqli_num_rows($resultado) > 0): ?>
                        <table>
                           <thead>
                                <tr>
                                    <th>ID Ingreso</th>
                                    <th>Fecha</th>
                                    <th>Paciente</th>
                                    <th>Cédula</th>
                                    <th>Tipo Paciente</th>
                                    <th>Especialidad</th>
                                    <th>Acciones</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php while ($row = mysqli_fetch_assoc($resultado)): 
                                    $clase_tipo = ($row['tipo_paciente'] == 'Nuevo') ? 'badge-nuevo' : 'badge-existente';
                                    $cedula_mostrar = !empty($row['cedula']) ? $row['cedula'] : 'N/A (' . $row['tipo'] . ')';
                                    $especialidad_mostrar = !empty($row['especialidad']) ? $row['especialidad'] : 'No asignada';
                                ?>
                                    <tr>
                                        <td><strong>#<?php echo $row['ingreso_id']; ?></strong></td>
                                        <td><?php echo date('d/m/Y', strtotime($row['fecha_consulta'])); ?></td>
                                        <td><?php echo htmlspecialchars($row['nombres'] . ' ' . $row['apellidos']); ?></td>
                                        <td><?php echo $cedula_mostrar; ?></td>
                                        <td><span class="badge <?php echo $clase_tipo; ?>"><?php echo $row['tipo_paciente']; ?></span></td>
                                        <td>
                                            <?php if($especialidad_mostrar != 'No asignada'): ?>
                                                <span class="badge badge-especialidad"><?php echo $especialidad_mostrar; ?></span>
                                            <?php else: ?>
                                                <span style="color: #95a5a6; font-size: 0.85rem;">No asignada</span>
                                            <?php endif; ?>
                                        </td>
                                        <td>
                                            <button type="button" class="btn-delete" onclick="eliminarIngreso(<?php echo $row['ingreso_id']; ?>)">
                                                <i class="fas fa-trash-alt"></i>
                                            </button>
                                        </td>
                                    </tr>
                                <?php endwhile; ?>
                            </tbody>
                        </table>

                        <!-- RENDERIZAR PAGINACIÓN -->
                        <?php if ($total_paginas > 1): ?>
                            <div class="pagination">
                                <?php if ($pagina_actual > 1): ?>
                                    <a href="?pagina=<?php echo $pagina_actual - 1; ?><?php echo $query_string; ?>">&laquo; Anterior</a>
                                <?php endif; ?>

                                <?php for ($i = 1; $i <= $total_paginas; $i++): ?>
                                    <a href="?pagina=<?php echo $i; ?><?php echo $query_string; ?>" class="<?php echo ($i == $pagina_actual) ? 'active' : ''; ?>">
                                        <?php echo $i; ?>
                                    </a>
                                <?php endfor; ?>

                                <?php if ($pagina_actual < $total_paginas): ?>
                                    <a href="?pagina=<?php echo $pagina_actual + 1; ?><?php echo $query_string; ?>">Siguiente &raquo;</a>
                                <?php endif; ?>
                            </div>
                        <?php endif; ?>
                        
                        <div class="pagination-info">
                            Mostrando página <?php echo $pagina_actual; ?> de <?php echo $total_paginas; ?> (<?php echo $total_registros; ?> registros en total)
                        </div>

                    <?php else: ?>
                        <div class="empty-state">
                            <h3>No se encontraron registros</h3>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </main>
    </div>
    
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <script>
    function eliminarIngreso(idIngreso) {
        Swal.fire({
            title: '¿Estás segura/o?',
            text: "Se eliminará el registro de ingreso #" + idIngreso,
            icon: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#e74c3c',
            confirmButtonText: 'Sí, eliminar',
            heightAuto: false
        }).then((result) => {
            if (result.isConfirmed) {
                fetch('../api/eliminar_ingreso.php', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                    body: `id=${idIngreso}`
                })
                .then(response => response.json())
                .then(data => {
                    if (data.status === 'success') {
                        Swal.fire('¡Eliminado!', '', 'success').then(() => {
                            window.location.reload();
                        });
                    } else {
                        Swal.fire('Error', data.message, 'error');
                    }
                });
            }
        });
    }
    </script>
</body>
</html>