<?php
require_once '../auth/sesion.php'; 

require_once '../conexion.php'; 

validarAcceso('Administrador'); 


if (!$conexion) {
    die("Error de conexión: " . mysqli_connect_error());
}

// LÓGICA DE FILTRADO POR FECHAS

$fecha_inicio = isset($_GET['fecha_inicio']) ? $_GET['fecha_inicio'] : '';
$fecha_fin = isset($_GET['fecha_fin']) ? $_GET['fecha_fin'] : '';

$where_pacientes = "";
$where_ingresos = "";

// Si ambas fechas fueron enviadas, armamos la condición SQL
if (!empty($fecha_inicio) && !empty($fecha_fin)) {
    // Sanitizamos para evitar inyecciones SQL
    $inicio_safe = mysqli_real_escape_string($conexion, $fecha_inicio);
    $fin_safe = mysqli_real_escape_string($conexion, $fecha_fin);
    
    // Filtramos pacientes por fecha de creación y los ingresos por fecha de consulta
    $where_pacientes = " WHERE DATE(fecha_creacion) BETWEEN '$inicio_safe' AND '$fin_safe'";
    $where_ingresos = " WHERE fecha_consulta BETWEEN '$inicio_safe' AND '$fin_safe'";
}


// CONSULTAS ESTADÍSTICAS (Con o sin filtro)


// 1. Total de Pacientes Registrados
$query_pacientes = "SELECT COUNT(*) as total FROM pacientes" . $where_pacientes;
$res_pacientes = mysqli_query($conexion, $query_pacientes);
$total_pacientes = mysqli_fetch_assoc($res_pacientes)['total'];

// 2. Total de Ingresos Registrados
$query_ingresos = "SELECT COUNT(*) as total FROM ingresos" . $where_ingresos;
$res_ingresos = mysqli_query($conexion, $query_ingresos);
$total_ingresos = mysqli_fetch_assoc($res_ingresos)['total'];

// 3. Ingresos por Especialidad (Para Gráfico Circular)
$query_esp = "SELECT IF(especialidad='', 'Sin Especificar', especialidad) as nombre_esp, COUNT(*) as cantidad FROM ingresos" . $where_ingresos . " GROUP BY nombre_esp";
$res_esp = mysqli_query($conexion, $query_esp);
$labels_esp = [];
$data_esp = [];
while($row = mysqli_fetch_assoc($res_esp)){
    $labels_esp[] = $row['nombre_esp'];
    $data_esp[] = $row['cantidad'];
}

// 4. Ingresos por Tipo de Paciente (Nuevo vs Existente)
$query_tipo = "SELECT tipo_paciente, COUNT(*) as cantidad FROM ingresos" . $where_ingresos . " GROUP BY tipo_paciente";
$res_tipo = mysqli_query($conexion, $query_tipo);
$labels_tipo = [];
$data_tipo = [];
while($row = mysqli_fetch_assoc($res_tipo)){
    $labels_tipo[] = $row['tipo_paciente'];
    $data_tipo[] = $row['cantidad'];
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>IVSS - Estadísticas Generales</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;600&family=Montserrat:wght@500;600&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <link rel="stylesheet" href="../estilos.css">
</head>
<body class="page-estadisticas ivss-app-body">

    <nav class="navbar">
        <div class="navbar-content">
            <img src="../assets/seguro.png" alt="Logo" class="navbar-logo" onerror="this.src='https://via.placeholder.com/55?text=IVSS'">
            <span class="navbar-text">
                DEPARTAMENTO DE REGISTRO Y ESTADÍSTICA <br> 
                HOSPITAL DR. RAFAEL GALLARDO - CORO
            </span>
        </div>
    </nav>

    <div class="app-container">
        <aside class="sidebar">
            <a href="dashboard_admin.php" class="menu-item"><i class="fas fa-th-large"></i> Dashboard</a>
            <a href="registrar_ingreso.php" class="menu-item"><i class="fas fa-user-plus"></i> Registro Ingresos</a>
            <a href="gestion_ingresos.php" class="menu-item"><i class="fas fa-list-alt"></i> Historial Ingresos</a>
            <a href="gestion_pacientes.php" class="menu-item"><i class="fas fa-search"></i> Gestion Pacientes</a>
            <a href="estadisticas.php" class="menu-item active"><i class="fas fa-chart-pie"></i> Estadísticas</a>
            <a href="gestion_usuarios.php" class="menu-item"><i class="fas fa-user-shield"></i> Gestión Usuarios</a>
            <a href="bitacora.php" class="menu-item"><i class="fas fa-book"></i> Bitácora</a>
            
            <div style="margin-top: auto; padding-top: 20px; border-top: 1px solid rgba(255,255,255,0.1);">
                <a href="../auth/logout.php" class="menu-item" style="color: #ff7675; font-weight: 600;">
                    <i class="fas fa-sign-out-alt"></i> Cerrar Sesión
                </a>
            </div>
        </aside>

        <main class="main">
            <div class="container">
                
                <div class="filter-card">
                    <h3><i class="fas fa-calendar-alt"></i> Filtro de Búsqueda</h3>
                    <form method="GET" action="estadisticas.php" class="filter-form">
                        <div class="form-group">
                            <label for="fecha_inicio">Desde:</label>
                            <input type="date" id="fecha_inicio" name="fecha_inicio" value="<?php echo htmlspecialchars($fecha_inicio); ?>" required>
                        </div>
                        <div class="form-group">
                            <label for="fecha_fin">Hasta:</label>
                            <input type="date" id="fecha_fin" name="fecha_fin" value="<?php echo htmlspecialchars($fecha_fin); ?>" required>
                        </div>
                        <button type="submit" class="btn-filter"><i class="fas fa-filter"></i> Aplicar Filtro</button>
                        <a href="estadisticas.php" class="btn-clear"><i class="fas fa-eraser"></i> Limpiar</a>
                    </form>
                </div>

                <div class="stats-grid">
                    <div class="stat-card blue-border">
                        <div class="icon-box"><i class="fas fa-users"></i></div>
                        <div class="stat-info">
                            <h3><?php echo $total_pacientes; ?></h3>
                            <p>Pacientes Registrados</p>
                        </div>
                    </div>
                    
                    <div class="stat-card">
                        <div class="icon-box"><i class="fas fa-file-medical-alt"></i></div>
                        <div class="stat-info">
                            <h3><?php echo $total_ingresos; ?></h3>
                            <p>Ingresos Totales</p>
                        </div>
                    </div>
                </div>

                <div class="charts-wrapper">
                    <div class="chart-box">
                        <h2><i class="fas fa-stethoscope"></i> Ingresos por Especialidad</h2>
                        <div class="canvas-container">
                            <?php if(empty($data_esp)): ?>
                                <p class="no-data">No hay datos en este rango de fechas.</p>
                            <?php else: ?>
                                <canvas id="graficoEspecialidades"></canvas>
                            <?php endif; ?>
                        </div>
                    </div>

                    <div class="chart-box">
                        <h2><i class="fas fa-user-tag"></i> Tipo de Paciente (Ingresos)</h2>
                        <div class="canvas-container">
                            <?php if(empty($data_tipo)): ?>
                                <p class="no-data">No hay datos en este rango de fechas.</p>
                            <?php else: ?>
                                <canvas id="graficoTipoPaciente"></canvas>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>

            </div>
        </main>
    </div>

    <script>
        const labelsEsp = <?php echo json_encode($labels_esp); ?>;
        const dataEsp = <?php echo json_encode($data_esp); ?>;
        const labelsTipo = <?php echo json_encode($labels_tipo); ?>;
        const dataTipo = <?php echo json_encode($data_tipo); ?>;

        const coloresGraficos = ['#0056b3', '#00d1b2', '#fdcb6e', '#e17055', '#6c5ce7', '#00b894', '#e84393'];

        if(document.getElementById('graficoEspecialidades')) {
            const ctxEsp = document.getElementById('graficoEspecialidades').getContext('2d');
            new Chart(ctxEsp, {
                type: 'doughnut',
                data: {
                    labels: labelsEsp,
                    datasets: [{
                        data: dataEsp,
                        backgroundColor: coloresGraficos,
                        borderWidth: 2,
                        borderColor: '#ffffff'
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    plugins: { legend: { position: 'bottom' } }
                }
            });
        }

        if(document.getElementById('graficoTipoPaciente')) {
            const ctxTipo = document.getElementById('graficoTipoPaciente').getContext('2d');
            new Chart(ctxTipo, {
                type: 'pie',
                data: {
                    labels: labelsTipo,
                    datasets: [{
                        data: dataTipo,
                        backgroundColor: ['#00d1b2', '#0056b3'],
                        borderWidth: 2,
                        borderColor: '#ffffff'
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    plugins: { legend: { position: 'bottom' } }
                }
            });
        }
    </script>
</body>
</html>