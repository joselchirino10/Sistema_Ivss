<?php
require_once '../auth/sesion.php';

validarAcceso('Administrador'); 

// Conexión básica para obtener los datos del administrador
require_once '../conexion.php';
// ID del administrador (ajustar según sesión)
$mi_id = $_SESSION['usuario_id'] ?? 2; 
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Eliminar Cuenta - IVSS</title>
    <link rel="stylesheet" href="../assets/style.css">
    <style>
        .alert { padding: 15px; border-radius: 6px; margin-bottom: 20px; font-size: 0.9rem; line-height: 1.4; }
        .alert-warning { background: #fff3cd; color: #856404; border: 1px solid #ffeeba; }
        .hidden { display: none; }
    </style>
</head>
<body>
    <div class="container">
        <header>
            <h1>Confirmar Eliminación</h1>
        </header>

        <div id="email-step">
            <div class="alert alert-warning">
                <strong>Atención:</strong> Para eliminar su cuenta de administrador, primero debe generar un código de verificación que será enviado a su correo registrado.
            </div>
            <button type="button" id="btnGenerar" onclick="solicitarCodigo()">Generar Código de Verificación</button>
        </div>

        <div id="validate-step" class="hidden">
            <div class="form-group">
                <label>Ingrese el código enviado a su correo:</label>
                <input type="text" id="codigo_input" maxlength="6" placeholder="******" style="text-align: center; letter-spacing: 5px; font-size: 1.2rem;">
            </div>
            <button type="button" class="btn-red" onclick="procesarBorradoFinal()">Eliminar Cuenta Permanentemente</button>
            <p id="msg-error" class="error-text hidden" style="margin-top:10px;">Código incorrecto o error en el sistema.</p>
        </div>

        <a href="dashboard_admin.php" class="btn-link">Cancelar y volver al panel</a>
    </div>

    <script>
        function solicitarCodigo() {
            const btn = document.getElementById('btnGenerar');
            btn.disabled = true;
            btn.innerText = "Enviando...";

            fetch('../api/procesar_verificacion.php?accion=enviar_mail', { method: 'POST' })
            .then(res => res.json())
            .then(data => {
                if (data.status === 'success') {
                    document.getElementById('email-step').classList.add('hidden');
                    document.getElementById('validate-step').classList.remove('hidden');
                } else {
                    alert("Error SMTP: " + data.message + "\n\nVerifique que su contraseña de aplicación de Gmail sea correcta.");
                    btn.disabled = false;
                    btn.innerText = "Reintentar Envío";
                }
            });
        }

        function procesarBorradoFinal() {
            const cod = document.getElementById('codigo_input').value;
            fetch('../api/procesar_verificacion.php?accion=finalizar_borrado', {
                method: 'POST',
                headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                body: 'codigo=' + cod
            })
            .then(res => res.json())
            .then(data => {
                if (data.status === 'success') {
                    alert("Cuenta eliminada exitosamente.");
                    window.location.href = '../auth/login.html';
                } else {
                    document.getElementById('msg-error').classList.remove('hidden');
                }
            });
        }
    </script>
</body>
</html>