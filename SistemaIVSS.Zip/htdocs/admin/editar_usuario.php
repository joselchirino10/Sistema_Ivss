<?php
// --- LÓGICA DE PHP (Procesamiento) ---
$mensaje = "";
$tipo_alerta = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Sustitución de las líneas de conexión manual por el archivo centralizado
    require_once '../conexion.php'; 

    // Verificamos que la variable de conexión ($conn) exista en el archivo requerido
    if ($conn->connect_error) {
        $mensaje = "Error de conexión: " . $conn->connect_error;
        $tipo_alerta = "error";
    } else {
        $nombre = $_POST['nombre'];
        $apellido = $_POST['apellido'];
        $cedula = $_POST['cedula'];
        $username = $_POST['username'];
        $password = $_POST['password'];

        // Encriptar contraseña para que el login la reconozca
        $password_segura = password_hash($password, PASSWORD_DEFAULT);

        // Insertar en la tabla
        $sql = "INSERT INTO usuarios_sistema (nombre, apellidos, cedula, username, password_hash, tipo_usuario) 
                VALUES (?, ?, ?, ?, ?, 'Regular')";
        
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("sssss", $nombre, $apellido, $cedula, $username, $password_segura);

        if ($stmt->execute()) {
            $mensaje = "¡Usuario <b>$username</b> registrado con éxito! Ya puedes probar el login.";
            $tipo_alerta = "success";
        } else {
            $mensaje = "Error: " . $conn->error;
            $tipo_alerta = "error";
        }
        $stmt->close();
        $conn->close();
    }
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registro de Usuario - IVSS</title>
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@500;600&display=swap" rel="stylesheet">
    <style>
        /* Estilos mantenidos */
        body { font-family: 'Montserrat', sans-serif; background-color: #f4f7f6; margin: 0; padding: 0; }
        .container { max-width: 500px; margin: 50px auto; padding: 20px; }
        header { text-align: center; margin-bottom: 30px; }
        .card { background: white; padding: 30px; border-radius: 8px; box-shadow: 0 4px 10px rgba(0,0,0,0.1); border-top: 5px solid #0056b3; }
        .form-group { margin-bottom: 15px; }
        label { display: block; margin-bottom: 5px; font-weight: 600; font-size: 0.9rem; }
        input { width: 100%; padding: 10px; border: 1px solid #ccc; border-radius: 4px; box-sizing: border-box; }
        .btn-primary { width: 100%; background: #0056b3; color: white; border: none; padding: 12px; border-radius: 4px; cursor: pointer; font-weight: 600; margin-top: 10px; }
        .btn-primary:hover { background: #004494; }
        .alert { padding: 15px; border-radius: 4px; margin-bottom: 20px; text-align: center; font-size: 0.9rem; }
        .success { background-color: #d4edda; color: #155724; border: 1px solid #c3e6cb; }
        .error { background-color: #f8d7da; color: #721c24; border: 1px solid #f5c6cb; }
        .footer-links { text-align: center; margin-top: 20px; }
        a { color: #0056b3; text-decoration: none; font-size: 0.9rem; }
    </style>
</head>
<body>

<div class="container">
    <header>
        <h1>Crear Cuenta</h1>
        <p>Personal del Hospital Dr. Rafael Gallardo</p>
    </header>

    <?php if ($mensaje): ?>
        <div class="alert <?php echo $tipo_alerta; ?>">
            <?php echo $mensaje; ?>
        </div>
    <?php endif; ?>

    <div class="card">
        <form method="POST" action="">
            <div class="form-group">
                <label>Nombre</label>
                <input type="text" name="nombre" required placeholder="Ej. Ana">
            </div>
            <div class="form-group">
                <label>Apellido</label>
                <input type="text" name="apellido" required placeholder="Ej. García">
            </div>
            <div class="form-group">
                <label>Cédula</label>
                <input type="text" name="cedula" required placeholder="Ej. 26123456">
            </div>
            <div class="form-group">
                <label>Nombre de Usuario</label>
                <input type="text" name="username" required placeholder="Ej. agarcia">
            </div>
            <div class="form-group">
                <label>Contraseña</label>
                <input type="password" name="password" required placeholder="••••••••">
            </div>
            <button type="submit" class="btn-primary">Registrar Usuario</button>
        </form>
    </div>

    <div class="footer-links">
        <a href="login.html">← Volver al Inicio de Sesión</a>
    </div>
</div>

</body>
</html>