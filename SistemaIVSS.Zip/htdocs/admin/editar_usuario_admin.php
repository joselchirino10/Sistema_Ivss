<?php
require_once '../auth/sesion.php';

validarAcceso('Administrador'); 

require_once '../conexion.php';
// 2. VALIDACIÓN DE PERMISOS
$mi_id = $_SESSION['usuario_id'] ?? 2; 

$stmt_yo = $pdo->prepare("SELECT * FROM usuarios_sistema WHERE id_sistema = ?");
$stmt_yo->execute([$mi_id]);
$datos_admin = $stmt_yo->fetch();

if (!$datos_admin || $datos_admin['tipo_usuario'] !== 'Administrador') {
    die("Acceso denegado: Se requieren privilegios de Administrador.");
}

// 3. OBTENER ID DEL USUARIO A EDITAR
$id_a_editar = $_GET['id'] ?? null;

// Si no hay ID o el ID es el mismo del usuario logueado, lo mandamos a la tabla
if (!$id_a_editar || $id_a_editar == $mi_id) { 
    header("Location: gestion_usuarios.php"); 
    exit; 
}

// 4. CONSULTAR DATOS DEL OBJETIVO
$stmt_user = $pdo->prepare("SELECT * FROM usuarios_sistema WHERE id_sistema = ?");
$stmt_user->execute([$id_a_editar]);
$u = $stmt_user->fetch();

if (!$u) { die("Usuario no encontrado."); }

// Validación de seguridad extra: Evitar que edite a otro Admin por URL
if ($u['tipo_usuario'] === 'Administrador') {
    die("Seguridad: No tienes permiso para editar a otro Administrador.");
}

// 5. PROCESAR EL FORMULARIO
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nombre = $_POST['nombre'];
    $apellidos = $_POST['apellidos'];
    $correo = $_POST['correo'];
    $rol = $_POST['tipo_usuario'];
    $estado = $_POST['estado'];

    try {
        $sql = "UPDATE usuarios_sistema SET nombre = ?, apellidos = ?, correo = ?, tipo_usuario = ?, estado = ? WHERE id_sistema = ?";
        $pdo->prepare($sql)->execute([$nombre, $apellidos, $correo, $rol, $estado, $id_a_editar]);
        
        // Redirigir a gestión de usuarios con mensaje de éxito
        header("Location: gestion_usuarios.php?accion=actualizado");
        exit;
    } catch (PDOException $e) {
        $error_msj = "Error al guardar en base de datos.";
    }
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>IVSS - Modificar Personal</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600&family=Montserrat:wght@500;600&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        :root { --primary-blue: #0056b3; --dark-blue: #003366; --accent: #00d1b2; --bg: #f0f2f5; --white: #ffffff; --text: #2d3436; --sidebar-width: 260px; --navbar-height: 80px; }
        * { margin: 0; padding: 0; box-sizing: border-box; font-family: 'Inter', sans-serif; }
        body { background-color: var(--bg); color: var(--text); height: 100vh; display: flex; flex-direction: column; overflow: hidden; }

        .navbar { height: var(--navbar-height); background: var(--primary-blue); display: flex; align-items: center; padding: 0 2rem; border-bottom: 3px solid var(--accent); z-index: 1000; }
        .navbar-content { display: flex; align-items: center; gap: 15px; }
        .navbar-logo { height: 50px; }
        .navbar-text { font-family: 'Montserrat', sans-serif; font-size: 0.9rem; font-weight: 600; color: white; line-height: 1.2; }

        .app-container { display: flex; flex: 1; overflow: hidden; }

        .sidebar { width: var(--sidebar-width); background: var(--dark-blue); color: white; padding: 2rem 1rem; display: flex; flex-direction: column; gap: 10px; }
        .menu-item { padding: 12px 15px; color: #cbd5e0; text-decoration: none; display: flex; align-items: center; gap: 12px; border-radius: 8px; transition: 0.3s; font-size: 0.9rem; }
        .menu-item:hover, .menu-item.active { background: rgba(255,255,255,0.1); color: white; }
        .menu-item.active { background: var(--primary-blue); }

        .main-content { flex: 1; overflow-y: auto; padding: 2.5rem; display: flex; justify-content: center; align-items: flex-start; }
        .card-form { background: var(--white); border-radius: 15px; padding: 2.5rem; box-shadow: 0 10px 25px rgba(0,0,0,0.05); width: 100%; max-width: 600px; }
        
        .header-title { margin-bottom: 2rem; border-bottom: 2px solid #f0f2f5; padding-bottom: 1rem; }
        .form-row { display: flex; gap: 20px; }
        .form-group { margin-bottom: 1.5rem; flex: 1; }
        .form-group label { display: block; margin-bottom: 8px; font-weight: 600; font-size: 0.85rem; color: #555; }
        .form-group input, .form-group select { width: 100%; padding: 12px; border: 1px solid #ddd; border-radius: 10px; font-size: 0.95rem; background: #fdfdfd; }
        .form-group input:focus, .form-group select:focus { border-color: var(--primary-blue); outline: none; box-shadow: 0 0 0 3px rgba(0,86,179,0.1); }

        .btn-save { background: #f39c12; color: white; border: none; padding: 14px; width: 100%; border-radius: 10px; font-weight: 600; cursor: pointer; transition: 0.3s; font-size: 1rem; }
        .btn-save:hover { background: #d68910; }
        .back-link { display: block; text-align: center; margin-top: 20px; color: #666; text-decoration: none; font-size: 0.85rem; font-weight: 500; }
    </style>
</head>
<body>
    <nav class="navbar">
        <div class="navbar-content">
            <img src="seguro.png" alt="Logo" class="navbar-logo">
            <span class="navbar-text">DEPARTAMENTO DE REGISTRO Y ESTADÍSTICA <br> HOSPITAL DR. RAFAEL GALLARDO</span>
        </div>
    </nav>

    <div class="app-container">
        <aside class="sidebar">
            <a href="dashboard_admin.php" class="menu-item"><i class="fas fa-th-large"></i> Dashboard</a>
            <a href="registrar_ingreso.php" class="menu-item"><i class="fas fa-user-plus"></i> Registrar Ingreso</a>
            <a href="gestion_pacientes.php" class="menu-item"><i class="fas fa-search"></i> Gestion Pacientes</a>
            <a href="gestion_usuarios.php" class="menu-item active"><i class="fas fa-user-shield"></i> Gestión Usuarios</a>
            <a href="bitacora.php" class="menu-item"><i class="fas fa-book"></i> Bitácora</a>
            
            <div style="margin-top: auto; padding-top: 20px; border-top: 1px solid rgba(255,255,255,0.1);">
                <a href="logout.php" class="menu-item" style="color: #ff7675;"><i class="fas fa-sign-out-alt"></i> Cerrar Sesión</a>
            </div>
        </aside>

        <main class="main-content">
            <div class="card-form">
                <div class="header-title">
                    <h2 style="color: var(--dark-blue);"><i class="fas fa-user-edit"></i> Modificar Personal</h2>
                    <p style="color: #888; font-size: 0.85rem;">Cambiando permisos de: <strong><?= htmlspecialchars($u['username']) ?></strong></p>
                </div>

                <?php if(isset($error_msj)) echo "<div style='color:red; margin-bottom:15px; font-size:0.9rem;'>$error_msj</div>"; ?>

                <form method="POST">
                    <div class="form-row">
                        <div class="form-group">
                            <label>Nombre(s)</label>
                            <input type="text" name="nombre" value="<?= htmlspecialchars($u['nombre']) ?>" required>
                        </div>
                        <div class="form-group">
                            <label>Apellido(s)</label>
                            <input type="text" name="apellidos" value="<?= htmlspecialchars($u['apellidos']) ?>" required>
                        </div>
                    </div>

                    <div class="form-group">
                        <label>Correo Electrónico</label>
                        <input type="email" name="correo" value="<?= htmlspecialchars($u['correo']) ?>" required>
                    </div>

                    <div class="form-row">
                        <div class="form-group">
                            <label>Rol en el Sistema</label>
                            <select name="tipo_usuario">
                                <option value="Regular" <?= $u['tipo_usuario'] == 'Regular' ? 'selected' : '' ?>>Regular</option>
                                <option value="Soporte" <?= $u['tipo_usuario'] == 'Soporte' ? 'selected' : '' ?>>Soporte</option>
                            </select>
                        </div>
                        <div class="form-group">
                            <label>Estado de la Cuenta</label>
                            <select name="estado">
                                <option value="activo" <?= $u['estado'] == 'activo' ? 'selected' : '' ?>>Activo</option>
                                <option value="inactivo" <?= $u['estado'] == 'inactivo' ? 'selected' : '' ?>>Inactivo / Bloqueado</option>
                            </select>
                        </div>
                    </div>

                    <button type="submit" class="btn-save">Guardar Cambios</button>
                    <a href="gestion_usuarios.php" class="back-link">Cancelar y regresar a la tabla</a>
                </form>
            </div>
        </main>
    </div>
</body>
</html>