<?php
require_once '../auth/sesion.php'; 
require_once '../conexion.php'; 

validarAcceso('Administrador'); 
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>IVSS - Gestion Pacientes</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;600&family=Montserrat:wght@500;600&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="../estilos.css">
    
</head>
<body class="page-gestion-pacientes">

    <nav class="navbar">
        <div class="navbar-content">
            <img src="../assets/seguro.png" alt="Logo" class="navbar-logo" onerror="this.src='https://via.placeholder.com/55?text=IVSS'">
            <span class="navbar-text">
                DEPARTAMENTO DE REGISTRO Y ESTADÍSTICA <br> 
                HOSPITAL DR. RAFAEL GALLARDO - CORO
            </span>
        </div>
    </nav>

    <div class="app-container">
        
       
    <aside class="sidebar">
            <div class="menu-item" onclick="window.location.href='dashboard_admin.php'">
                <i class="fas fa-th-large"></i> Dashboard
            </div>
            <div class="menu-item" onclick="window.location.href='registrar_ingreso.php'">
                <i class="fas fa-user-plus"></i> Registro Ingresos
            </div>
            <a href="gestion_ingresos.php" class="menu-item"><i class="fas fa-list-alt"></i> Historial Ingresos</a>
            <div class="menu-item active" onclick="window.location.href='gestion_pacientes.php'">
                <i class="fas fa-search"></i> Gestion Pacientes
            </div>
            
            <a href="estadisticas.php" class="menu-item"><i class="fas fa-chart-pie"></i> Estadísticas</a>
            <a href="gestion_usuarios.php" class="menu-item"><i class="fas fa-user-shield"></i> Gestión Usuarios</a>
            <div class="menu-item" onclick="window.location.href='bitacora.php'">
                <i class="fas fa-book"></i> Bitácora
            </div>
            
            <div style="margin-top: auto; padding-top: 20px; border-top: 1px solid rgba(255,255,255,0.1);">
                <a href="../auth/logout.php" class="menu-item" style="color: #ff7675; font-weight: 600;">
                    <i class="fas fa-sign-out-alt"></i> Cerrar Sesión
                </a>
            </div> </aside>

        <main class="main">
            <div class="search-container">
                <div class="search-box">
                    <h2><i class="fas fa-file-medical"></i> Consulta de Pacientes e Historial</h2>
                    
                    <label class="checkbox-group">
                        <input type="checkbox" id="check_no_cedulado"> 
                        ¿Paciente No Cedulado? (Buscar por Cédula del Representante)
                    </label>

                    <div class="input-group">
                        <input type="text" id="busqueda" class="input-control" placeholder="Ingrese número de cédula..." maxlength="10">
                        <button onclick="realizarBusqueda()" class="btn-search">
                            <i class="fas fa-search"></i> Buscar
                        </button>
                    </div>
                </div>

                <div id="resultados-area"></div>
            </div>
        </main>
    </div>
<div id="modalEditar" class="modal-overlay">
        <div class="modal-content">
            <span class="close-modal" onclick="cerrarModal()">&times;</span>
            <h2 style="margin-bottom: 20px; color: var(--dark-blue);"><i class="fas fa-user-edit"></i> Editar Paciente</h2>
            
            <form id="formEditarPaciente" onsubmit="guardarEdicion(event)">
                <input type="hidden" id="edit_id" name="id">
                
                <div class="form-group">
                    <label>Nombres</label>
                    <input type="text" id="edit_nombres" name="nombres" class="input-control" required style="width: 100%;">
                </div>
                
                <div class="form-group">
                    <label>Apellidos</label>
                    <input type="text" id="edit_apellidos" name="apellidos" class="input-control" required style="width: 100%;">
                </div>
                
                <div class="form-group">
                    <label>Fecha de Nacimiento</label>
                    <input type="date" id="edit_fecha_nacimiento" name="fecha_nacimiento" class="input-control" required style="width: 100%;">
                </div>

                <button type="submit" class="btn-save"><i class="fas fa-save"></i> Guardar Cambios</button>
            </form>
        </div>
    </div>
    <script>
    function realizarBusqueda() {
        const valor = document.getElementById('busqueda').value.trim();
        const esNoCedulado = document.getElementById('check_no_cedulado').checked ? 1 : 0;
        const resultadosArea = document.getElementById('resultados-area');

        if(valor === "") {
            alert("Por favor ingrese un número de cédula válido.");
            return;
        }

        // Mostramos un mensaje de carga mientras responde el servidor
        resultadosArea.innerHTML = "<p style='text-align:center; margin-top: 20px; color: var(--primary-blue);'><i class='fas fa-spinner fa-spin'></i> Buscando información...</p>";

        fetch('../api/procesar_busqueda.php', {
            method: 'POST',
            headers: {'Content-Type': 'application/x-www-form-urlencoded'},
            body: `valor=${encodeURIComponent(valor)}&es_no_cedulado=${esNoCedulado}`
        })
        .then(response => response.text())
        .then(data => {
            resultadosArea.innerHTML = data;
        })
        .catch(error => {
            console.error('Error:', error);
            resultadosArea.innerHTML = "<p style='color:red; text-align:center;'>Ocurrió un error al realizar la búsqueda.</p>";
        });
    }

    // Permitir buscar presionando la tecla Enter
    document.getElementById('busqueda').addEventListener('keypress', function (e) {
        if (e.key === 'Enter') {
            realizarBusqueda();
        }
    });
    </script>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

<script>
    // Detectar si existe el parámetro status en la URL
    const urlParams = new URLSearchParams(window.location.search);
    
    if (urlParams.get('status') === 'success_registro') {
        Swal.fire({
    title: '¡Éxito!',
    text: 'Registro guardado.',
    icon: 'success',
    heightAuto: false // <--- FUNDAMENTAL
});
        // Limpiar la URL para que no vuelva a salir el alert si recargan la página
        window.history.replaceState({}, document.title, "gestion_pacientes.php");
    }
    // === AGREGAR ESTO DENTRO DEL <script> EXISTENTE EN gestion_pacientes.php ===

// 1. Función para ELIMINAR PACIENTE
function eliminarPaciente(idPaciente) {
    // Usamos SweetAlert2 para confirmar
    Swal.fire({
        title: '¿Estás totalmente seguro?',
        text: "Esta acción eliminará permanentemente el registro del paciente con ID " + idPaciente + " y todo su historial de ingresos. ¡No podrás deshacer esto!",
        icon: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#e74c3c', // Rojo para eliminar
        cancelButtonColor: '#3085d6',
        confirmButtonText: 'Sí, eliminar permanentemente',
        cancelButtonText: 'Cancelar',
        heightAuto: false // Importante para que no se mueva la interfaz
    }).then((result) => {
        // Si el usuario confirma
        if (result.isConfirmed) {
            // Mostramos un mensaje de carga
            Swal.fire({
                title: 'Eliminando...',
                text: 'Por favor espere.',
                icon: 'info',
                allowOutsideClick: false,
                showConfirmButton: false,
                willOpen: () => {
                    Swal.showLoading();
                },
                heightAuto: false
            });

            // Usamos Fetch para enviar la petición al backend
            fetch('../api/eliminar_paciente.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded',
                },
                body: `id=${idPaciente}` // Enviamos el ID del paciente
            })
            .then(response => response.json()) // Esperamos una respuesta JSON
            .then(data => {
                Swal.close(); // Cerramos el mensaje de carga

                if (data.status === 'success') {
                    Swal.fire({
                        title: '¡Eliminado!',
                        text: data.message,
                        icon: 'success',
                        heightAuto: false
                    });
                    // Recargamos la búsqueda actual para que desaparezca el paciente eliminado
                    realizarBusqueda(); 
                } else {
                    Swal.fire({
                        title: 'Error',
                        text: data.message, // Mensaje de error detallado del backend
                        icon: 'error',
                        heightAuto: false
                    });
                }
            })
            .catch(error => {
                Swal.close();
                console.error('Error:', error);
                Swal.fire({
                    title: 'Error Crítico',
                    text: 'Ocurrió un error en la comunicación con el servidor.',
                    icon: 'error',
                    heightAuto: false
                });
            });
        }
    });
}

// 2. Función para EDITAR PACIENTE (Estructura básica)
// 1. Abrir modal y cargar datos
function abrirModalEditar(idPaciente) {
    // Le agregamos scrollbarPadding: false y heightAuto: false para evitar el salto
    Swal.fire({ 
        title: 'Cargando...', 
        allowOutsideClick: false, 
        scrollbarPadding: false, 
        heightAuto: false,
        didOpen: () => { Swal.showLoading(); }
    });

    fetch(`../api/obtener_paciente.php?id=${idPaciente}`)
    .then(response => response.json())
    .then(data => {
        Swal.close();
        if(data.error) {
            Swal.fire('Error', data.error, 'error');
        } else {
            // Llenar el formulario
            document.getElementById('edit_id').value = data.id;
            document.getElementById('edit_nombres').value = data.nombres;
            document.getElementById('edit_apellidos').value = data.apellidos;
            document.getElementById('edit_fecha_nacimiento').value = data.fecha_nacimiento;
            
            // Mostrar modal
            document.getElementById('modalEditar').classList.add('active');
        }
    })
    .catch(error => {
        Swal.close();
        Swal.fire('Error', 'No se pudieron cargar los datos.', 'error');
    });
}
// Guardar los cambios (Versión a prueba de errores)
function guardarEdicion(event) {
    event.preventDefault(); 
    
    Swal.fire({
        title: 'Guardando...',
        text: 'Conectando con la base de datos...',
        allowOutsideClick: false,
        heightAuto: false, // Mantener consistencia visual
        didOpen: () => { Swal.showLoading(); }
    });
    
    const formData = new FormData(document.getElementById('formEditarPaciente'));

    fetch('../api/actualizar_paciente.php', {
        method: 'POST',
        body: formData
    })
    .then(response => response.json()) // Intentar convertir directo
    .then(data => {
        if(data.status === 'success') {
            cerrarModal(); // Asegúrate que esta función exista
            Swal.fire({
                title: '¡Actualizado!',
                text: data.message,
                icon: 'success',
                heightAuto: false
            });
            realizarBusqueda(); // Refresca la tabla
        } else {
            Swal.fire('Error', data.message || 'Error desconocido', 'error');
        }
    })
    .catch(error => {
        console.error("Error:", error);
        Swal.fire({
            title: 'Error de Respuesta',
            text: 'El servidor no envió un JSON válido. Revisa la consola (F12).',
            icon: 'error',
            heightAuto: false
        });
    });
}
function cerrarModal() {
    const modal = document.getElementById('modalEditar');
    modal.classList.remove('active');
    // Opcional: limpiar el formulario al cerrar
    document.getElementById('formEditarPaciente').reset();
}
</script>

</body>
</html>