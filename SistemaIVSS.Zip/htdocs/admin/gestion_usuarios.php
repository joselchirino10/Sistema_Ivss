<?php
require_once '../auth/sesion.php'; 

validarAcceso('Administrador'); 

// 1. CONFIGURACIÓN DE CONEXIÓN
require_once '../conexion.php';
// 2. IDENTIFICAR AL USUARIO LOGUEADO
$mi_id = $_SESSION['usuario_id'] ?? 2; 

// --- LÓGICA DE BORRADO LÓGICO ---
if (isset($_GET['eliminar_id']) && $_GET['eliminar_id'] != $mi_id) {
    $pdo->prepare("UPDATE usuarios_sistema SET estado = 'inactivo' WHERE id_sistema = ?")->execute([$_GET['eliminar_id']]);
    header("Location: gestion_usuarios.php?accion=eliminado"); 
    exit;
}

// 3. OBTENER DATOS DEL USUARIO LOGUEADO
$stmtAdmin = $pdo->prepare("SELECT * FROM usuarios_sistema WHERE id_sistema = ?");
$stmtAdmin->execute([$mi_id]);
$datos_admin = $stmtAdmin->fetch();

$mi_rol = $datos_admin ? $datos_admin['tipo_usuario'] : 'Regular';
$nombre_completo = $datos_admin ? $datos_admin['nombre'] . " " . $datos_admin['apellidos'] : 'Usuario';
$username = $datos_admin ? $datos_admin['username'] : '';
$cedula = $datos_admin ? $datos_admin['cedula'] : '';
$correo = $datos_admin ? $datos_admin['correo'] : '';

// 4. OBTENER TODOS LOS USUARIOS PARA LA TABLA
$usuarios = $pdo->query("SELECT * FROM usuarios_sistema ORDER BY tipo_usuario ASC, id_sistema DESC")->fetchAll();

$foto_path = "../auth/uploads/perfil_" . $mi_id . ".jpg";
$foto_vif = file_exists($foto_path) ? $foto_path : "https://ui-avatars.com/api/?name=".urlencode($nombre_completo)."&background=0056b3&color=fff";
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>IVSS - Gestión de Usuarios</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;600&family=Montserrat:wght@500;600&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <style>
        :root { --primary-blue: #0056b3; --dark-blue: #003366; --accent: #00d1b2; --bg: #f0f2f5; --white: #ffffff; --text: #2d3436; --error: #dc3545; --sidebar-width: 260px; --navbar-height: 80px; }
        * { margin: 0; padding: 0; box-sizing: border-box; font-family: 'Inter', sans-serif; }
        body { background-color: var(--bg); color: var(--text); height: 100vh; display: flex; flex-direction: column; overflow: hidden; }

    /* --- NAVBAR --- */
        .navbar {
            height: var(--navbar-height);
            background: var(--primary-blue);
            display: flex;
            align-items: center;
            padding: 0 2rem;
            box-shadow: 0 4px 10px rgba(0,0,0,0.15);
            z-index: 1000;
            border-bottom: 3px solid var(--accent);
        }
        .navbar-content { display: flex; align-items: center; gap: 20px; }
        .navbar-logo { height: 55px; width: auto; }
        .navbar-text { font-family: 'Montserrat', sans-serif; font-size: 0.95rem; font-weight: 600; color: white; line-height: 1.4; }

        .app-container { display: flex; flex: 1; overflow: hidden; }
             .sidebar { width: var(--sidebar-width); background: var(--dark-blue); color: white; display: flex; flex-direction: column; padding: 2rem 1.2rem; gap: 8px; }
        .menu-item { padding: 14px 18px; color: #cbd5e0; text-decoration: none; display: flex; align-items: center; gap: 12px; border-radius: 10px; cursor: pointer; transition: var(--transition); }
        .menu-item i { width: 22px; text-align: center; font-size: 1.1rem; }
        .menu-item:hover { background: rgba(255,255,255,0.1); color: white; transform: translateX(5px); }
        .menu-item.active { background: var(--primary-blue); color: white; box-shadow: 0 4px 8px rgba(0,0,0,0.1); }

        .main-content { flex: 1; overflow-y: auto; padding: 2rem; }
        .grid-layout { display: grid; grid-template-columns: 300px 1fr; gap: 2rem; max-width: 1400px; margin: 0 auto; }
        .card { background: var(--white); border-radius: 15px; padding: 1.5rem; box-shadow: 0 5px 15px rgba(0,0,0,0.05); border-top: 5px solid var(--primary-blue); }
        
        
        .profile-section { text-align: center; }
        .profile-img { width: 120px; height: 120px; border-radius: 50%; border: 4px solid var(--primary-blue); object-fit: cover; margin-bottom: 1rem; }
        .admin-badge { background: #e3f2fd; color: var(--primary-blue); padding: 4px 12px; border-radius: 20px; font-size: 0.75rem; font-weight: 700; display: inline-block;}

        table { width: 100%; border-collapse: collapse; margin-top: 1rem; }
        th { text-align: left; padding: 12px; border-bottom: 2px solid #f0f2f5; color: #7f8c8d; font-size: 0.75rem; text-transform: uppercase; }
        td { padding: 15px 12px; border-bottom: 1px solid #f8f9fa; font-size: 0.9rem; }

        .btn-group { display: flex; gap: 5px; }
        .btn { padding: 8px 12px; border-radius: 6px; text-decoration: none; color: white; font-size: 0.8rem; font-weight: 600; text-align: center; border: none; cursor: pointer; transition: 0.3s;}
        .btn-blue { background: #3498db; }
        .btn-orange { background: #f39c12; }
        .btn-red { background: var(--error); }
        .btn-disabled { background: #ccc; cursor: not-allowed; color: #666; }

        .status-pill { padding: 4px 10px; border-radius: 12px; font-size: 0.75rem; font-weight: bold; }
        .active-pill { background: #e8f5e9; color: #2e7d32; }
        .inactive-pill { background: #ffebee; color: #c62828; }

        .form-update-photo { margin-top: 1.5rem; padding-top: 1rem; border-top: 1px solid #eee; }
        .custom-file-upload { border: 2px dashed var(--primary-blue); color: var(--primary-blue); padding: 10px; border-radius: 8px; display: block; cursor: pointer; width: 100%; text-align: center; font-weight: 600; transition: 0.3s; margin-bottom: 10px; }
        .custom-file-upload:hover { background: #e3f2fd; }
        input[type="file"] { display: none; }
    </style>
</head>
<body>
    <script>
        document.addEventListener("DOMContentLoaded", function() {
            const urlParams = new URLSearchParams(window.location.search);
            let accion = urlParams.get('accion');
            if(accion) {
                let msj = accion === 'foto_ok' ? 'Foto de perfil actualizada.' : 
                          (accion === 'eliminado' ? 'Usuario desactivado correctamente.' : 
                          (accion === 'creado' ? 'Usuario registrado con éxito.' : 
                          (accion === 'actualizado' ? 'Usuario modificado correctamente.' : '')));
                
                if(msj !== '') {
                    Swal.fire({ icon: 'success', title: '¡Éxito!', text: msj, timer: 2500, showConfirmButton: false });
                    window.history.replaceState(null, null, window.location.pathname);
                }
            }
        });

        function confirmarEliminacion(id, nombre) {
            Swal.fire({
                title: '¿Desactivar a ' + nombre + '?',
                text: "Se requerirá un código de seguridad enviado a tu correo.",
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#dc3545',
                cancelButtonColor: '#6c757d',
                confirmButtonText: 'Enviar código'
            }).then((result) => {
                if (result.isConfirmed) {
                    Swal.fire({
                        title: 'Código de Verificación',
                        text: 'Ingresa el código que hemos enviado a tu correo (Simulado)',
                        input: 'text',
                        showCancelButton: true,
                        confirmButtonText: 'Verificar y Eliminar'
                    }).then((codigo) => {
                        if (codigo.isConfirmed && codigo.value !== "") {
                            window.location.href = `gestion_usuarios.php?eliminar_id=${id}`;
                        }
                    });
                }
            });
        }
    </script>

    <nav class="navbar">
        <div class="navbar-content">
            <img src="../assets/seguro.png" alt="Logo Seguro" class="navbar-logo">
            <span class="navbar-text">DEPARTAMENTO DE REGISTRO Y ESTADÍSTICA <br> HOSPITAL DR. RAFAEL GALLARDO</span>
        </div>
    </nav>

    <div class="app-container">
        <aside class="sidebar">
            <a href="dashboard_admin.php" class="menu-item"><i class="fas fa-th-large"></i> Dashboard</a>
            <a href="registrar_ingreso.php" class="menu-item"><i class="fas fa-user-plus"></i> Registrar Ingreso</a>
            <a href="gestion_ingresos.php" class="menu-item"><i class="fas fa-list-alt"></i> Historial Ingresos</a>
            <a href="gestion_pacientes.php" class="menu-item"><i class="fas fa-search"></i> Gestion Pacientes</a>
            <a href="estadisticas.php" class="menu-item"><i class="fas fa-chart-pie"></i> Estadísticas</a>
            <a href="gestion_usuarios.php" class="menu-item active"><i class="fas fa-user-shield"></i> Gestión Usuarios</a>
            
            <a href="bitacora.php" class="menu-item"><i class="fas fa-book"></i> Bitácora</a>
            <div style="margin-top: auto; padding-top: 20px; border-top: 1px solid rgba(255,255,255,0.1);">
                <a href="../auth/logout.php" class="menu-item" style="color: #ff7675;"><i class="fas fa-sign-out-alt"></i> Cerrar Sesión</a>
            </div>
        </aside>

        <main class="main-content">
            <div class="grid-layout">
                <section class="profile-section">
                    <div class="card">
                        <img src="<?= $foto_vif ?>?v=<?=time()?>" class="profile-img"><br>
                        <div class="admin-badge"><?= strtoupper($mi_rol) ?></div>
                        <h3 style="margin: 1rem 0 0.5rem;"><?= htmlspecialchars($nombre_completo) ?></h3>
                        <p style="color: #7f8c8d; font-size: 0.85rem; margin-bottom: 1rem;">@<?= htmlspecialchars($username) ?></p>
                        
                        <div style="text-align: left; font-size: 0.85rem; line-height: 1.8;">
                            <p><strong>Cédula:</strong> <?= htmlspecialchars($cedula) ?></p>
                            <p><strong>Correo:</strong> <?= htmlspecialchars($correo) ?></p>
                        </div>

                        <div class="form-update-photo">
                            <form action="../auth/subir_foto.php" method="POST" enctype="multipart/form-data" id="form-foto">
                                <label class="custom-file-upload">
                                    <input type="file" name="foto" required onchange="document.getElementById('form-foto').submit();">
                                    <i class="fas fa-camera"></i> Actualizar Foto
                                </label>
                            </form>
                            <a href="../auth/editar_perfil.php" class="btn btn-blue" style="display: block; width: 100%; margin-top: 10px;">Editar mi perfil</a>
                        </div>
                    </div>
                </section>

                <section class="table-section">
                    <div class="card">
                        <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 1.5rem;">
                            <h3>Usuarios del Sistema</h3>
                            <a href="registro_usuario.php" class="btn btn-blue" style="padding: 10px 20px;">+ Nuevo Personal</a>
                        </div>

                        <table>
                            <thead>
                                <tr>
                                    <th>Usuario</th>
                                    <th>Nombre</th>
                                    <th>Rol</th>
                                    <th>Estado</th>
                                    <th>Acciones</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($usuarios as $u): ?>
                                <tr>
                                    <td><strong><?= htmlspecialchars($u['username']) ?></strong></td>
                                    <td><?= htmlspecialchars($u['nombre'] . " " . $u['apellidos']) ?></td>
                                    <td><span style="font-size: 0.75rem; font-weight: 600;"><?= $u['tipo_usuario'] ?></span></td>
                                    <td>
                                        <span class="status-pill <?= $u['estado'] === 'activo' ? 'active-pill' : 'inactive-pill' ?>">
                                            <?= strtoupper($u['estado']) ?>
                                        </span>
                                    </td>
                                    <td>
                                        <div class="btn-group">
                                            <?php 
                                            // LÓGICA DE ACCIONES
                                            $id_fila = $u['id_sistema'];
                                            $rol_fila = $u['tipo_usuario'];

                                            // Si la fila es el usuario que está navegando
                                            if ($id_fila == $mi_id) {
                                                echo '<span class="btn btn-disabled" style="font-size: 0.7rem; padding: 8px; background: #95a5a6; color:white;">Tu cuenta</span>';
                                            } else {
                                                $puede_editar = false;
                                                $puede_eliminar = false;

                                                if ($mi_rol === 'Administrador') {
                                                    if ($rol_fila !== 'Administrador') { $puede_editar = true; $puede_eliminar = true; }
                                                } elseif ($mi_rol === 'Soporte') {
                                                    if ($rol_fila === 'Regular') { $puede_eliminar = true; }
                                                }

                                                if ($puede_editar) {
                                                    echo '<a href="editar_usuario_admin.php?id=' . $id_fila . '" class="btn btn-orange">Modificar</a>';
                                                }
                                                if ($puede_eliminar) {
                                                    $nombre_js = addslashes($u['nombre']);
                                                    echo '<button onclick="confirmarEliminacion(' . $id_fila . ', \'' . $nombre_js . '\')" class="btn btn-red">Borrar</button>';
                                                }
                                                if (!$puede_editar && !$puede_eliminar) {
                                                    echo '<span class="btn btn-disabled" style="font-size: 0.7rem; padding: 8px;">Protegido</span>';
                                                }
                                            }
                                            ?>
                                        </div>
                                    </td>
                                </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                </section>
            </div>
        </main>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<script>
    // Obtener los parámetros de la URL
    const urlParams = new URLSearchParams(window.location.search);
    
    if (urlParams.get('subida') === 'exitosa') {
        Swal.fire({
            title: '¡Excelente!',
            text: 'La foto de perfil se actualizó correctamente.',
            icon: 'success',
            confirmButtonText: 'Entendido'
        });
        
        // Opcional: Limpiar la URL para que no salga el alert si el usuario recarga
        window.history.replaceState({}, document.title, window.location.pathname);
    }
</script>
</body>
</html>