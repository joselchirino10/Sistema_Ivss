<?php
require_once '../auth/sesion.php'; 
// Sustitución de la configuración manual por el archivo centralizado
require_once '../conexion.php'; 

validarAcceso('Administrador'); 

/* Nota: Se asume que en ../conexion.php la conexión se asigna a $conn.
   Si en tu archivo de conexión usaste $conexion, descomenta la línea de abajo:
   // $conn = $conexion; 
*/

if ($conn->connect_error) {
    die("Error de conexión: " . $conn->connect_error);
}

// Para que PHP lea bien los acentos
$conn->set_charset("utf8mb4");

// Inicializar variables de búsqueda
$filtro_fecha = isset($_GET['fecha']) ? $_GET['fecha'] : '';
$filtro_cedula = isset($_GET['cedula']) ? $_GET['cedula'] : '';
$filtro_nombre = isset($_GET['nombre']) ? $_GET['nombre'] : '';

// --- CONFIGURACIÓN DE PAGINACIÓN ---
$registros_por_pagina = 10; 
$pagina_actual = isset($_GET['pagina']) ? (int)$_GET['pagina'] : 1;
if ($pagina_actual < 1) $pagina_actual = 1;

// Construir la condición WHERE dinámicamente
$where_clause = " WHERE 1=1";

if (!empty($filtro_fecha)) {
    $fecha_esc = $conn->real_escape_string($filtro_fecha);
    $where_clause .= " AND DATE(b.fecha_accion) = '$fecha_esc'";
}
if (!empty($filtro_cedula)) {
    $cedula_esc = $conn->real_escape_string($filtro_cedula);
    $where_clause .= " AND u.cedula LIKE '%$cedula_esc%'";
}
if (!empty($filtro_nombre)) {
    $nombre_esc = $conn->real_escape_string($filtro_nombre);
    $where_clause .= " AND (u.nombre LIKE '%$nombre_esc%' OR u.apellidos LIKE '%$nombre_esc%')";
}

// 1. Obtener el total de registros para calcular el número de páginas
$sql_total = "SELECT COUNT(*) as total FROM bitacora b INNER JOIN usuarios_sistema u ON b.usuario_id = u.id_sistema" . $where_clause;
$resultado_total = $conn->query($sql_total);
$fila_total = $resultado_total->fetch_assoc();
$total_registros = $fila_total['total'];
$total_paginas = ceil($total_registros / $registros_por_pagina);

// 2. Calcular el OFFSET para la consulta principal
$offset = ($pagina_actual - 1) * $registros_por_pagina;

// 3. Consulta principal con LIMIT y OFFSET
$sql = "SELECT b.fecha_accion, b.descripcion, u.nombre, u.apellidos, u.cedula 
        FROM bitacora b
        INNER JOIN usuarios_sistema u ON b.usuario_id = u.id_sistema" 
        . $where_clause . 
        " ORDER BY b.fecha_accion DESC 
        LIMIT $registros_por_pagina OFFSET $offset";

$resultado = $conn->query($sql);

// Cadena de parámetros para mantener los filtros al navegar entre páginas
$parametros_url = "&fecha=" . urlencode($filtro_fecha) . "&cedula=" . urlencode($filtro_cedula) . "&nombre=" . urlencode($filtro_nombre);
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>IVSS - Bitácora</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;600&family=Montserrat:wght@500;600&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="../estilos.css">
</head>
<body class="page-bitacora">

    <nav class="navbar">
        <div class="navbar-content">
            <img src="../assets/seguro.png" alt="Logo" class="navbar-logo">
            <span class="navbar-text">
                DEPARTAMENTO DE REGISTRO Y ESTADÍSTICA <br> 
                HOSPITAL DR. RAFAEL GALLARDO - CORO
            </span>
        </div>
    </nav>

    <div class="app-container">
        <aside class="sidebar">
            <div class="menu-item" onclick="window.location.href='dashboard_admin.php'">
                <i class="fas fa-th-large"></i> Dashboard
            </div>
            <div class="menu-item" onclick="window.location.href='registrar_ingreso.php'">
                <i class="fas fa-user-plus"></i> Registro Ingresos
            </div>
            <a href="gestion_ingresos.php" class="menu-item"><i class="fas fa-list-alt"></i> Historial Ingresos</a>
            <div class="menu-item" onclick="window.location.href='gestion_pacientes.php'">
                <i class="fas fa-search"></i> Gestion Pacientes
            </div>
            <a href="estadisticas.php" class="menu-item"><i class="fas fa-chart-pie"></i> Estadísticas</a>
            <a href="gestion_usuarios.php" class="menu-item"><i class="fas fa-user-shield"></i> Gestión Usuarios</a>
            <div class="menu-item active">
                <i class="fas fa-book"></i> Bitácora
            </div>
            <div style="margin-top: auto; padding-top: 20px; border-top: 1px solid rgba(255,255,255,0.1);">
                <a href="../auth/logout.php" class="menu-item" style="color: #ff7675; font-weight: 600;">
                    <i class="fas fa-sign-out-alt"></i> Cerrar Sesión
                </a>
            </div>
        </aside>

        <main class="main">
            <div class="content">
                <form method="GET" action="bitacora.php" class="search-container">
                    <div style="width: 100%; margin-bottom: 10px;">
                        <h2 style="font-family: 'Montserrat'; color: var(--dark-blue); font-size: 1.3rem;">
                            <i class="fas fa-history"></i> Bitácora del Sistema
                        </h2>
                    </div>
                    <input type="date" name="fecha" value="<?php echo htmlspecialchars($filtro_fecha); ?>">
                    <input type="text" name="cedula" value="<?php echo htmlspecialchars($filtro_cedula); ?>" placeholder="Cédula...">
                    <input type="text" name="nombre" value="<?php echo htmlspecialchars($filtro_nombre); ?>" placeholder="Nombre/Apellido...">
                    <button type="submit"><i class="fas fa-search"></i> Buscar</button>
                    <?php if(!empty($filtro_fecha) || !empty($filtro_cedula) || !empty($filtro_nombre)): ?>
                        <a href="bitacora.php" class="reset-btn"><i class="fas fa-times"></i> Limpiar</a>
                    <?php endif; ?>
                </form>

                <div class="table-container">
                    <table>
                        <thead>
                            <tr>
                                <th><i class="far fa-clock"></i> Fecha y Hora</th>
                                <th><i class="far fa-user"></i> Usuario</th>
                                <th><i class="far fa-id-card"></i> Cédula</th>
                                <th><i class="fas fa-info-circle"></i> Descripción</th>
                            </tr>
                        </thead>
                        <tbody>
                        <?php
                        if (!$resultado) {
                            echo "<tr><td colspan='4' style='color:red;'>Error: " . $conn->error . "</td></tr>";
                        } elseif ($resultado->num_rows > 0) {
                            while($row = $resultado->fetch_assoc()) {
                                $fecha_formateada = date("d/m/Y", strtotime($row['fecha_accion']));
                                $hora_formateada = date("h:i A", strtotime($row['fecha_accion']));
                                $nombre_completo = ($row['nombre'] ?? '') . " " . ($row['apellidos'] ?? '');
                                
                                echo "<tr>";
                                echo "<td><span class='timestamp'>$fecha_formateada</span> <small>$hora_formateada</small></td>";
                                echo "<td style='font-weight: 600;'>" . htmlspecialchars($nombre_completo) . "</td>";
                                echo "<td>" . htmlspecialchars($row['cedula'] ?? '') . "</td>";
                                echo "<td>" . htmlspecialchars($row['descripcion'] ?? '') . "</td>";
                                echo "</tr>";
                            }
                        } else {
                            echo "<tr><td colspan='4' style='text-align: center; padding: 40px;'>No se encontraron registros.</td></tr>";
                        }
                        ?>
                        </tbody>
                    </table>
                </div>

                <?php if ($total_paginas > 1): ?>
                <div class="pagination">
                    <a href="?pagina=<?php echo ($pagina_actual - 1) . $parametros_url; ?>" class="<?php echo ($pagina_actual <= 1) ? 'disabled' : ''; ?>">Anterior</a>
                    <?php for ($i = 1; $i <= $total_paginas; $i++): ?>
                        <a href="?pagina=<?php echo $i . $parametros_url; ?>" class="<?php echo ($i == $pagina_actual) ? 'active' : ''; ?>"><?php echo $i; ?></a>
                    <?php endfor; ?>
                    <a href="?pagina=<?php echo ($pagina_actual + 1) . $parametros_url; ?>" class="<?php echo ($pagina_actual >= $total_paginas) ? 'disabled' : ''; ?>">Siguiente</a>
                </div>
                <?php endif; ?>
            </div>
        </main>
    </div>
    <?php $conn->close(); ?>
</body>
</html>