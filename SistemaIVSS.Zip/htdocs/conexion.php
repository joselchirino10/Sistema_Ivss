<?php
// Configuración de la base de datos
$host = "sql208.infinityfree.com";    // Servidor local (XAMPP)
$user = "if0_41479192";         // Usuario por defecto de MySQL
$pass = "ciMAvVRAjyR";             // Contraseña por defecto (vacía en XAMPP)
$db   = "if0_41479192_bd_ivss";      // El nombre de tu base de datos

// Crear la conexión utilizando la extensión mysqli
$conexion = mysqli_connect($host, $user, $pass, $db);
$conn = $conexion;
// Verificar si la conexión fue exitosa
if (!$conexion) {
    // Si falla, mostramos el error técnico para saber qué pasó
    die("Error crítico de conexión: " . mysqli_connect_error());
}

// Configurar el conjunto de caracteres a UTF-8 
// Esto es VITAL para que las tildes y la 'ñ' de los apellidos de Coro se vean bien
mysqli_set_charset($conexion, "utf8");

// ── Conexión PDO (usada en auth/, api/enviar_codigo.php, etc.) ─
try {
    $pdo = new PDO(
        "mysql:host=$host;dbname=$db;charset=utf8mb4",
        $user,
        $pass,
        [
            PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        ]
    );
} catch (PDOException $e) {
    die("Error crítico de conexión PDO: " . $e->getMessage());
}

// Nota: No cerramos la etiqueta ?> 