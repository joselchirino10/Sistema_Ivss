<?php
// config_sesion.php

// 1. Configurar parámetros de la cookie antes de iniciar la sesión
session_set_cookie_params([
    'lifetime' => 0,             // La cookie expira al cerrar el navegador
    'path' => '/',               // Disponible en todo el dominio
    'domain' => '',              
    'secure' => false,            // Solo enviar por HTTPS
    'httponly' => true,          // Evitar que JavaScript robe la cookie (previene XSS)
    'samesite' => 'Strict'       // Evitar ataques de falsificación de petición (CSRF)
]);

session_start();

