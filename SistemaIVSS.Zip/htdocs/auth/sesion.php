<?php
// 1. Cargamos la configuración técnica de cookies y el inicio de sesión
// Esto aplica el protocolo Secure Cookies (HttpOnly, SameSite, etc.)
require_once 'config_sesion.php'; 

/**
 * Función para proteger las páginas según el login y el rol del usuario.
 * @param string|null $rolRequerido El rol necesario ('Administrador' o 'Regular'). 
 */
function validarAcceso($rolRequerido = null) {
    // A. ¿Existe la sesión del usuario?
    if (!isset($_SESSION['usuario_id'])) {
        mostrarAlertaYRedirigir(
            "Acceso Denegado", 
            "Debes iniciar sesión para acceder a este módulo.", 
            "error", 
            "login.html"
        );
        exit();
    }

    // B. ¿El usuario tiene el rol necesario?
    if ($rolRequerido !== null && $_SESSION['tipo_usuario'] !== $rolRequerido) {
        // Redirección inteligente según el rango actual del usuario
        $destino = ($_SESSION['tipo_usuario'] === 'Administrador') ? '../admin/dashboard_admin.php' : '../regular/dashboard_regular.php';
        
        mostrarAlertaYRedirigir(
            "Permiso Insuficiente", 
            "Tu cuenta de " . $_SESSION['tipo_usuario'] . " no tiene acceso aquí.", 
            "warning", 
            $destino
        );
        exit();
    }
}

/**
 * Función auxiliar para mostrar un mensaje estético con SweetAlert2 y redirigir.
 */
function mostrarAlertaYRedirigir($titulo, $texto, $icono, $url) {
    echo "
    <!DOCTYPE html>
    <html lang='es'>
    <head>
        <meta charset='UTF-8'>
        <title>Validando...</title>
        <script src='https://cdn.jsdelivr.net/npm/sweetalert2@11'></script>
        <style>
            body { 
                font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; 
                background-color: #f4f7f6; 
                display: flex;
                justify-content: center;
                align-items: center;
                height: 100vh;
                margin: 0;
            }
        </style>
    </head>
    <body>
        <script>
            Swal.fire({
                title: '$titulo',
                text: '$texto',
                icon: '$icono',
                confirmButtonText: 'Entendido',
                confirmButtonColor: '#3085d6',
                allowOutsideClick: false
            }).then((result) => {
                window.location.href = '$url';
            });
        </script>
    </body>
    </html>";
}

/**
 * Función para cerrar la sesión de forma segura.
 */
function cerrarSesion() {
    // Limpiamos y destruimos la sesión
    session_unset();
    session_destroy();
    
    // Opcional: Podrías usar mostrarAlertaYRedirigir aquí también para un adiós estético
    header("Location: login.html");
    exit();
}
?>