<?php
session_start();

require_once '../conexion.php';

$dsn = "mysql:host=$host;dbname=$db;charset=$charset";
$options = [
    PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
    PDO::ATTR_EMULATE_PREPARES   => false,
];

try {
    $pdo = new PDO($dsn, $user, $pass, $options);
} catch (\PDOException $e) {
    die("Error de conexión: " . $e->getMessage());
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Aplicamos trim y strtolower al identificador por seguridad
    $identifier   = strtolower(trim($_POST['identifier'] ?? ''));
    $new_password = $_POST['new_password'] ?? '';
    $pregunta1    = $_POST['pregunta1'] ?? '';
    $respuesta1   = $_POST['respuesta1'] ?? '';
    $pregunta2    = $_POST['pregunta2'] ?? '';
    $respuesta2   = $_POST['respuesta2'] ?? '';

    // Validación de longitud mínima (16 caracteres)
    if (empty($new_password) || strlen($new_password) < 16) {
        die("Error: La contraseña no cumple los requisitos de seguridad.");
    }

    try {
        $pdo->beginTransaction();

        // 1. BUSCAR USUARIO
        // Buscamos usando el identificador ya normalizado en minúsculas
        $stmtUser = $pdo->prepare("SELECT id_sistema FROM usuarios_sistema WHERE cedula = ? OR correo = ? LIMIT 1");
        $stmtUser->execute([$identifier, $identifier]);
        $userRow = $stmtUser->fetch();

        if (!$userRow) {
            throw new Exception("Usuario no encontrado con la identificación: " . htmlspecialchars($identifier));
        }

        $usuario_id = $userRow['id_sistema'];

        // 2. ACTUALIZAR CONTRASEÑA
        $password_secure = password_hash($new_password, PASSWORD_DEFAULT);
        
        $stmtUpdatePass = $pdo->prepare("UPDATE usuarios_sistema SET password_hash = ? WHERE id_sistema = ?");
        $stmtUpdatePass->execute([$password_secure, $usuario_id]);

        // 3. GUARDAR PREGUNTAS DE SEGURIDAD
        $stmtDelete = $pdo->prepare("DELETE FROM preguntas_seguridad WHERE usuario_id = ?");
        $stmtDelete->execute([$usuario_id]);

        $stmtInsertPreg = $pdo->prepare("INSERT INTO preguntas_seguridad (usuario_id, pregunta, respuesta_hash) VALUES (?, ?, ?)");

        // --- PROCESAMIENTO ESTÁNDAR (Minúsculas y sin espacios extra) ---

        // Procesar Pregunta 1
        $resp1_normalizada = strtolower(trim($respuesta1));
        $resp1_h = password_hash($resp1_normalizada, PASSWORD_DEFAULT);
        $stmtInsertPreg->execute([$usuario_id, $pregunta1, $resp1_h]);

        // Procesar Pregunta 2
        $resp2_normalizada = strtolower(trim($respuesta2));
        $resp2_h = password_hash($resp2_normalizada, PASSWORD_DEFAULT);
        $stmtInsertPreg->execute([$usuario_id, $pregunta2, $resp2_h]);

        // Confirmar todos los cambios
        $pdo->commit();

        echo "<script>
                alert('¡Seguridad configurada correctamente! Su contraseña y preguntas han sido guardadas.');
                window.location.href = 'login.html';
              </script>";

    } catch (Exception $e) {
        if ($pdo->inTransaction()) $pdo->rollBack();
        die("Error al procesar la solicitud: " . $e->getMessage());
    }
} else {
    header("Location: login.html");
    exit;
}
// Asegúrate de que tu conexión soporte acentos
$conn->set_charset("utf8mb4");

// -------------------------------------------------------------
// GUARDAR EN LA BITÁCORA LA CONFIGURACIÓN DE SEGURIDAD
// -------------------------------------------------------------
$descripcion_bitacora = "Configuración de nueva contraseña y preguntas de seguridad";

// Nota: Asegúrate de usar la variable correcta que contiene el ID del usuario en ese archivo.
// Puede que la tengas como $user_id, $id_sistema, o $_SESSION['usuario_id'].
$usuario_id_bitacora = $_SESSION['usuario_id']; // <-- Ajusta esto según tu código

$stmt_bitacora = $conn->prepare("INSERT INTO bitacora (usuario_id, descripcion) VALUES (?, ?)");
$stmt_bitacora->bind_param("is", $usuario_id_bitacora, $descripcion_bitacora);
$stmt_bitacora->execute();
$stmt_bitacora->close();
// -------------------------------------------------------------