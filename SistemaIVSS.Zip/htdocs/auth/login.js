document.addEventListener('DOMContentLoaded', () => {
    // Referencias a elementos del DOM
    const loginForm = document.getElementById('form-login');
    const btnNext = document.getElementById('btn-next');
    const step1 = document.getElementById('step-1');
    const step2 = document.getElementById('step-2');
    const identifierInput = document.getElementById('identifier');
    const passwordInput = document.getElementById('password');
    const displayUser = document.getElementById('display-user');
    const errorContainer = document.getElementById('login-error');
    const errorText = document.getElementById('error-text');
    const btnLogin = document.getElementById('btn-login');
    const togglePassword = document.getElementById('toggle-password');

    // --- FUNCIONALIDAD DEL BOTÓN VER CONTRASEÑA ---
    if (togglePassword && passwordInput) {
        togglePassword.addEventListener('click', function (e) {
            e.preventDefault(); 
            e.stopPropagation(); 
            
            const type = passwordInput.getAttribute('type') === 'password' ? 'text' : 'password';
            passwordInput.setAttribute('type', type);
            
            this.textContent = type === 'password' ? '👁️' : '🔒';
        });
    }

    // --- FUNCIONES DE APOYO ---
    function showError(msg) {
        errorText.innerHTML = msg; 
        errorContainer.style.display = 'flex';
        errorContainer.classList.remove('hidden');
    }

    function hideError() {
        errorContainer.style.display = 'none';
        errorContainer.classList.add('hidden');
    }

    // --- LÓGICA DE FLUJO: PASO 1 ---
    async function verificarUsuario() {
        const identifier = identifierInput.value.trim();
        if (!identifier) {
            showError("Por favor, ingrese su cédula o usuario.");
            return;
        }

        try {
            const response = await fetch('check_user.php', {
                method: 'POST',
                headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                body: `identifier=${encodeURIComponent(identifier)}`
            });

            const data = await response.json();

            if (data.exists) {
                if (data.estado === 'inactivo') {
                    showError(`Cuenta bloqueada. Por favor diríjase al módulo de olvido de contraseña.`);
                    return;
                }

                if (data.has_password) {
                    hideError();
                    // Transición al paso 2
                    step1.classList.add('hidden');
                    step1.style.display = 'none';
                    
                    step2.classList.remove('hidden');
                    step2.style.display = 'block';
                    
                    displayUser.textContent = data.nombre;
                    passwordInput.focus();
                } else {
                    window.location.href = `configurar_credenciales.php?user=${encodeURIComponent(identifier)}`;
                }
            } else {
                showError("El usuario o cédula no están registrados.");
            }
        } catch (error) {
            showError("Error de conexión con el servidor.");
        }
    }

    // --- LÓGICA DE FLUJO: PASO 2 (PROCESAR LOGIN Y CAPTCHA) ---
    async function procesarLogin() {
        const identifier = identifierInput.value.trim();
        const password = passwordInput.value;

        if (!password) {
            showError("Por favor, ingrese su contraseña.");
            return;
        }

        // ==========================================
        // VALIDACIÓN DE GOOGLE reCAPTCHA
        // ==========================================
        // Verifica si la API de grecaptcha está cargada
        if (typeof grecaptcha === 'undefined') {
            showError("El sistema anti-robots no se ha cargado. Revise su conexión a internet.");
            return;
        }

        const captchaResponse = grecaptcha.getResponse();
        
        if (captchaResponse.length === 0) {
            showError("Por favor, verifica que no eres un robot activando la casilla.");
            return; // Detenemos el envío si no marcó el captcha
        }
        // ==========================================

        try {
            // Añadimos la respuesta del captcha al body de la petición POST
            const requestBody = `identifier=${encodeURIComponent(identifier)}&password=${encodeURIComponent(password)}&g-recaptcha-response=${encodeURIComponent(captchaResponse)}`;

            const response = await fetch('login_process.php', {
                method: 'POST',
                headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                body: requestBody
            });

            const data = await response.json();

            if (data.success) {
                window.location.href = data.redirect;
            } else {
                showError(data.message);
                // Si hay un error (ej. contraseña incorrecta), reseteamos el widget de recaptcha
                grecaptcha.reset(); 
                
                if (data.status === 'bloqueado') {
                    btnLogin.disabled = true;
                    btnLogin.style.opacity = '0.5';
                    btnLogin.innerText = 'Acceso Bloqueado';
                } else {
                    passwordInput.value = "";
                    passwordInput.focus();
                }
            }
        } catch (error) {
            showError("Error al procesar el inicio de sesión.");
            grecaptcha.reset(); // Reseteamos por si acaso
        }
    }

    // --- EVENTOS ---
    if(btnNext) {
        btnNext.addEventListener('click', verificarUsuario);
    }

    if(loginForm) {
        loginForm.addEventListener('submit', (e) => {
            e.preventDefault();
            // Si el paso 1 no está oculto, verificamos usuario, si no, procesamos login
            if (getComputedStyle(step1).display !== 'none') {
                verificarUsuario();
            } else {
                procesarLogin();
            }
        });
    }
});