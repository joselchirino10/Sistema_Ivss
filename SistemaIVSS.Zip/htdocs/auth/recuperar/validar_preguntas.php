<?php
    // LÍNEAS MÁGICAS PARA MOSTRAR ERRORES OCULTOS
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
// 1. La sesión siempre va primero, antes de cualquier header o texto
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

header('Content-Type: application/json');

// 2. Usar la conexión centralizada (esto ya trae tu $pdo configurado)
require_once '../../conexion.php';

// Verificamos que exista $pdo para que no muera en silencio
if (!isset($pdo)) {
    echo json_encode(['status' => 'error', 'message' => 'Error interno: Base de datos no disponible.']);
    exit;
}

// 3. Obtener y limpiar datos del POST
$identifier = strtolower(trim($_POST['identifier'] ?? '')); 
$r1_usuario = strtolower(trim($_POST['respuesta_1'] ?? '')); 
$r2_usuario = strtolower(trim($_POST['respuesta_2'] ?? '')); 

if (empty($identifier) || empty($r1_usuario) || empty($r2_usuario)) {
    echo json_encode(['status' => 'error', 'message' => 'Por favor, complete todas las respuestas.']);
    exit;
}

try {
    // 4. Buscar al usuario
    $stmtUser = $pdo->prepare("SELECT id_sistema FROM usuarios_sistema WHERE cedula = ? OR correo = ? LIMIT 1");
    $stmtUser->execute([$identifier, $identifier]);
    $userRow = $stmtUser->fetch();

    if (!$userRow) {
        echo json_encode(['status' => 'error', 'message' => 'Usuario no encontrado.']);
        exit;
    }

    $usuario_id = $userRow['id_sistema'];

    // 5. Obtener las respuestas hasheadas de la base de datos
    $stmtPreguntas = $pdo->prepare("SELECT respuesta_hash FROM preguntas_seguridad WHERE usuario_id = ? ORDER BY id ASC");
    $stmtPreguntas->execute([$usuario_id]);
    $hashes = $stmtPreguntas->fetchAll();

    // Verificamos que tenga las preguntas registradas
    if (count($hashes) < 2) {
        echo json_encode(['status' => 'error', 'message' => 'El usuario no tiene configuradas suficientes preguntas de seguridad.']);
        exit;
    }

    // 6. Validación con password_verify
    $valido1 = password_verify($r1_usuario, $hashes[0]['respuesta_hash']);
    $valido2 = password_verify($r2_usuario, $hashes[1]['respuesta_hash']);

    if ($valido1 && $valido2) {
        // Respuestas correctas: Autorizamos la sesión para que pueda cambiar la clave
        $_SESSION['auth_password_reset'] = $identifier;
        $_SESSION['user_id_reset'] = $usuario_id;
        
        echo json_encode(['status' => 'success']);
    } else {
        echo json_encode(['status' => 'error', 'message' => 'Las respuestas no coinciden. Intente de nuevo.']);
    }

} catch (Exception $e) {
    // Si algo falla a nivel de base de datos, ahora sí lo veremos en el F12
    echo json_encode(['status' => 'error', 'message' => 'Error en el servidor: ' . $e->getMessage()]);
}
?>