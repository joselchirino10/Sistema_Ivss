<?php
session_start();
require '../../vendor/PHPMailer/src/Exception.php';
require '../../vendor/PHPMailer/src/PHPMailer.php';
require '../../vendor/PHPMailer/src/SMTP.php';
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

// Conexión a la base de datos
$host = 'localhost'; $db = 'bd_ivss'; $user = 'root'; $pass = ''; 
$pdo = new PDO("mysql:host=$host;dbname=$db;charset=utf8mb4", $user, $pass);

$mi_id = $_SESSION['usuario_id'] ?? 2;
$accion = $_GET['accion'] ?? '';

if ($accion === 'enviar_mail') {
    // 1. Obtener correo del administrador
    $stmt = $pdo->prepare("SELECT correo, nombre FROM usuarios_sistema WHERE id_sistema = ?");
    $stmt->execute([$mi_id]);
    $u = $stmt->fetch();

    if (!$u) {
        echo json_encode(['status' => 'error', 'message' => 'Usuario no encontrado']);
        exit;
    }

    $codigo = rand(100000, 999999);
    $_SESSION['codigo_borrado'] = $codigo;

    $mail = new PHPMailer(true);
    try {
        // Configuración SMTP Robusta
        $mail->isSMTP();
        $mail->Host       = 'smtp.gmail.com'; 
        $mail->SMTPAuth   = true;
        $mail->Username   = 'joseaziritl@gmail.com'; 
        $mail->Password   = 'kewf rjpa bhub tbcz'; // Asegúrate que esta sea una "Contraseña de Aplicación"
        $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS; // TLS
        $mail->Port       = 587; 
        $mail->CharSet    = 'UTF-8';

        // Opciones para evitar errores de certificados en servidores locales
        $mail->SMTPOptions = array(
            'ssl' => array(
                'verify_peer' => false,
                'verify_peer_name' => false,
                'allow_self_signed' => true
            )
        );

        $mail->setFrom('no-reply@ivss.gob.ve', 'Seguridad IVSS');
        $mail->addAddress($u['correo']);

        $mail->isHTML(true);
        $mail->Subject = 'Código de Verificación - Eliminación de Cuenta';
        $mail->Body    = "
            <div style='font-family: sans-serif; padding: 20px; border: 1px solid #eee;'>
                <h2 style='color: #d32f2f;'>Confirmación de Seguridad</h2>
                <p>Estimado/a <strong>{$u['nombre']}</strong>,</p>
                <p>Se ha solicitado la eliminación permanente de su cuenta de administrador.</p>
                <p style='font-size: 24px; font-weight: bold; color: #0056b3;'>$codigo</p>
                <p>Si usted no realizó esta solicitud, ignore este mensaje.</p>
            </div>";

        $mail->send();
        echo json_encode(['status' => 'success']);
    } catch (Exception $e) {
        echo json_encode(['status' => 'error', 'message' => $mail->ErrorInfo]);
    }
}

if ($accion === 'finalizar_borrado') {
    $codigo_ingresado = $_POST['codigo'] ?? '';
    
    // Validar código almacenado en sesión
    if (!empty($codigo_ingresado) && $codigo_ingresado == $_SESSION['codigo_borrado']) {
        // Ejecutar eliminación física de la base de datos
        $stmt = $pdo->prepare("DELETE FROM usuarios_sistema WHERE id_sistema = ?");
        $stmt->execute([$mi_id]);
        
        session_destroy();
        echo json_encode(['status' => 'success']);
    } else {
        echo json_encode(['status' => 'error', 'message' => 'Código inválido']);
    }
}