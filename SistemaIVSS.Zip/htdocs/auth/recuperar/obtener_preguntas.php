<?php
header('Content-Type: application/json');
// Incluye tu conexión a la base de datos aquí
require_once '../../conexion.php'; 

$identifier = $_POST['identifier'] ?? '';

if (empty($identifier)) {
    echo json_encode(['status' => 'error', 'message' => 'Usuario no proporcionado']);
    exit;
}

// SIMULACIÓN DE CONSULTA SQL (Reemplaza con tu consulta real)
/*
$stmt = $pdo->prepare("SELECT pregunta1, pregunta2 FROM usuarios WHERE cedula = ? OR usuario = ?");
$stmt->execute([$identifier, $identifier]);
$user = $stmt->fetch();
*/

// Ejemplo de cómo debería responder si encuentra al usuario:
$user_ficticio = [
    'pregunta1' => '¿Cuál es el nombre de tu primera mascota?',
    'pregunta2' => '¿Cuál es tu película favorita?'
];

if ($user_ficticio) {
    echo json_encode([
        'status' => 'success',
        'preguntas' => [
            $user_ficticio['pregunta1'],
            $user_ficticio['pregunta2']
        ]
    ]);
} else {
    echo json_encode(['status' => 'error', 'message' => 'No se encontraron preguntas para este usuario.']);
}