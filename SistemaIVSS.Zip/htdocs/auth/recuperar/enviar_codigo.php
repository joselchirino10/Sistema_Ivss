<?php
// enviar_codigo.php — auth/recuperar/
// No requiere sesion activa (se usa ANTES de iniciar sesion)
 
session_start();
 
require '../../conexion.php';
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

// Carga las librerías (Ajusta la ruta según tu carpeta)
require '../../vendor/PHPMailer/src/Exception.php';
require '../../vendor/PHPMailer/src/PHPMailer.php';
require '../../vendor/PHPMailer/src/SMTP.php';

if (isset($_POST['identifier'])) {
    $user = $_POST['identifier'];

    // 1. Buscar correo en BD_IVSS
    $stmt = $pdo->prepare("SELECT correo FROM usuarios_sistema WHERE cedula = ?");
    $stmt->execute([$user]);
    $usuario = $stmt->fetch();

    if ($usuario) {
        $destinatario = $usuario['correo'];
        $codigo = rand(100000, 999999);
        $_SESSION['codigo_verificacion'] = $codigo;

        $mail = new PHPMailer(true);

        try {
            // Configuración del Servidor
            $mail->isSMTP();
            $mail->Host       = 'smtp.gmail.com'; 
            $mail->SMTPAuth   = true;
            $mail->Username   = 'joseaziritl@gmail.com'; // Tu correo real
            $mail->Password   = 'kewf rjpa bhub tbcz'; // Ver nota abajo*
            $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
            $mail->Port       = 587;

            // Destinatarios
            $mail->setFrom('no-reply@ivss.gob.ve', 'Seguridad IVSS');
            $mail->addAddress($destinatario);

            // Contenido del Correo
            $mail->isHTML(true);
            $mail->Subject = 'Codigo de Verificacion de Identidad';
            $mail->Body    = "
                <div style='font-family: Arial; border-top: 5px solid #0056b3; padding: 20px;'>
                    <h2>Confirmación de Seguridad</h2>
                    <p>Has solicitado configurar tu contraseña en el sistema de Registro y Estadística.</p>
                    <p style='font-size: 20px;'>Su código es: <strong>$codigo</strong></p>
                    <p>Este código expira en 10 minutos.</p>
                </div>";

            $mail->send();
            echo json_encode(['status' => 'success']);
        } catch (Exception $e) {
            echo json_encode(['status' => 'error', 'message' => "Error al enviar: {$mail->ErrorInfo}"]);
        }
    } else {
        echo json_encode(['status' => 'error', 'message' => 'Usuario no encontrado']);
    }
}