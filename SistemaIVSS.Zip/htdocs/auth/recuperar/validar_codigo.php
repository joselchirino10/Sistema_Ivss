<?php
session_start();

if (isset($_POST['codigo_ingresado'])) {
    if ($_POST['codigo_ingresado'] == $_SESSION['codigo_verificacion']) {
        echo json_encode(['status' => 'success']);
    } else {
        echo json_encode(['status' => 'error', 'message' => 'Código incorrecto']);
    }
}
?>