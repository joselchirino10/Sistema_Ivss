<?php
session_start();
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Recuperar Acceso - IVSS</title>
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@500;600&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <link rel="stylesheet" href="../../assets/style.css">
    <style>
        .container { max-width: 550px; margin: 20px auto; }
        .card { background: white; padding: 25px; border-radius: 12px; box-shadow: 0 10px 25px rgba(0,0,0,0.1); border-top: 6px solid #0056b3; }
        
        #section-verify { text-align: center; }
        .code-input { 
            letter-spacing: 8px; 
            font-size: 24px !important; 
            text-align: center; 
            font-weight: bold; 
            border: 2px solid #0056b3 !important;
        }
        .loading-spinner { display: none; margin: 10px auto; border: 4px solid #f3f3f3; border-top: 4px solid #3498db; border-radius: 50%; width: 30px; height: 30px; animation: spin 1s linear infinite; }
        @keyframes spin { 0% { transform: rotate(0deg); } 100% { transform: rotate(360deg); } }

        /* Contenedor del input para posicionar el ojo */
        .input-group { 
            position: relative; 
            width: 100%; 
            display: flex;
            align-items: center;
        }

        input[type="password"], input[type="text"], select { 
            width: 100%; 
            padding: 12px; 
            margin-top: 5px; 
            border: 1px solid #ddd; 
            border-radius: 6px; 
            box-sizing: border-box; 
        }

        /* Padding extra a la derecha para que el texto no tape el icono */
        .input-group input {
            padding-right: 40px;
        }

        .toggle-pass { 
            position: absolute; 
            right: 12px; 
            top: calc(50% + 2px); 
            transform: translateY(-50%); 
            background: none; 
            border: none; 
            cursor: pointer; 
            font-size: 1.1rem; 
            color: #777; 
            z-index: 10;
        }
        
        .requirement { font-size: 0.8rem; font-weight: 600; margin-top: 4px; }
        .invalid-text { color: #ff4d4d; }
        .valid-text { color: #2eb82e; }
        header { text-align: center; margin-bottom: 15px; }
        .hidden { display: none; }
        
        .btn-primary { 
            background: #0056b3; 
            color: white; 
            border: none; 
            border-radius: 6px; 
            font-weight: 600; 
            padding: 15px; 
            transition: 0.3s; 
            cursor: pointer; 
            width: 100%; 
            margin-top: 25px;
        }
        .btn-primary:disabled { background: #ccc; cursor: not-allowed; }
        
        hr { margin: 25px 0; border: 0; border-top: 1px solid #eee; }

        .input-group, #questions-container > div {
            margin-bottom: 20px;
        }

        #btn-verify-email { margin-top: 15px; }

        #step-questions h3, #step-password h3 { margin-bottom: 20px; }

        /* Barra de Seguridad */
        .strength-meter { width: 100%; height: 8px; background: #eee; border-radius: 4px; margin: 15px 0 5px; overflow: hidden; }
        #strength-bar { height: 100%; width: 0%; transition: all 0.4s ease; background: #ff4d4d; }
    </style>
</head>
<body>
    <nav class="navbar">
        <div class="navbar-content">
            <img src="../../assets/seguro.png" alt="Logo Seguro" class="navbar-logo">
            <span class="navbar-text">
                Departamento de Registro y Estadística <br> 
                Hospital Dr. Rafael Gallardo
            </span>
        </div>
    </nav>

    <div class="container">
        <header>
            <h1>Recuperar Cuenta</h1>
            <p>Siga los pasos para restablecer su acceso</p>
        </header>

        <div class="card">
            <div id="step-id">
                <h3>Identificación</h3>
                <p>Ingrese su número de cédula o nombre de usuario:</p>
                <input type="text" id="user-input" placeholder="Ej: V-12345678" required>
                <button type="button" id="btn-next-to-email" class="btn-primary">Continuar</button>
                <p id="id-error" class="requirement invalid-text"></p>
            </div>

            <div id="step-email" class="hidden">
                <h3>Paso 1: Código de Seguridad</h3>
                <p>Se enviará un código al correo registrado para: <strong id="display-user"></strong></p>
                <button type="button" id="btn-send-code" class="btn-primary">Enviar Código</button>
                <div id="loader" class="loading-spinner"></div>

                <div id="verify-input-group" class="hidden">
                    <hr>
                    <label>Ingrese el código de 6 dígitos:</label>
                    <input type="text" id="verification-code" class="code-input" maxlength="6" placeholder="000000">
                    <button type="button" id="btn-verify-email" class="btn-primary">Validar Código</button>
                    <p id="email-error" class="requirement invalid-text"></p>
                </div>
            </div>

            <div id="step-questions" class="hidden">
                <h3>Paso 2: Preguntas de Seguridad</h3>
                <p>Responda correctamente a sus preguntas registradas:</p>
                <form id="form-questions">
                    <div id="questions-container"></div>
                    <button type="button" id="btn-verify-questions" class="btn-primary">Verificar Respuestas</button>
                    <p id="questions-error" class="requirement invalid-text"></p>
                </form>
            </div>

            <div id="step-password" class="hidden">
                <h3>Paso 3: Nueva Contraseña</h3>
                <form id="final-form" action="../update_password.php" method="POST">
                    <input type="hidden" name="user_id" id="hidden-user-id">
                    
                    <label>Nueva Contraseña</label>
                    <div class="input-group">
                        <input type="password" id="new-password" name="new_password" required placeholder="Mínimo 16 caracteres">
                        <i class="fas fa-eye toggle-pass" onclick="toggleVisibility('new-password', this)"></i>
                    </div>

                    <div class="strength-meter">
                        <div id="strength-bar"></div>
                    </div>
                    <p id="strength-text" class="requirement"></p>
                    
                    <label style="display:block; margin-top:20px;">Confirmar Contraseña</label>
                    <div class="input-group">
                        <input type="password" id="confirm-password" required placeholder="Repita la contraseña">
                        <i class="fas fa-eye toggle-pass" onclick="toggleVisibility('confirm-password', this)"></i>
                    </div>
                    
                    <p id="pass-msg" class="requirement" style="margin-top:10px;"></p>
                    <button type="submit" id="btn-save" class="btn-primary" disabled>Actualizar Contraseña</button>
                </form>
            </div>
        </div>
    </div>

    <script>
        let currentUser = "";
        const steps = {
            id: document.getElementById('step-id'),
            email: document.getElementById('step-email'),
            questions: document.getElementById('step-questions'),
            password: document.getElementById('step-password')
        };

        function toggleVisibility(id, icon) {
            const input = document.getElementById(id);
            if (input.type === "password") {
                input.type = "text";
                icon.classList.replace('fa-eye', 'fa-eye-slash');
            } else {
                input.type = "password";
                icon.classList.replace('fa-eye-slash', 'fa-eye');
            }
        }

        document.getElementById('btn-next-to-email').addEventListener('click', () => {
            const val = document.getElementById('user-input').value.trim();
            if (val.length < 3) {
                document.getElementById('id-error').innerText = "Ingrese un usuario válido.";
                return;
            }
            document.getElementById('id-error').innerText = "";
            currentUser = val;
            document.getElementById('display-user').innerText = currentUser;
            document.getElementById('hidden-user-id').value = currentUser;
            steps.id.classList.add('hidden');
            steps.email.classList.remove('hidden');
        });

        document.getElementById('btn-send-code').addEventListener('click', async function() {
            this.disabled = true;
            document.getElementById('loader').style.display = 'block';
            const fd = new FormData(); fd.append('identifier', currentUser);
            try {
                const res = await fetch('enviar_codigo.php', { method: 'POST', body: fd });
                const data = await res.json();
                document.getElementById('loader').style.display = 'none';
                if (data.status === 'success' || data.status === 'debug') {
                    document.getElementById('verify-input-group').classList.remove('hidden');
                } else { 
                    this.disabled = false; 
                    alert(data.message); 
                }
            } catch (e) { 
                alert("Error de conexión al enviar código."); 
                this.disabled = false; 
                document.getElementById('loader').style.display = 'none';
            }
        });

        document.getElementById('btn-verify-email').addEventListener('click', async () => {
            const fd = new FormData(); fd.append('codigo_ingresado', document.getElementById('verification-code').value);
            try {
                const res = await fetch('validar_codigo.php', { method: 'POST', body: fd });
                const data = await res.json();
                if (data.status === 'success') {
                    await loadUserQuestions();
                    steps.email.classList.add('hidden');
                    steps.questions.classList.remove('hidden');
                } else { 
                    document.getElementById('email-error').innerText = data.message; 
                }
            } catch (e) {
                document.getElementById('email-error').innerText = "Error al validar el código.";
            }
        });

        // --- Cargar Preguntas ---
        async function loadUserQuestions() {
            const cont = document.getElementById('questions-container');
            cont.innerHTML = "<p>Cargando preguntas...</p>";
            const fd = new FormData(); 
            fd.append('identifier', currentUser);
            
            try {
                const res = await fetch('obtener_preguntas.php', { method: 'POST', body: fd });
                const data = await res.json();
                
                if (data.status === 'success') {
                    cont.innerHTML = "";
                    data.preguntas.forEach((p, i) => {
                        const d = document.createElement('div');
                        d.innerHTML = `<label><strong>${p}</strong></label><input type="text" name="respuesta_${i+1}" placeholder="Su respuesta" required>`;
                        cont.appendChild(d);
                    });
                } else {
                    cont.innerHTML = `<p class="invalid-text">${data.message}</p>`;
                }
            } catch (e) {
                cont.innerHTML = `<p class="invalid-text">Error al cargar preguntas de seguridad.</p>`;
            }
        }

        // --- Verificar Respuestas ---
        document.getElementById('btn-verify-questions').addEventListener('click', async function() {
            const btn = this;
            const errorMsg = document.getElementById('questions-error');
            
            // Validar que los campos no estén vacíos
            const inputs = document.querySelectorAll('#questions-container input');
            let isEmpty = false;
            inputs.forEach(input => { if (input.value.trim() === "") isEmpty = true; });
            
            if (isEmpty) {
                errorMsg.innerText = "Por favor, responda todas las preguntas.";
                return;
            }

            btn.disabled = true;
            btn.innerText = "Verificando...";
            errorMsg.innerText = "";

            const fd = new FormData(document.getElementById('form-questions'));
            fd.append('identifier', currentUser);
            
            try {
                const res = await fetch('validar_preguntas.php', { method: 'POST', body: fd });
                const data = await res.json(); 
                
                if (data.status === 'success') {
                    steps.questions.classList.add('hidden');
                    steps.password.classList.remove('hidden');
                } else { 
                    errorMsg.innerText = data.message || "Respuestas incorrectas."; 
                    btn.disabled = false;
                    btn.innerText = "Verificar Respuestas";
                }
            } catch (e) {
                console.error(e);
                errorMsg.innerText = "Error de servidor en validar_preguntas.php. Revisa F12 (Red).";
                btn.disabled = false;
                btn.innerText = "Verificar Respuestas";
            }
        });

        // --- Lógica de Seguridad (Mínimo 16 caracteres) ---
        const passInput = document.getElementById('new-password');
        const confirmInput = document.getElementById('confirm-password');
        const bar = document.getElementById('strength-bar');
        const sText = document.getElementById('strength-text');
        const btnSave = document.getElementById('btn-save');

        function validarFinal() {
            const p1 = passInput.value;
            const p2 = confirmInput.value;
            const long = p1.length >= 16;
            const match = (p1 === p2 && p1 !== "");

            if (long && match) {
                btnSave.disabled = false;
                document.getElementById('pass-msg').innerText = "✓ Las contraseñas coinciden";
                document.getElementById('pass-msg').className = "requirement valid-text";
            } else {
                btnSave.disabled = true;
                if (!long && p1 !== "") {
                    document.getElementById('pass-msg').innerText = "✘ Mínimo 16 caracteres requeridos";
                } else if (p1 !== "" && p2 !== "") {
                    document.getElementById('pass-msg').innerText = "✘ Las contraseñas no coinciden";
                } else {
                    document.getElementById('pass-msg').innerText = "";
                }
                document.getElementById('pass-msg').className = "requirement invalid-text";
            }
        }

        passInput.addEventListener('input', () => {
            const v = passInput.value;
            let s = 0;

            if (v.length >= 16) {
                s += 40; 
                if (v.match(/[A-Z]/)) s += 20;
                if (v.match(/[0-9]/)) s += 20;
                if (v.match(/[^A-Za-z0-9]/)) s += 20;
            } else if (v.length > 0) {
                s = 15; 
            }

            bar.style.width = s + "%";

            if (v.length < 16) {
                bar.style.backgroundColor = "#ff4d4d";
                sText.innerText = "Seguridad: Insuficiente (Mínimo 16 caracteres)";
                sText.style.color = "#ff4d4d";
            } else {
                if (s <= 60) { 
                    bar.style.backgroundColor = "#ffa500"; 
                    sText.innerText = "Seguridad: Media"; 
                    sText.style.color = "#ffa500"; 
                } else if (s <= 80) { 
                    bar.style.backgroundColor = "#2eb82e"; 
                    sText.innerText = "Seguridad: Alta"; 
                    sText.style.color = "#2eb82e"; 
                } else { 
                    bar.style.backgroundColor = "#0056b3"; 
                    sText.innerText = "Seguridad: Máxima"; 
                    sText.style.color = "#0056b3"; 
                }
            }
            validarFinal();
        });

        confirmInput.addEventListener('input', validarFinal);

    </script>
</body>
</html>