<?php
header('Content-Type: application/json');
require_once '../conexion.php';

$identifier = $_POST['identifier'] ?? '';

$stmt = $conn->prepare("SELECT nombre, password_hash, estado FROM usuarios_sistema WHERE username = ? OR cedula = ?");
$stmt->bind_param("ss", $identifier, $identifier);
$stmt->execute();
$result = $stmt->get_result();

if ($user = $result->fetch_assoc()) {
    echo json_encode([
        'exists' => true,
        'nombre' => $user['nombre'],
        'estado' => $user['estado'], // IMPORTANTE: Enviamos si está 'activo' o 'inactivo'
        'has_password' => !empty($user['password_hash'])
    ]);
} else {
    echo json_encode(['exists' => false]);
}
$stmt->close();
$conn->close();