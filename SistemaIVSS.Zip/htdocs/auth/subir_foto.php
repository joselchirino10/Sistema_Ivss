<?php
session_start();
$admin_id = $_SESSION['usuario_id'] ?? 2; // Asegúrate de que este ID exista en tu BD

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_FILES['foto'])) {
    $file = $_FILES['foto'];
    
    // Si hay un error en la carga (archivo muy grande, etc)
    if ($file['error'] !== UPLOAD_ERR_OK) {
        die("Error de subida de PHP código: " . $file['error']);
    }

    $directorio_destino = "uploads/";
    
    // Validar extensión
    $extension = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
    $permitidos = ['jpg', 'jpeg', 'png'];

    if (!in_array($extension, $permitidos)) {
        die("Error: Solo se permiten JPG o PNG.");
    }

    // Nombre fijo para el admin actual
    $nombre_archivo = "perfil_" . $admin_id . ".jpg"; 
    $ruta_final = $directorio_destino . $nombre_archivo;

    // Intentar mover el archivo
    if (move_uploaded_file($file['tmp_name'], $ruta_final)) {
        header("Location: ../admin/gestion_usuarios.php?subida=exitosa");
        exit;
    } else {
        // Esto se activa si la carpeta 'uploads' no existe o no tiene permisos
        echo "Error: No se pudo mover el archivo a la carpeta /uploads. Verifica que la carpeta exista.";
    }
}