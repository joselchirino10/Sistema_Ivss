<?php
session_start();
header('Content-Type: application/json');

// Conexión - Considera usar un archivo externo config.php para esto
require_once '../conexion.php';

// Para evitar problemas con los acentos al guardar en la bitácora
$conn->set_charset("utf8mb4");

$identifier = $_POST['identifier'] ?? '';
$password = $_POST['password'] ?? '';

if (empty($identifier) || empty($password)) {
    echo json_encode(['success' => false, 'message' => 'Por favor, complete todos los campos']);
    exit;
}

// 1. Buscar usuario 
// ¡CORRECCIÓN AQUÍ!: Agregué la columna 'nombre' al SELECT. (Cámbiala si en tu BD se llama diferente, ej. 'nombres')
$stmt = $conn->prepare("SELECT id_sistema, password_hash, intentos_fallidos, estado, tipo_usuario, nombre FROM usuarios_sistema WHERE username = ? OR cedula = ?");
$stmt->bind_param("ss", $identifier, $identifier);
$stmt->execute();
$result = $stmt->get_result();
$user = $result->fetch_assoc();

if ($user) {
    // 2. Verificar si la cuenta está bloqueada
    if ($user['estado'] === 'inactivo') {
        echo json_encode([
            'success' => false, 
            'status' => 'bloqueado', 
            'message' => 'Cuenta bloqueada. Diríjase al módulo de recuperación para desbloquear su usuario.'
        ]);
        exit;
    }

    // 3. Validar contraseña
    if (password_verify($password, $user['password_hash'])) {
        // --- ÉXITO ---
        
        // Reiniciar intentos fallidos
        $stmt_reset = $conn->prepare("UPDATE usuarios_sistema SET intentos_fallidos = 0 WHERE id_sistema = ?");
        $stmt_reset->bind_param("i", $user['id_sistema']);
        $stmt_reset->execute();

        // Seguridad: Regenerar el ID de sesión para evitar Session Fixation
        session_regenerate_id(true);

        // Guardar datos esenciales en la sesión
        $_SESSION['usuario_id'] = $user['id_sistema'];
        $_SESSION['identificador'] = $identifier; 
        $_SESSION['tipo_usuario'] = $user['tipo_usuario']; 
        $_SESSION['ultimo_acceso'] = date("Y-m-d H:i:s");
        
        // ¡CORRECCIÓN AQUÍ!: Eliminado el session_start() duplicado y asignado el nombre correctamente desde la BD
        $_SESSION['nombre'] = $user['nombre']; 

        // -------------------------------------------------------------
        // GUARDAR EL INICIO DE SESIÓN EN LA BITÁCORA
        // -------------------------------------------------------------
        $descripcion_bitacora = "Inicio de sesión exitoso";
        $stmt_bitacora = $conn->prepare("INSERT INTO bitacora (usuario_id, descripcion) VALUES (?, ?)");
        $stmt_bitacora->bind_param("is", $user['id_sistema'], $descripcion_bitacora);
        $stmt_bitacora->execute();
        $stmt_bitacora->close();
        // -------------------------------------------------------------

        // Definir redirección según el rol
        $redirect = ($user['tipo_usuario'] === 'Administrador') ? '../admin/dashboard_admin.php' : '../regular/dashboard_regular.php';
        
        echo json_encode(['success' => true, 'redirect' => $redirect]);

    } else {
        // --- FALLO ---
        $nuevo_intento = $user['intentos_fallidos'] + 1;
        
        if ($nuevo_intento >= 3) {
            // BLOQUEAR DEFINITIVAMENTE
            $stmt_block = $conn->prepare("UPDATE usuarios_sistema SET intentos_fallidos = 3, estado = 'inactivo' WHERE id_sistema = ?");
            $stmt_block->bind_param("i", $user['id_sistema']);
            $stmt_block->execute();

            // -------------------------------------------------------------
            // NUEVO: GUARDAR EL BLOQUEO DE USUARIO EN LA BITÁCORA
            // -------------------------------------------------------------
            $descripcion_bloqueo = "Usuario bloqueado por exceder el límite de intentos fallidos";
            $stmt_bitacora_bloqueo = $conn->prepare("INSERT INTO bitacora (usuario_id, descripcion) VALUES (?, ?)");
            $stmt_bitacora_bloqueo->bind_param("is", $user['id_sistema'], $descripcion_bloqueo);
            $stmt_bitacora_bloqueo->execute();
            $stmt_bitacora_bloqueo->close();
            // -------------------------------------------------------------

            echo json_encode([
                'success' => false, 
                'status' => 'bloqueado', 
                'message' => 'Has agotado los 3 intentos. Tu cuenta ha sido bloqueada por seguridad.'
            ]);
        } else {
            // ACTUALIZAR CONTADOR DE INTENTOS
            $stmt_update = $conn->prepare("UPDATE usuarios_sistema SET intentos_fallidos = ? WHERE id_sistema = ?");
            $stmt_update->bind_param("ii", $nuevo_intento, $user['id_sistema']);
            $stmt_update->execute();

            echo json_encode([
                'success' => false, 
                'message' => "Contraseña incorrecta. Intento $nuevo_intento de 3."
            ]);
        }
    }
} else {
    echo json_encode(['success' => false, 'message' => 'El usuario ingresado no existe']);
}

$stmt->close();
$conn->close();