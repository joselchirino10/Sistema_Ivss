<?php
// Conexión a la base de datos (ajusta tus credenciales)
require_once '../conexion.php';
// 1. Asegurar codificación para los acentos en la bitácora
$conn->set_charset("utf8mb4");

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $identifier = $_POST['user_id'];
    $new_pass = $_POST['new_password'];

    // 2. Buscamos el ID numérico del usuario usando su cédula o username
    $stmt_buscar = $conn->prepare("SELECT id_sistema FROM usuarios_sistema WHERE cedula = ? OR username = ?");
    $stmt_buscar->bind_param("ss", $identifier, $identifier);
    $stmt_buscar->execute();
    $resultado = $stmt_buscar->get_result();
    
    if ($row = $resultado->fetch_assoc()) {
        $id_del_usuario = $row['id_sistema'];

        // 3. Hashear la contraseña
        $hashed_password = password_hash($new_pass, PASSWORD_BCRYPT);

        // 4. Actualizar contraseña, activar cuenta y resetear intentos
        $stmt_update = $conn->prepare("UPDATE usuarios_sistema SET password_hash = ?, estado = 'activo', intentos_fallidos = 0 WHERE id_sistema = ?");
        $stmt_update->bind_param("si", $hashed_password, $id_del_usuario);

        if ($stmt_update->execute()) {
            
            // 5. REGISTRAR EN LA BITÁCORA
            $descripcion_bitacora = "Recuperación de cuenta y cambio de contraseña exitoso";
            $stmt_bitacora = $conn->prepare("INSERT INTO bitacora (usuario_id, descripcion) VALUES (?, ?)");
            $stmt_bitacora->bind_param("is", $id_del_usuario, $descripcion_bitacora);
            $stmt_bitacora->execute();
            $stmt_bitacora->close();

            // REDIRECCIÓN SILENCIOSA CON PARÁMETRO DE ÉXITO
            header("Location: login.html?reset=success");
            exit();

        } else {
            // REDIRECCIÓN CON PARÁMETRO DE ERROR
            header("Location: login.html?reset=error");
            exit();
        }
        $stmt_update->close();
        
    } else {
        // Usuario no encontrado
        header("Location: login.html?reset=notfound");
        exit();
    }
    
    $stmt_buscar->close();
}
$conn->close();
?>