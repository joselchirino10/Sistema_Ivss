<?php
require_once 'sesion.php'; 

validarAcceso('Administrador'); 

// 1. CONFIGURACIÓN DE CONEXIÓN
require_once '../conexion.php';
// 2. OBTENER USUARIO ACTUAL (Si no hay sesión, usamos el ID 2 de prueba)
$mi_id = $_SESSION['usuario_id'] ?? 2; 
$mensaje_exito = false;
$error_msj = "";

// 3. LÓGICA DE ACTUALIZACIÓN AL ENVIAR FORMULARIO
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nombre = $_POST['nombre'];
    $apellidos = $_POST['apellidos'];
    $correo = $_POST['correo'];
    $password = $_POST['password'];

    try {
        if (!empty($password)) {
            // Actualizar con nueva contraseña
            $pass_hash = password_hash($password, PASSWORD_DEFAULT);
            $sql = "UPDATE usuarios_sistema SET nombre = ?, apellidos = ?, correo = ?, password_hash = ? WHERE id_sistema = ?";
            $stmt = $pdo->prepare($sql);
            $stmt->execute([$nombre, $apellidos, $correo, $pass_hash, $mi_id]);
        } else {
            // Actualizar solo datos básicos
            $sql = "UPDATE usuarios_sistema SET nombre = ?, apellidos = ?, correo = ? WHERE id_sistema = ?";
            $stmt = $pdo->prepare($sql);
            $stmt->execute([$nombre, $apellidos, $correo, $mi_id]);
        }
        $mensaje_exito = true;
    } catch (PDOException $e) {
        $error_msj = "Error: El correo electrónico ya está registrado por otro usuario.";
    }
}

// 4. CONSULTAR DATOS ACTUALES PARA MOSTRAR EN INPUTS Y SIDEBAR
$stmt = $pdo->prepare("SELECT * FROM usuarios_sistema WHERE id_sistema = ?");
$stmt->execute([$mi_id]);
$user_data = $stmt->fetch();

$foto_path = "uploads/perfil_" . $mi_id . ".jpg";
$foto_vif = file_exists($foto_path) ? $foto_path : "https://ui-avatars.com/api/?name=".urlencode($user_data['nombre'])."&background=0056b3&color=fff";
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>IVSS - Mi Perfil</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600&family=Montserrat:wght@500;600&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <style>
        :root { --primary-blue: #0056b3; --dark-blue: #003366; --accent: #00d1b2; --bg: #f0f2f5; --white: #ffffff; --text: #2d3436; --sidebar-width: 260px; --navbar-height: 80px; }
        * { margin: 0; padding: 0; box-sizing: border-box; font-family: 'Inter', sans-serif; }
        body { background-color: var(--bg); color: var(--text); height: 100vh; display: flex; flex-direction: column; overflow: hidden; }

        /* NAVBAR */
        .navbar { height: var(--navbar-height); background: var(--primary-blue); display: flex; align-items: center; padding: 0 2rem; border-bottom: 3px solid var(--accent); z-index: 1000; }
        .navbar-content { display: flex; align-items: center; gap: 15px; }
        .navbar-logo { height: 50px; }
        .navbar-text { font-family: 'Montserrat', sans-serif; font-size: 0.9rem; font-weight: 600; color: white; line-height: 1.2; }

        /* CONTENEDOR PRINCIPAL */
        .app-container { display: flex; flex: 1; overflow: hidden; }

        /* SIDEBAR COMPLETA */
        .sidebar { width: var(--sidebar-width); background: var(--dark-blue); color: white; padding: 2rem 1rem; display: flex; flex-direction: column; gap: 10px; }
        .menu-item { padding: 12px 15px; color: #cbd5e0; text-decoration: none; display: flex; align-items: center; gap: 12px; border-radius: 8px; transition: 0.3s; font-size: 0.9rem; }
        .menu-item:hover { background: rgba(255,255,255,0.1); color: white; }
        .menu-item.active { background: var(--primary-blue); color: white; }

        /* ÁREA DE CONTENIDO */
        .main-content { flex: 1; overflow-y: auto; padding: 2.5rem; display: flex; justify-content: center; align-items: flex-start; }
        
        /* TARJETA DE EDICIÓN */
        .card-edit { background: var(--white); border-radius: 15px; padding: 2.5rem; box-shadow: 0 10px 25px rgba(0,0,0,0.05); width: 100%; max-width: 600px; }
        .header-edit { text-align: center; margin-bottom: 2rem; }
        .img-preview { width: 110px; height: 110px; border-radius: 50%; border: 4px solid var(--primary-blue); object-fit: cover; margin-bottom: 12px; box-shadow: 0 4px 10px rgba(0,0,0,0.1); }

        .form-row { display: flex; gap: 20px; }
        .form-group { margin-bottom: 1.5rem; flex: 1; }
        .form-group label { display: block; margin-bottom: 8px; font-weight: 600; font-size: 0.85rem; color: #555; }
        .form-group input { width: 100%; padding: 12px; border: 1px solid #ddd; border-radius: 10px; font-size: 0.95rem; background: #fdfdfd; transition: 0.3s; }
        .form-group input:focus { border-color: var(--primary-blue); outline: none; box-shadow: 0 0 0 3px rgba(0,86,179,0.1); }

        .btn-save { background: var(--primary-blue); color: white; border: none; padding: 14px; width: 100%; border-radius: 10px; font-weight: 600; cursor: pointer; transition: 0.3s; font-size: 1rem; margin-top: 10px; }
        .btn-save:hover { background: #004494; transform: translateY(-1px); }
        
        .pass-hint { font-size: 0.75rem; color: #888; margin-top: 6px; line-height: 1.4; }
        .back-link { display: block; text-align: center; margin-top: 20px; color: #666; text-decoration: none; font-size: 0.85rem; font-weight: 500; }
        .back-link:hover { color: var(--primary-blue); }
    </style>
</head>
<body>

    <?php if($mensaje_exito): ?>
    <script>
        document.addEventListener("DOMContentLoaded", function() {
            Swal.fire({
                icon: 'success',
                title: '¡Cambios Guardados!',
                text: 'Tu información de perfil ha sido actualizada con éxito.',
                confirmButtonColor: '#0056b3',
                timer: 3000
            }).then(() => { window.location.href = '../admin/gestion_usuarios.php'; });
        });
    </script>
    <?php endif; ?>

    <?php if($error_msj !== ""): ?>
    <script>
        document.addEventListener("DOMContentLoaded", function() {
            Swal.fire({ icon: 'error', title: 'Error', text: '<?= $error_msj ?>' });
        });
    </script>
    <?php endif; ?>

    <nav class="navbar">
        <div class="navbar-content">
            <img src="../assets/seguro.png" alt="Logo Seguro" class="navbar-logo">
            <span class="navbar-text">DEPARTAMENTO DE REGISTRO Y ESTADÍSTICA <br> HOSPITAL DR. RAFAEL GALLARDO</span>
        </div>
    </nav>

    <div class="app-container">
        <aside class="sidebar">
            <a href="../admin/dashboard_admin.php" class="menu-item"><i class="fas fa-th-large"></i> Dashboard</a>
            <a href="../admin/registrar_ingreso.php" class="menu-item"><i class="fas fa-user-plus"></i> Registrar Ingreso</a>
            <a href="../admin/gestion_pacientes.php" class="menu-item"><i class="fas fa-search"></i> Gestion Pacientes</a>
            <a href="../admin/gestion_usuarios.php" class="menu-item active"><i class="fas fa-user-shield"></i> Gestión Usuarios</a>
            <a href="../admin/bitacora.php" class="menu-item"><i class="fas fa-book"></i> Bitácora</a>
            <div style="margin-top: auto; padding-top: 20px; border-top: 1px solid rgba(255,255,255,0.1);">
            <a href="logout.php" class="menu-item" style="color: #ff7675; font-weight: 600;">
            <i class="fas fa-sign-out-alt"></i> Cerrar Sesión
            </a>
</div>
        </aside>

        <main class="main-content">
            <div class="card-edit">
                <div class="header-edit">
                    <img src="<?= $foto_vif ?>?v=<?=time()?>" class="img-preview">
                    <h2 style="color: var(--dark-blue); margin-bottom: 4px;">Editar mi Información</h2>
                    <p style="color: #888; font-size: 0.85rem;">Configura tus datos de acceso y personales</p>
                </div>

                <form method="POST" action="editar_perfil.php">
                    <div class="form-row">
                        <div class="form-group">
                            <label><i class="fas fa-user"></i> Nombre(s)</label>
                            <input type="text" name="nombre" value="<?= htmlspecialchars($user_data['nombre']) ?>" required>
                        </div>
                        <div class="form-group">
                            <label><i class="fas fa-user-tag"></i> Apellido(s)</label>
                            <input type="text" name="apellidos" value="<?= htmlspecialchars($user_data['apellidos']) ?>" required>
                        </div>
                    </div>

                    <div class="form-group">
                        <label><i class="fas fa-envelope"></i> Correo Electrónico</label>
                        <input type="email" name="correo" value="<?= htmlspecialchars($user_data['correo']) ?>" required>
                    </div>

                   

                    <button type="submit" class="btn-save">Actualizar Perfil</button>
                    <a href="../admin/gestion_usuarios.php" class="back-link">Cancelar y volver</a>
                </form>
            </div>
        </main>
    </div>
</body>
</html>