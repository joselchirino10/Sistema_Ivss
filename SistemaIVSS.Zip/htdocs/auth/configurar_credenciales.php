<?php
session_start();
// Validación de seguridad básica
$user_identifier = isset($_GET['user']) ? $_GET['user'] : '';

if (empty($user_identifier) && !isset($_SESSION['temp_user_id'])) {
    header("Location: login.html");
    exit;
}

// Opciones exactas de tu tabla SQL
$preguntas_db = [
    '¿Cuál es el nombre de tu primera mascota?',
    '¿En qué ciudad nacieron tus padres?',
    '¿Cuál era el nombre de tu escuela primaria?',
    '¿Cuál es tu película favorita?',
    '¿Cuál es el modelo de tu primer automóvil?'
];
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Verificación de Seguridad - IVSS</title>
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@500;600&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="../assets/style.css">
    <style>
        .container { max-width: 550px; margin: 20px auto; }
        .card { background: white; padding: 25px; border-radius: 12px; box-shadow: 0 10px 25px rgba(0,0,0,0.1); border-top: 6px solid #0056b3; }
        
        #section-verify { text-align: center; }
        .code-input { 
            letter-spacing: 8px; 
            font-size: 24px !important; 
            text-align: center; 
            font-weight: bold; 
            border: 2px solid #0056b3 !important;
        }
        .loading-spinner { display: none; margin: 10px auto; border: 4px solid #f3f3f3; border-top: 4px solid #3498db; border-radius: 50%; width: 30px; height: 30px; animation: spin 1s linear infinite; }
        @keyframes spin { 0% { transform: rotate(0deg); } 100% { transform: rotate(360deg); } }

        .password-wrapper { position: relative; width: 100%; }
        .toggle-pass { position: absolute; right: 12px; top: 50%; transform: translateY(-50%); background: none; border: none; cursor: pointer; font-size: 1.1rem; color: #777; }
        
        input[type="password"], input[type="text"], select { width: 100%; padding: 12px; margin-top: 5px; border: 1px solid #ddd; border-radius: 6px; box-sizing: border-box; }
        
        .strength-meter { width: 100%; height: 8px; background: #eee; border-radius: 4px; margin: 10px 0; overflow: hidden; }
        .bar { height: 100%; width: 0%; transition: all 0.4s ease; }
        .weak { background: #ff4d4d; width: 33%; }
        .medium { background: #ffd633; width: 66%; }
        .strong { background: #2eb82e; width: 100%; }
        
        .requirement { font-size: 0.8rem; font-weight: 600; margin-top: 4px; }
        .invalid-text { color: #ff4d4d; }
        .valid-text { color: #2eb82e; }
        header { text-align: center; margin-bottom: 15px; }
        .hidden { display: none; }
        .btn-primary { background: #0056b3; color: white; border: none; border-radius: 6px; font-weight: 600; padding: 15px; transition: 0.3s; cursor: pointer; width: 100%; }
        .btn-primary:disabled { background: #ccc; cursor: not-allowed; }
        hr { margin: 25px 0; border: 0; border-top: 1px solid #eee; }
        .toggle-pass { 
    position: absolute; 
    right: 12px; 
    top: calc(50% + 2px); /* Centrado vertical considerando el margin-top del input */
    transform: translateY(-50%); 
    background: none; 
    border: none; 
    cursor: pointer; 
    font-size: 1.1rem; 
    color: #777; 
    z-index: 10; /* Asegura que esté por encima */
}
    </style>
</head>
<body>
    <nav class="navbar">
        <div class="navbar-content">
            <img src="../assets/seguro.png" alt="Logo" class="navbar-logo" style="height: 40px;">
            <span class="navbar-text">
                Departamento de Registro y Estadística <br> 
                Hospital Dr. Rafael Gallardo
            </span>
        </div>
    </nav>

    <div class="container">
        <header>
            
            <h1>Seguridad de la Cuenta</h1>
        </header>

        <div class="card">
            <div id="section-verify">
                <h3>Confirmar Identidad</h3><br>
                <p>Necesitamos enviarle un código de validación al correo registrado.</p><br>
                
                <button type="button" id="btn-send-code" class="btn-primary">
                    Enviar Código al Correo
                </button>
                <div id="loader" class="loading-spinner"></div>

                <div id="verify-input-group" class="hidden" style="margin-top: 25px; border-top: 1px dashed #ccc; padding-top: 20px;">
                    <label>Ingrese el código de 6 dígitos:</label>
                    <input type="text" id="verification-code" class="code-input" maxlength="6" placeholder="000000">
                    <p id="verify-error" class="requirement invalid-text"></p>
                    <button type="button" id="btn-confirm-code" class="btn-primary" style="background: #28a745; margin-top: 15px;">
                        Validar Código
                    </button>
                </div>
            </div>

            <form id="form-config" action="save_credentials.php" method="POST" class="hidden">
                <input type="hidden" name="identifier" value="<?php echo htmlspecialchars($user_identifier); ?>">

                <h3>Establecer Nueva Contraseña</h3>
                <div class="form-group">
                    <label>Nueva Contraseña</label>
                    <div class="password-wrapper">
                        <input type="password" id="new-password" name="new_password" required placeholder="Mínimo 16 caracteres">
                        <button type="button" class="toggle-pass" onclick="toggleVisibility('new-password')">👁️</button>
                    </div>
                    <div class="strength-meter">
                        <div id="strength-bar" class="bar"></div>
                    </div>
                    <p id="strength-text" class="requirement invalid-text">Mínimo 16 caracteres (letras, números y símbolos)</p>
                </div>

                <div class="form-group" style="margin-top: 15px;">
                    <label>Confirmar Contraseña</label>
                    <div class="password-wrapper">
                        <input type="password" id="confirm-password" required placeholder="Repita la contraseña">
                        <button type="button" class="toggle-pass" onclick="toggleVisibility('confirm-password')">👁️</button>
                    </div>
                    <p id="match-text" class="requirement"></p>
                </div>

                <hr>

                <h3>Preguntas de Seguridad</h3>
                <div class="form-group">
                    <label>Pregunta 1</label>
                    <select name="pregunta1" id="pregunta1" required>
                        <option value="" disabled selected>Seleccione una pregunta...</option>
                        <?php foreach($preguntas_db as $p): ?>
                            <option value="<?php echo $p; ?>"><?php echo $p; ?></option>
                        <?php endforeach; ?>
                    </select>
                    <input type="text" name="respuesta1" placeholder="Su respuesta" required>
                </div>

                <div class="form-group" style="margin-top: 15px;">
                    <label>Pregunta 2</label>
                    <select name="pregunta2" id="pregunta2" required>
                        <option value="" disabled selected>Seleccione otra pregunta...</option>
                        <?php foreach($preguntas_db as $p): ?>
                            <option value="<?php echo $p; ?>"><?php echo $p; ?></option>
                        <?php endforeach; ?>
                    </select>
                    <input type="text" name="respuesta2" placeholder="Su respuesta" required>
                </div>

                <button type="submit" id="btn-save" class="btn-primary" style="margin-top: 30px;" disabled>
                    Finalizar y Guardar
                </button>
            </form>
        </div>
    </div>

    <script>
        // Elementos
        const sectionVerify = document.getElementById('section-verify');
        const verifyInputGroup = document.getElementById('verify-input-group');
        const btnSendCode = document.getElementById('btn-send-code');
        const btnConfirmCode = document.getElementById('btn-confirm-code');
        const inputCode = document.getElementById('verification-code');
        const loader = document.getElementById('loader');
        const formConfig = document.getElementById('form-config');
        const passInput = document.getElementById('new-password');
        const confirmInput = document.getElementById('confirm-password');
        const strengthBar = document.getElementById('strength-bar');
        const strengthText = document.getElementById('strength-text');
        const matchText = document.getElementById('match-text');
        const btnSave = document.getElementById('btn-save');
        const select1 = document.getElementById('pregunta1');
        const select2 = document.getElementById('pregunta2');

        // --- Lógica de Verificación (AJAX) ---
        btnSendCode.addEventListener('click', async () => {
            btnSendCode.disabled = true;
            loader.style.display = 'block';
            const formData = new FormData();
            formData.append('identifier', "<?php echo $user_identifier; ?>");

            try {
                const response = await fetch('recuperar/enviar_codigo.php', { method: 'POST', body: formData });
                const data = await response.json();
                loader.style.display = 'none';
                if (data.status === 'success' || data.status === 'debug') {
                    if(data.status === 'debug') alert("CÓDIGO: " + data.code);
                    verifyInputGroup.classList.remove('hidden');
                } else {
                    alert(data.message);
                    btnSendCode.disabled = false;
                }
            } catch (e) { alert("Error de conexión"); btnSendCode.disabled = false; loader.style.display = 'none'; }
        });

        btnConfirmCode.addEventListener('click', async () => {
            const formData = new FormData();
            formData.append('codigo_ingresado', inputCode.value);
            const response = await fetch('recuperar/validar_codigo.php', { method: 'POST', body: formData });
            const data = await response.json();

            if (data.status === 'success') {
                sectionVerify.classList.add('hidden');
                formConfig.classList.remove('hidden');
            } else {
                document.getElementById('verify-error').innerText = data.message;
            }
        });

        // --- Lógica de Contraseña y Preguntas ---
        function toggleVisibility(inputId) {
            const input = document.getElementById(inputId);
            const btn = input.nextElementSibling;
            input.type = (input.type === "password") ? "text" : "password";
            btn.textContent = (input.type === "password") ? "👁️" : "🔒";
        }

        function validarFormulario() {
            const pass = passInput.value;
            const confirm = confirmInput.value;
            let score = 0;

            if (pass.length >= 16) score++;
            if (/[A-Z]/.test(pass) && /[a-z]/.test(pass)) score++; 
            if (/\d/.test(pass)) score++; 
            if (/[@$!%*?&._-]/.test(pass)) score++; 

            let passValid = (pass.length >= 16 && score >= 4);
            
            if (pass.length === 0) updateMeter(0, "Esperando contraseña...", "");
            else if (pass.length < 16) updateMeter(33, "Faltan " + (16-pass.length) + " caracteres", "weak");
            else if (score < 4) updateMeter(66, "Use mayúsculas, números y símbolos", "medium");
            else updateMeter(100, "¡Contraseña Robusta!", "strong");

            let matchValid = (confirm.length > 0 && pass === confirm);
            matchText.innerText = matchValid ? "Las contraseñas coinciden" : (confirm.length > 0 ? "No coinciden" : "");
            matchText.className = "requirement " + (matchValid ? "valid-text" : "invalid-text");

            btnSave.disabled = !(passValid && matchValid);
        }

        function filtrarPreguntas() {
            const v1 = select1.value;
            const v2 = select2.value;
            Array.from(select2.options).forEach(opt => opt.style.display = (opt.value === v1 && v1 !== "") ? 'none' : 'block');
            Array.from(select1.options).forEach(opt => opt.style.display = (opt.value === v2 && v2 !== "") ? 'none' : 'block');
        }

        function updateMeter(percent, text, status) {
            strengthBar.className = "bar " + status;
            strengthBar.style.width = percent + "%";
            strengthText.innerText = text;
            strengthText.className = "requirement " + (status === "strong" ? "valid-text" : "invalid-text");
        }

        passInput.addEventListener('input', validarFormulario);
        confirmInput.addEventListener('input', validarFormulario);
        select1.addEventListener('change', filtrarPreguntas);
        select2.addEventListener('change', filtrarPreguntas);
    </script>
</body>
</html>