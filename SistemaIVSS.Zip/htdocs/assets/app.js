/**
 * Sistema de Registro Hospitalario - Frontend Senior
 * Adaptado para BD_IVSS
 */

const API_URL = '../api/api.php';

// --- FUNCIONES DE UTILIDAD ---

// Formateador: Prefijo 01 + ceros a la izquierda para completar 6 dígitos
const formatHospitalID = (id) => {
    if (!id) return "000000";
    return `01${String(id).padStart(4, '0')}`;
};

// Sanitización básica para evitar XSS
const sanitize = (str) => {
    const temp = document.createElement('div');
    temp.textContent = str;
    return temp.innerHTML;
};

// --- LÓGICA PRINCIPAL ---

const buscarPaciente = async () => {
    const searchInput = document.getElementById('search-cedula');
    const cedula = searchInput.value.trim();
    const loader = document.getElementById('loader');
    const searchError = document.getElementById('search-error');

    // Validación de entrada
    if (!/^\d+$/.test(cedula)) {
        searchError.classList.remove('hidden');
        return;
    }
    
    searchError.classList.add('hidden');
    resetViews();
    loader.classList.remove('hidden');

    try {
        // Petición GET al backend (parámetro ?cedula=...)
        const response = await fetch(`${API_URL}?cedula=${encodeURIComponent(cedula)}`);
        
        if (response.ok) {
            // Caso: Paciente EXISTE
            const paciente = await response.json();
            renderCard(paciente);
        } else if (response.status === 404) {
            // Caso: Paciente NO existe
            prepareRegistrationForm(cedula);
        } else {
            throw new Error("Error en el servidor");
        }
    } catch (error) {
        console.error("Error de conexión:", error);
        alert("No se pudo conectar con el servidor PHP.");
    } finally {
        loader.classList.add('hidden');
    }
};

// --- MANEJO DE LA INTERFAZ (DOM) ---

const renderCard = (p) => {
    const card = document.getElementById('patient-card');
    card.classList.remove('hidden');
    
    document.getElementById('card-id').textContent = formatHospitalID(p.id);
    document.getElementById('card-nombres').textContent = p.nombres;
    document.getElementById('card-apellidos').textContent = p.apellidos;
    document.getElementById('card-dob').textContent = p.fecha_nacimiento;
    document.getElementById('card-cedula').textContent = p.cedula_identidad;
};

const prepareRegistrationForm = (cedula) => {
    const formSection = document.getElementById('registration-form');
    formSection.classList.remove('hidden');
    
    // Pre-llenar cédula y bloquearla
    const regCedula = document.getElementById('reg-cedula');
    regCedula.value = cedula;
    regCedula.readOnly = true;
};

const resetViews = () => {
    document.getElementById('patient-card').classList.add('hidden');
    document.getElementById('registration-form').classList.add('hidden');
    document.getElementById('form-patient').reset();
};

// --- EVENTOS ---

// Botón Buscar
document.getElementById('btn-search').addEventListener('click', buscarPaciente);

// Enter en el input de búsqueda
document.getElementById('search-cedula').addEventListener('keypress', (e) => {
    if (e.key === 'Enter') buscarPaciente();
});

// Envío del Formulario (POST)
document.getElementById('form-patient').addEventListener('submit', async (e) => {
    e.preventDefault();
    
    const payload = {
        nombres: document.getElementById('reg-nombres').value,
        apellidos: document.getElementById('reg-apellidos').value,
        cedula_identidad: document.getElementById('reg-cedula').value,
        fecha_nacimiento: document.getElementById('reg-dob').value
    };

    try {
        const response = await fetch(API_URL, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(payload)
        });

        const result = await response.json();

        if (response.ok) {
            alert("¡Paciente registrado exitosamente!");
            // Volvemos a buscar para mostrar la tarjeta con el ID generado
            buscarPaciente();
        } else {
            alert("Error al registrar: " + (result.error || "Desconocido"));
        }
    } catch (error) {
        console.error("Error en POST:", error);
        alert("Error de red al intentar registrar.");
    }
});

// Función global para el botón "Nueva Búsqueda" o "Cancelar"
window.resetUI = () => {
    resetViews();
    document.getElementById('search-cedula').value = '';
    document.getElementById('search-cedula').focus();
};
// Seleccionamos el campo de la cédula
const inputCedula = document.getElementById('search-cedula');

// Escuchamos cada vez que el usuario presiona una tecla
inputCedula.addEventListener('input', function () {
    // Esta línea busca cualquier cosa que NO sea un número y la borra al instante
    this.value = this.value.replace(/[^0-9]/g, '');
});

// Hacemos lo mismo para los nombres (que solo permita letras y espacios)
const inputNombres = document.getElementById('reg-nombres');
const inputApellidos = document.getElementById('reg-apellidos');

const soloLetras = function () {
    this.value = this.value.replace(/[^a-zA-ZáéíóúÁÉÍÓÚñÑ\s]/g, '');
};

inputNombres.addEventListener('input', soloLetras);
inputApellidos.addEventListener('input', soloLetras);